import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'plan_models.dart';

/// يرسم المخطط المعماري بمقياس رسم: جدران، أبواب، شبابيك، أعمدة، أثاث، أبعاد.
class PlanPainter extends CustomPainter {
  final FloorPlan plan;
  PlanPainter(this.plan);

  static const _ink = Color(0xFF1A1A1A);
  static const _wall = Color(0xFF222222);
  static const double extT = 0.25; // سماكة الجدار الخارجي (م)
  static const double intT = 0.12; // سماكة الجدار الداخلي (م)

  static Size sizeFor(FloorPlan p, double width) {
    final s = (width * 0.88) / p.plotW;
    return Size(width, width * 0.18 + s * p.plotL);
  }

  static Future<Uint8List> renderPng(FloorPlan p, {double width = 3000}) async {
    final size = sizeFor(p, width);
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec, Offset.zero & size);
    PlanPainter(p).paint(canvas, size);
    final pic = rec.endRecording();
    final img = await pic.toImage(size.width.round(), size.height.round());
    final bd = await img.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  static Color roomColor(String type) {
    switch (type) {
      case 'bedroom':
      case 'master_bedroom':
        return const Color(0xFFEAF2FB);
      case 'bathroom':
      case 'toilet':
      case 'laundry':
        return const Color(0xFFE3F6F8);
      case 'kitchen':
        return const Color(0xFFFFF6DD);
      case 'living':
      case 'dining':
        return const Color(0xFFEAF7E8);
      case 'majlis_men':
      case 'majlis_women':
        return const Color(0xFFFCEBDD);
      case 'courtyard':
        return const Color(0xFFF1F8EC);
      case 'garage':
        return const Color(0xFFEFEFEF);
      case 'stairs':
        return const Color(0xFFF3EDF8);
      default:
        return const Color(0xFFF6F6F4);
    }
  }

  void _text(Canvas c, String text, Offset center, double fs,
      {bool bold = false,
      Color color = _ink,
      double maxW = 1e9,
      double rotate = 0}) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
            fontSize: fs,
            color: color,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
            height: 1.15),
      ),
      textDirection: TextDirection.rtl,
      textAlign: TextAlign.center,
      maxLines: 3,
    )..layout(maxWidth: maxW);
    c.save();
    c.translate(center.dx, center.dy);
    if (rotate != 0) c.rotate(rotate);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  void _dashedLine(Canvas c, Offset a, Offset b, Paint p, double dash, double gap) {
    final total = (b - a).distance;
    if (total == 0) return;
    final dir = (b - a) / total;
    var d = 0.0;
    while (d < total) {
      final e = math.min(d + dash, total);
      c.drawLine(a + dir * d, a + dir * e, p);
      d += dash + gap;
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (!plan.valid) return;
    final W = size.width;
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    final availH = size.height - 0.18 * W;
    final s = math.min(W * 0.88 / plan.plotW, availH / plan.plotL);
    final ox = W * 0.06;
    final oy = W * 0.10 + (availH - s * plan.plotL) / 2;
    Offset P(double x, double y) => Offset(ox + x * s, oy + y * s);
    Rect R(double x, double y, double w, double h) =>
        Rect.fromLTWH(ox + x * s, oy + y * s, w * s, h * s);
    final fs = (s * 0.30).clamp(5.0, 70.0).toDouble();
    final opt = plan.options;

    // عنوان
    final area = plan.plotW * plan.plotL;
    _text(canvas, plan.title.isEmpty ? 'مخطط معماري' : plan.title,
        Offset(W / 2, W * 0.035), fs * 1.7,
        bold: true, maxW: W * 0.7);
    _text(
        canvas,
        '${plan.level}  •  الأرض ${fmtM(plan.plotW)}×${fmtM(plan.plotL)} م (${fmtM(area, 1)} م²)  •  المبني ${fmtM(plan.builtArea, 1)} م²  •  نسبة البناء ${fmtM(plan.coveragePct, 1)}%',
        Offset(W / 2, W * 0.07),
        fs * 0.85,
        maxW: W * 0.88,
        color: const Color(0xFF555555));

    // شبكة
    if (opt.grid) {
      final gp = Paint()
        ..color = const Color(0xFFE6E6E6)
        ..strokeWidth = 1;
      for (var x = 0.0; x <= plan.plotW + 0.001; x += 1) {
        canvas.drawLine(P(x, 0), P(x, plan.plotL), gp);
      }
      for (var y = 0.0; y <= plan.plotL + 0.001; y += 1) {
        canvas.drawLine(P(0, y), P(plan.plotW, y), gp);
      }
    }

    // الشارع
    if (plan.street.isNotEmpty) {
      final band = Paint()..color = const Color(0xFFE3E3E3);
      const bw = 1.0;
      Rect? r;
      double rot = 0;
      switch (plan.street) {
        case 'top':
          r = R(0, -bw - 0.4, plan.plotW, bw);
          break;
        case 'bottom':
          r = R(0, plan.plotL + 0.4, plan.plotW, bw);
          break;
        case 'left':
          r = R(-bw - 0.4, 0, bw, plan.plotL);
          rot = -math.pi / 2;
          break;
        case 'right':
          r = R(plan.plotW + 0.4, 0, bw, plan.plotL);
          rot = math.pi / 2;
          break;
      }
      if (r != null) {
        canvas.drawRect(r, band);
        _text(canvas, 'الشارع', r.center, fs, color: const Color(0xFF666666), rotate: rot);
      }
    }

    // حدود الأرض والارتدادات
    final plotP = Paint()
      ..color = const Color(0xFF666666)
      ..strokeWidth = math.max(1.2, s * 0.03)
      ..style = PaintingStyle.stroke;
    final pr = R(0, 0, plan.plotW, plan.plotL);
    _dashedLine(canvas, pr.topLeft, pr.topRight, plotP, s * 0.5, s * 0.25);
    _dashedLine(canvas, pr.topRight, pr.bottomRight, plotP, s * 0.5, s * 0.25);
    _dashedLine(canvas, pr.bottomRight, pr.bottomLeft, plotP, s * 0.5, s * 0.25);
    _dashedLine(canvas, pr.bottomLeft, pr.topLeft, plotP, s * 0.5, s * 0.25);
    if (plan.sbTop + plan.sbBottom + plan.sbLeft + plan.sbRight > 0) {
      final sp = Paint()
        ..color = const Color(0xFFB0B0B0)
        ..strokeWidth = math.max(1.0, s * 0.015);
      final x1 = plan.sbLeft, x2 = plan.plotW - plan.sbRight;
      final y1 = plan.sbTop, y2 = plan.plotL - plan.sbBottom;
      _dashedLine(canvas, P(x1, y1), P(x2, y1), sp, s * 0.12, s * 0.12);
      _dashedLine(canvas, P(x2, y1), P(x2, y2), sp, s * 0.12, s * 0.12);
      _dashedLine(canvas, P(x2, y2), P(x1, y2), sp, s * 0.12, s * 0.12);
      _dashedLine(canvas, P(x1, y2), P(x1, y1), sp, s * 0.12, s * 0.12);
    }

    // تعبئة الغرف
    for (final r in plan.rooms) {
      canvas.drawRect(R(r.x, r.y, r.w, r.h), Paint()..color = roomColor(r.type));
    }

    // الأثاث
    if (opt.furniture) {
      for (final f in plan.furniture) {
        final pl = plan.placeFurniture(f);
        if (pl == null) continue;
        final rr = pl.rect;
        final odd = pl.turns.isOdd;
        final lw = (odd ? rr.height : rr.width) * s;
        final ld = (odd ? rr.width : rr.height) * s;
        final c = P(rr.center.dx, rr.center.dy);
        canvas.save();
        canvas.translate(c.dx, c.dy);
        canvas.rotate(pl.turns * math.pi / 2);
        _drawFurn(canvas, f.type, lw, ld, s);
        canvas.restore();
      }
    }

    // الجدران
    final wallPaint = Paint()..color = _wall;
    for (final r in plan.rooms) {
      for (final w in const ['N', 'S', 'W', 'E']) {
        final t = plan.isExternalEdge(r, w) ? extT : intT;
        final h = t / 2;
        Rect rr;
        switch (w) {
          case 'N':
            rr = R(r.x - h, r.y - h, r.w + t, t);
            break;
          case 'S':
            rr = R(r.x - h, r.y + r.h - h, r.w + t, t);
            break;
          case 'W':
            rr = R(r.x - h, r.y - h, t, r.h + t);
            break;
          default:
            rr = R(r.x + r.w - h, r.y - h, t, r.h + t);
        }
        canvas.drawRect(rr, wallPaint);
      }
    }

    // الفتحات (أبواب وشبابيك)
    final paper = Paint()..color = Colors.white;
    final line = Paint()
      ..color = _ink
      ..strokeWidth = math.max(1.0, s * 0.03)
      ..style = PaintingStyle.stroke;
    final thin = Paint()
      ..color = _ink
      ..strokeWidth = math.max(0.8, s * 0.015)
      ..style = PaintingStyle.stroke;
    for (final o in plan.openings()) {
      final horizontal = (o.y1 - o.y2).abs() < 1e-6;
      const half = 0.16;
      final gap = horizontal
          ? R(math.min(o.x1, o.x2), o.y1 - half, (o.x2 - o.x1).abs(), half * 2)
          : R(o.x1 - half, math.min(o.y1, o.y2), half * 2, (o.y2 - o.y1).abs());
      canvas.drawRect(gap, paper);
      if (!o.isDoor) {
        // شباك: ثلاثة خطوط
        for (final k in const [-0.06, 0.0, 0.06]) {
          if (horizontal) {
            canvas.drawLine(P(math.min(o.x1, o.x2), o.y1 + k),
                P(math.max(o.x1, o.x2), o.y1 + k), thin);
          } else {
            canvas.drawLine(P(o.x1 + k, math.min(o.y1, o.y2)),
                P(o.x1 + k, math.max(o.y1, o.y2)), thin);
          }
        }
        continue;
      }
      final d = o.door!;
      final startFirst = d.hinge != 'end';
      final hx = startFirst ? o.x1 : o.x2, hy = startFirst ? o.y1 : o.y2;
      final cx = startFirst ? o.x2 : o.x1, cy = startFirst ? o.y2 : o.y1;
      double nx = 0, ny = 0;
      switch (d.wall) {
        case 'N':
          ny = 1;
          break;
        case 'S':
          ny = -1;
          break;
        case 'W':
          nx = 1;
          break;
        default:
          nx = -1;
      }
      if (d.swing == 'out') {
        nx = -nx;
        ny = -ny;
      }
      final wdt = math.sqrt((cx - hx) * (cx - hx) + (cy - hy) * (cy - hy));
      final ox2 = hx + nx * wdt, oy2 = hy + ny * wdt;
      canvas.drawLine(P(hx, hy), P(ox2, oy2), line);
      final ax = cx - hx, ay = cy - hy;
      final start = math.atan2(ay, ax);
      final cross = ax * ny - ay * nx;
      final sweep = cross > 0 ? math.pi / 2 : -math.pi / 2;
      canvas.drawArc(Rect.fromCircle(center: P(hx, hy), radius: wdt * s), start,
          sweep, false, thin);
    }

    // الأعمدة
    if (opt.columns) {
      final cp = Paint()..color = const Color(0xFF111111);
      for (final c in plan.columns) {
        canvas.drawRect(R(c.x - c.size / 2, c.y - c.size / 2, c.size, c.size), cp);
      }
    }

    // أسماء الغرف
    if (opt.labels) {
      for (final r in plan.rooms) {
        final center = P(r.x + r.w / 2, r.y + r.h / 2);
        final dims = opt.dims ? '\n${fmtM(r.w)}×${fmtM(r.h)}' : '';
        _text(canvas, '${r.name}\n${fmtM(r.area, 1)} م²$dims', center, fs,
            maxW: r.w * s * 0.92,
            color: const Color(0xFF222222),
            bold: false);
      }
    }

    // الأبعاد الكلية
    if (opt.dims) {
      final dp = Paint()
        ..color = const Color(0xFF444444)
        ..strokeWidth = math.max(1.0, s * 0.015);
      final yTop = -0.7;
      canvas.drawLine(P(0, yTop), P(plan.plotW, yTop), dp);
      canvas.drawLine(P(0, yTop - 0.15), P(0, yTop + 0.15), dp);
      canvas.drawLine(P(plan.plotW, yTop - 0.15), P(plan.plotW, yTop + 0.15), dp);
      _text(canvas, '${fmtM(plan.plotW)} م', P(plan.plotW / 2, yTop - 0.35), fs * 0.9);
      final xLeft = -0.7;
      canvas.drawLine(P(xLeft, 0), P(xLeft, plan.plotL), dp);
      canvas.drawLine(P(xLeft - 0.15, 0), P(xLeft + 0.15, 0), dp);
      canvas.drawLine(P(xLeft - 0.15, plan.plotL), P(xLeft + 0.15, plan.plotL), dp);
      _text(canvas, '${fmtM(plan.plotL)} م', P(xLeft - 0.35, plan.plotL / 2), fs * 0.9,
          rotate: -math.pi / 2);
    }

    // سهم الشمال
    final nc = Offset(W * 0.93, W * 0.045);
    final nr = W * 0.025;
    canvas.drawCircle(nc, nr, thin);
    final ang = {'up': 0.0, 'right': math.pi / 2, 'down': math.pi, 'left': -math.pi / 2}[plan.north] ?? 0.0;
    canvas.save();
    canvas.translate(nc.dx, nc.dy);
    canvas.rotate(ang);
    final arrow = Path()
      ..moveTo(0, -nr * 0.85)
      ..lineTo(nr * 0.45, nr * 0.6)
      ..lineTo(0, nr * 0.25)
      ..lineTo(-nr * 0.45, nr * 0.6)
      ..close();
    canvas.drawPath(arrow, Paint()..color = _ink);
    canvas.restore();
    _text(canvas, 'ش', nc + Offset(0, nr + fs * 0.9), fs * 0.9, bold: true);

    // مقياس الرسم
    final barM = plan.plotW >= 20 ? 5.0 : (plan.plotW >= 8 ? 2.0 : 1.0);
    final by = size.height - W * 0.035;
    final bx = W * 0.06;
    canvas.drawLine(Offset(bx, by), Offset(bx + barM * s, by), line);
    canvas.drawLine(Offset(bx, by - s * 0.15), Offset(bx, by + s * 0.15), line);
    canvas.drawLine(Offset(bx + barM * s, by - s * 0.15),
        Offset(bx + barM * s, by + s * 0.15), line);
    _text(canvas, '${fmtM(barM, 0)} م', Offset(bx + barM * s / 2, by - fs * 1.1), fs * 0.9);
    _text(canvas, 'تصميم: الليث AI — اقتراح أولي يُراجَع من مهندس مختص',
        Offset(W * 0.62, by), fs * 0.8,
        color: const Color(0xFF777777), maxW: W * 0.6);
  }

  // ---------------- رموز الأثاث (إحداثيات محلية مركزها (0,0)، الظهر في الأعلى) ----------------
  void _drawFurn(Canvas c, String type, double w, double d, double s) {
    final stroke = Paint()
      ..color = const Color(0xFF555555)
      ..strokeWidth = math.max(0.8, s * 0.014)
      ..style = PaintingStyle.stroke;
    final fill = Paint()..color = const Color(0xFFFFFFFF);
    final soft = Paint()..color = const Color(0xFFEDEDED);
    final r = Rect.fromCenter(center: Offset.zero, width: w, height: d);
    final rr = RRect.fromRectAndRadius(r, Radius.circular(math.min(w, d) * 0.06));

    void box() {
      c.drawRRect(rr, fill);
      c.drawRRect(rr, stroke);
    }

    switch (type) {
      case 'bed_double':
      case 'bed_king':
      case 'bed_single':
        box();
        final pw = type == 'bed_single' ? w * 0.7 : w * 0.42;
        final ph = d * 0.13;
        final top = r.top + d * 0.04;
        if (type == 'bed_single') {
          c.drawRect(Rect.fromCenter(center: Offset(0, top + ph / 2), width: pw, height: ph), soft);
          c.drawRect(Rect.fromCenter(center: Offset(0, top + ph / 2), width: pw, height: ph), stroke);
        } else {
          for (final sx in const [-1.0, 1.0]) {
            final cr = Rect.fromCenter(
                center: Offset(sx * w * 0.24, top + ph / 2), width: pw, height: ph);
            c.drawRect(cr, soft);
            c.drawRect(cr, stroke);
          }
        }
        c.drawLine(Offset(r.left, r.top + d * 0.38), Offset(r.right, r.top + d * 0.38), stroke);
        break;
      case 'wardrobe':
        box();
        c.drawLine(r.topLeft, r.bottomRight, stroke);
        c.drawLine(r.topRight, r.bottomLeft, stroke);
        break;
      case 'sofa':
      case 'sofa_corner':
      case 'armchair':
        box();
        c.drawLine(Offset(r.left, r.top + d * 0.28), Offset(r.right, r.top + d * 0.28), stroke);
        final arm = w * 0.09;
        c.drawLine(Offset(r.left + arm, r.top + d * 0.28), Offset(r.left + arm, r.bottom), stroke);
        c.drawLine(Offset(r.right - arm, r.top + d * 0.28), Offset(r.right - arm, r.bottom), stroke);
        break;
      case 'dining_table':
      case 'dining_table_8':
        final tr = Rect.fromCenter(center: Offset.zero, width: w * 0.8, height: d * 0.6);
        c.drawRect(tr, fill);
        c.drawRect(tr, stroke);
        final n = (w / (s * 0.6)).floor().clamp(2, 6);
        for (var i = 0; i < n; i++) {
          final x = -tr.width / 2 + (i + 0.5) * tr.width / n;
          for (final y in [-d * 0.4, d * 0.4]) {
            c.drawRect(Rect.fromCenter(center: Offset(x, y), width: s * 0.38, height: s * 0.3), stroke);
          }
        }
        break;
      case 'coffee_table':
      case 'desk':
        box();
        if (type == 'desk') {
          c.drawRect(Rect.fromCenter(center: Offset(0, d * 0.75), width: s * 0.45, height: s * 0.4), stroke);
        }
        break;
      case 'chair':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        break;
      case 'tv_unit':
      case 'bookshelf':
      case 'dresser':
      case 'bedside':
        c.drawRect(r, soft);
        c.drawRect(r, stroke);
        break;
      case 'kitchen_counter':
      case 'island':
        box();
        if (type == 'kitchen_counter') {
          final sk = Rect.fromCenter(center: Offset(-w * 0.2, 0), width: w * 0.22, height: d * 0.6);
          c.drawRect(sk, stroke);
          for (final cx in [w * 0.15, w * 0.3]) {
            c.drawCircle(Offset(cx, 0), d * 0.16, stroke);
          }
        }
        break;
      case 'fridge':
        box();
        c.drawLine(Offset(r.left, r.top + d * 0.35), Offset(r.right, r.top + d * 0.35), stroke);
        break;
      case 'stove':
        box();
        for (final p in [Offset(-w * 0.22, -d * 0.22), Offset(w * 0.22, -d * 0.22), Offset(-w * 0.22, d * 0.22), Offset(w * 0.22, d * 0.22)]) {
          c.drawCircle(p, math.min(w, d) * 0.13, stroke);
        }
        break;
      case 'sink':
        box();
        c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: w * 0.7, height: d * 0.65), Radius.circular(d * 0.2)), stroke);
        break;
      case 'wc':
        c.drawRect(Rect.fromLTWH(r.left, r.top, w, d * 0.28), fill);
        c.drawRect(Rect.fromLTWH(r.left, r.top, w, d * 0.28), stroke);
        c.drawOval(Rect.fromLTWH(r.left + w * 0.05, r.top + d * 0.28, w * 0.9, d * 0.72), fill);
        c.drawOval(Rect.fromLTWH(r.left + w * 0.05, r.top + d * 0.28, w * 0.9, d * 0.72), stroke);
        break;
      case 'basin':
        box();
        c.drawOval(Rect.fromCenter(center: Offset(0, d * 0.05), width: w * 0.62, height: d * 0.58), stroke);
        break;
      case 'shower':
        box();
        c.drawLine(r.topLeft, r.bottomRight, stroke);
        c.drawCircle(Offset.zero, math.min(w, d) * 0.07, stroke);
        break;
      case 'bathtub':
        box();
        c.drawRRect(RRect.fromRectAndRadius(r.deflate(math.min(w, d) * 0.12), Radius.circular(d * 0.3)), stroke);
        break;
      case 'washing_machine':
        box();
        c.drawCircle(Offset.zero, math.min(w, d) * 0.3, stroke);
        break;
      case 'majlis':
        final n = (w / (s * 0.9)).floor().clamp(2, 12);
        final cw = w / n;
        for (var i = 0; i < n; i++) {
          final cr = Rect.fromLTWH(r.left + i * cw + cw * 0.04, r.top, cw * 0.92, d);
          c.drawRect(cr, soft);
          c.drawRect(cr, stroke);
        }
        break;
      case 'stairs':
        box();
        final steps = (d / (s * 0.28)).floor().clamp(4, 30);
        for (var i = 1; i < steps; i++) {
          final y = r.top + i * d / steps;
          c.drawLine(Offset(r.left, y), Offset(r.right, y), stroke);
        }
        c.drawLine(Offset(0, r.bottom - d * 0.05), Offset(0, r.top + d * 0.1), stroke);
        c.drawLine(Offset(0, r.top + d * 0.1), Offset(-w * 0.15, r.top + d * 0.2), stroke);
        c.drawLine(Offset(0, r.top + d * 0.1), Offset(w * 0.15, r.top + d * 0.2), stroke);
        break;
      case 'car':
        c.drawRRect(RRect.fromRectAndRadius(r, Radius.circular(math.min(w, d) * 0.25)), fill);
        c.drawRRect(RRect.fromRectAndRadius(r, Radius.circular(math.min(w, d) * 0.25)), stroke);
        c.drawRect(Rect.fromCenter(center: Offset(0, -d * 0.05), width: w * 0.7, height: d * 0.4), stroke);
        break;
      default:
        box();
    }
  }

  @override
  bool shouldRepaint(covariant PlanPainter old) => true;
}
