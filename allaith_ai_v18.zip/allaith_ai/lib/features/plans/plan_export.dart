import 'dart:io';
import 'dart:math' as math;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../site_supervision/app_storage.dart';
import '../site_supervision/brand_store.dart';
import 'plan_models.dart';
import 'plan_painter.dart';

class PlanExport {
  PlanExport._();

  static String _stamp() {
    final d = DateTime.now();
    return '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
  }

  static Future<File> _tmp(String name, List<int> bytes) async {
    final dir = await AppStorage.temp();
    final f = File('${dir.path}/$name');
    await f.writeAsBytes(bytes, flush: true);
    return f;
  }

  // ---------------- صورة PNG ----------------
  static Future<void> sharePng(FloorPlan p) async {
    final bytes = await PlanPainter.renderPng(p, width: 3200);
    final f = await _tmp('plan_${_stamp()}.png', bytes);
    await Share.shareXFiles([XFile(f.path, mimeType: 'image/png')]);
  }

  // ---------------- PDF ----------------
  static Future<void> sharePdf(FloorPlan p) async {
    final regular = await PdfGoogleFonts.cairoRegular();
    final bold = await PdfGoogleFonts.cairoBold();
    final png = await PlanPainter.renderPng(p, width: 2800);
    final img = pw.MemoryImage(png);
    pw.MemoryImage? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) logo = pw.MemoryImage(lb.bytes);
    } catch (_) {}
    final landscape = p.plotW >= p.plotL * 0.9;
    final format = landscape ? PdfPageFormat.a3.landscape : PdfPageFormat.a3;

    pw.Widget t(String s, {double size = 10, bool b = false, PdfColor? color}) =>
        pw.Text(s,
            textDirection: pw.TextDirection.rtl,
            textAlign: pw.TextAlign.right,
            style: pw.TextStyle(
                fontSize: size,
                color: color ?? PdfColors.black,
                fontWeight: b ? pw.FontWeight.bold : pw.FontWeight.normal));

    final issues = p.validate();
    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: format,
          margin: const pw.EdgeInsets.all(24),
          theme: pw.ThemeData.withFont(base: regular, bold: bold),
        ),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                if (logo != null)
                  pw.Container(height: 50, child: pw.Image(logo))
                else
                  pw.SizedBox(width: 50),
                t(p.country.isEmpty ? '' : 'المرجع: ${p.country}', size: 11),
              ],
            ),
            pw.SizedBox(height: 6),
            pw.Expanded(
              child: pw.Center(child: pw.Image(img, fit: pw.BoxFit.contain)),
            ),
            pw.SizedBox(height: 6),
            if (p.notes.isNotEmpty) ...[
              t('ملاحظات', size: 11, b: true),
              for (final n in p.notes) t('- $n', size: 9),
            ],
            if (issues.isNotEmpty) ...[
              pw.SizedBox(height: 4),
              t('تنبيهات هندسية للمراجعة', size: 10, b: true, color: PdfColors.red800),
              for (final i in issues.take(8)) t('- ${i.text}', size: 8.5),
            ],
            pw.SizedBox(height: 4),
            t('المخطط اقتراح أولي، والأبعاد والارتدادات تُراجَع مع اشتراطات البلدية ومن مهندس مختص قبل الاعتماد. أُنشئ بواسطة تطبيق الليث AI.',
                size: 8, color: PdfColors.grey700),
          ],
        ),
      ),
    );
    final bytes = await doc.save();
    await Printing.sharePdf(bytes: bytes, filename: 'plan_${_stamp()}.pdf');
  }

  // ---------------- DXF (يفتحه AutoCAD ويحفظه DWG) ----------------
  static String _esc(String s) {
    final b = StringBuffer();
    for (final r in s.runes) {
      if (r > 127) {
        b.write('\\U+${r.toRadixString(16).toUpperCase().padLeft(4, '0')}');
      } else {
        b.writeCharCode(r);
      }
    }
    return b.toString();
  }

  static String buildDxf(FloorPlan p) {
    final out = StringBuffer();
    void g(Object code, Object v) {
      out.writeln(code);
      out.writeln(v);
    }

    String n(double v) => (v * 1000).toStringAsFixed(1); // م -> مم
    double yy(double y) => p.plotL - y; // اقلب المحور الرأسي (CAD يتجه للأعلى)

    const layers = {
      'WALLS': 7,
      'DOORS': 3,
      'WINDOWS': 5,
      'COLUMNS': 1,
      'FURNITURE': 8,
      'TEXT': 2,
      'DIMS': 4,
      'PLOT': 9,
      'SETBACK': 8,
    };

    g(0, 'SECTION');
    g(2, 'HEADER');
    g(9, r'$ACADVER');
    g(1, 'AC1009');
    g(9, r'$INSUNITS');
    g(70, 4);
    g(0, 'ENDSEC');
    g(0, 'SECTION');
    g(2, 'TABLES');
    g(0, 'TABLE');
    g(2, 'LTYPE');
    g(70, 1);
    g(0, 'LTYPE');
    g(2, 'CONTINUOUS');
    g(70, 0);
    g(3, 'Solid line');
    g(72, 65);
    g(73, 0);
    g(40, 0.0);
    g(0, 'ENDTAB');
    g(0, 'TABLE');
    g(2, 'LAYER');
    g(70, layers.length);
    layers.forEach((name, color) {
      g(0, 'LAYER');
      g(2, name);
      g(70, 0);
      g(62, color);
      g(6, 'CONTINUOUS');
    });
    g(0, 'ENDTAB');
    g(0, 'TABLE');
    g(2, 'STYLE');
    g(70, 1);
    g(0, 'STYLE');
    g(2, 'ARABIC');
    g(70, 0);
    g(40, 0.0);
    g(41, 1.0);
    g(50, 0.0);
    g(71, 0);
    g(42, 0.2);
    g(3, 'arial.ttf');
    g(4, '');
    g(0, 'ENDTAB');
    g(0, 'ENDSEC');
    g(0, 'SECTION');
    g(2, 'ENTITIES');

    void line(String layer, double x1, double y1, double x2, double y2) {
      g(0, 'LINE');
      g(8, layer);
      g(10, n(x1));
      g(20, n(yy(y1)));
      g(30, 0);
      g(11, n(x2));
      g(21, n(yy(y2)));
      g(31, 0);
    }

    void text(String layer, double x, double y, double h, String s) {
      g(0, 'TEXT');
      g(8, layer);
      g(10, n(x));
      g(20, n(yy(y)));
      g(30, 0);
      g(40, n(h));
      g(1, _esc(s));
      g(72, 1);
      g(11, n(x));
      g(21, n(yy(y)));
      g(31, 0);
      g(7, 'ARABIC');
    }

    void rect(String layer, double x, double y, double w, double h) {
      line(layer, x, y, x + w, y);
      line(layer, x + w, y, x + w, y + h);
      line(layer, x + w, y + h, x, y + h);
      line(layer, x, y + h, x, y);
    }

    // حدود الأرض والارتدادات
    rect('PLOT', 0, 0, p.plotW, p.plotL);
    if (p.sbTop + p.sbBottom + p.sbLeft + p.sbRight > 0) {
      rect('SETBACK', p.sbLeft, p.sbTop, p.plotW - p.sbLeft - p.sbRight,
          p.plotL - p.sbTop - p.sbBottom);
    }

    // الجدران بخطين متوازيين مع قطع الفتحات
    final openings = p.openings();
    final seen = <String>{};
    for (final r in p.rooms) {
      for (final w in const ['N', 'S', 'W', 'E']) {
        final ext = p.isExternalEdge(r, w);
        final t = ext ? PlanPainter.extT : PlanPainter.intT;
        final h = t / 2;
        final horiz = w == 'N' || w == 'S';
        final fixed = w == 'N'
            ? r.y
            : w == 'S'
                ? r.y + r.h
                : w == 'W'
                    ? r.x
                    : r.x + r.w;
        final a = horiz ? r.x : r.y;
        final b = horiz ? r.x + r.w : r.y + r.h;
        final key = '$horiz:${fixed.toStringAsFixed(2)}:${a.toStringAsFixed(2)}:${b.toStringAsFixed(2)}';
        if (!seen.add(key)) continue;
        // فجوات هذا الضلع
        final gaps = <List<double>>[];
        for (final o in openings) {
          final oh = (o.y1 - o.y2).abs() < 1e-6;
          if (oh != horiz) continue;
          final of = horiz ? o.y1 : o.x1;
          if ((of - fixed).abs() > 0.03) continue;
          final lo = horiz ? math.min(o.x1, o.x2) : math.min(o.y1, o.y2);
          final hi = horiz ? math.max(o.x1, o.x2) : math.max(o.y1, o.y2);
          if (hi <= a || lo >= b) continue;
          gaps.add([math.max(lo, a), math.min(hi, b)]);
        }
        gaps.sort((x, y) => x[0].compareTo(y[0]));
        final segs = <List<double>>[];
        var cur = a - h;
        for (final gp in gaps) {
          if (gp[0] > cur) segs.add([cur, gp[0]]);
          cur = math.max(cur, gp[1]);
        }
        if (cur < b + h) segs.add([cur, b + h]);
        for (final sg in segs) {
          for (final off in [-h, h]) {
            if (horiz) {
              line('WALLS', sg[0], fixed + off, sg[1], fixed + off);
            } else {
              line('WALLS', fixed + off, sg[0], fixed + off, sg[1]);
            }
          }
        }
      }
    }

    // الأبواب والشبابيك
    for (final o in openings) {
      final horiz = (o.y1 - o.y2).abs() < 1e-6;
      if (!o.isDoor) {
        for (final k in const [-0.06, 0.0, 0.06]) {
          if (horiz) {
            line('WINDOWS', math.min(o.x1, o.x2), o.y1 + k, math.max(o.x1, o.x2), o.y1 + k);
          } else {
            line('WINDOWS', o.x1 + k, math.min(o.y1, o.y2), o.x1 + k, math.max(o.y1, o.y2));
          }
        }
        continue;
      }
      final d = o.door!;
      final startFirst = d.hinge != 'end';
      final hx = startFirst ? o.x1 : o.x2, hy = startFirst ? o.y1 : o.y2;
      final cx = startFirst ? o.x2 : o.x1, cy = startFirst ? o.y2 : o.y1;
      double nx = 0, ny = 0;
      switch (d.wall) {
        case 'N':
          ny = 1;
          break;
        case 'S':
          ny = -1;
          break;
        case 'W':
          nx = 1;
          break;
        default:
          nx = -1;
      }
      if (d.swing == 'out') {
        nx = -nx;
        ny = -ny;
      }
      final wd = math.sqrt((cx - hx) * (cx - hx) + (cy - hy) * (cy - hy));
      line('DOORS', hx, hy, hx + nx * wd, hy + ny * wd);
      final ax = cx - hx, ay = cy - hy;
      final start = math.atan2(ay, ax);
      final cross = ax * ny - ay * nx;
      final sweep = cross > 0 ? math.pi / 2 : -math.pi / 2;
      var px = hx + wd * math.cos(start), py = hy + wd * math.sin(start);
      for (var i = 1; i <= 12; i++) {
        final ang = start + sweep * i / 12;
        final qx = hx + wd * math.cos(ang), qy = hy + wd * math.sin(ang);
        line('DOORS', px, py, qx, qy);
        px = qx;
        py = qy;
      }
    }

    // الأعمدة
    if (p.options.columns) {
      for (final c in p.columns) {
        final h = c.size / 2;
        rect('COLUMNS', c.x - h, c.y - h, c.size, c.size);
        line('COLUMNS', c.x - h, c.y - h, c.x + h, c.y + h);
        line('COLUMNS', c.x - h, c.y + h, c.x + h, c.y - h);
      }
    }

    // الأثاث
    if (p.options.furniture) {
      for (final f in p.furniture) {
        final pl = p.placeFurniture(f);
        if (pl == null) continue;
        final r = pl.rect;
        rect('FURNITURE', r.left, r.top, r.width, r.height);
      }
    }

    // أسماء الغرف
    for (final r in p.rooms) {
      text('TEXT', r.x + r.w / 2, r.y + r.h / 2 - 0.1, 0.22, r.name);
      text('TEXT', r.x + r.w / 2, r.y + r.h / 2 + 0.3, 0.18,
          '${fmtM(r.area, 1)} m2  (${fmtM(r.w)} x ${fmtM(r.h)})');
    }

    // الأبعاد الكلية
    if (p.options.dims) {
      line('DIMS', 0, -0.7, p.plotW, -0.7);
      line('DIMS', 0, -0.85, 0, -0.55);
      line('DIMS', p.plotW, -0.85, p.plotW, -0.55);
      text('DIMS', p.plotW / 2, -1.1, 0.25, '${fmtM(p.plotW)} m');
      line('DIMS', -0.7, 0, -0.7, p.plotL);
      line('DIMS', -0.85, 0, -0.55, 0);
      line('DIMS', -0.85, p.plotL, -0.55, p.plotL);
      text('DIMS', -1.3, p.plotL / 2, 0.25, '${fmtM(p.plotL)} m');
    }
    text('TEXT', p.plotW / 2, p.plotL + 1.2, 0.35,
        p.title.isEmpty ? 'Floor plan' : p.title);

    g(0, 'ENDSEC');
    g(0, 'EOF');
    return out.toString();
  }

  static Future<void> shareDxf(FloorPlan p) async {
    final f = await _tmp('plan_${_stamp()}.dxf', buildDxf(p).codeUnits);
    await Share.shareXFiles([XFile(f.path, mimeType: 'application/octet-stream')]);
  }
}
