import 'dart:convert';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/theme/app_theme.dart';
import 'plan_models.dart';
import 'plan_painter.dart';
import 'plan_prompt.dart';
import 'plan_viewer.dart';

class _Msg {
  final bool user;
  String text;
  final List<AiFile> files;
  final PlanAiResult? res;
  final bool error;
  final String? planJson; // لقطة المخطط بعد هذه الرسالة
  final List<PlanIssue> issues;
  _Msg(this.user, this.text,
      {this.files = const [],
      this.res,
      this.error = false,
      this.planJson,
      this.issues = const []});
}

/// مولد المخططات: حوار مع مصمم معماري ذكي، يرسم التطبيق مخططه ويتحقق منه.
class PlanChatScreen extends StatefulWidget {
  final FloorPlan? existing;
  const PlanChatScreen({super.key, this.existing});
  @override
  State<PlanChatScreen> createState() => _PlanChatScreenState();
}

class _PlanChatScreenState extends State<PlanChatScreen> {
  static const _maxBytes = 18 * 1024 * 1024;
  static const _starters = [
    'أريد تصميم فيلا سكنية في السعودية، سأعطيك أبعاد الأرض والمتطلبات',
    'أريد تصميم بيت يمني على أرض مستطيلة، اسألني عمّا تحتاجه',
    'هذه صورة أرضي/مخطط المساحة المرفق، اقترح توزيعاً للغرف',
    'صمم لي شقة سكنية بغرفتي نوم وصالة ومطبخ',
  ];

  final _ctl = TextEditingController();
  final _scroll = ScrollController();
  final List<_Msg> _msgs = [];
  final List<AiFile> _pending = [];
  FloorPlan? _plan;
  late final String? _initialJson;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _plan = widget.existing;
    _initialJson = widget.existing?.toJsonString();
  }

  @override
  void dispose() {
    _ctl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  int get _usedBytes {
    var t = 0;
    for (final m in _msgs) {
      for (final f in m.files) {
        t += f.bytes.length;
      }
    }
    for (final f in _pending) {
      t += f.bytes.length;
    }
    return t;
  }

  void _scrollEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  // ---------------- المرفقات ----------------
  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('كاميرا'),
              subtitle: const Text('تصوير مخطط أو أرض'),
              onTap: () => Navigator.pop(ctx, 'cam'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('صور من المعرض'),
              onTap: () => Navigator.pop(ctx, 'img'),
            ),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: const Text('ملف PDF'),
              onTap: () => Navigator.pop(ctx, 'pdf'),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    try {
      final added = <AiFile>[];
      if (choice == 'cam') {
        final x = await ImagePicker()
            .pickImage(source: ImageSource.camera, maxWidth: 2600, imageQuality: 90);
        if (x != null) added.add(AiFile(x.name, 'image/jpeg', await x.readAsBytes()));
      } else if (choice == 'img') {
        final xs = await ImagePicker().pickMultiImage(maxWidth: 2600, imageQuality: 90);
        for (final x in xs) {
          final png = x.name.toLowerCase().endsWith('.png');
          added.add(AiFile(x.name, png ? 'image/png' : 'image/jpeg', await x.readAsBytes()));
        }
      } else {
        final x = await openFile(acceptedTypeGroups: [
          const XTypeGroup(
              label: 'PDF', extensions: ['pdf'], mimeTypes: ['application/pdf'])
        ]);
        if (x != null) added.add(AiFile(x.name, 'application/pdf', await x.readAsBytes()));
      }
      if (added.isEmpty) return;
      final add = added.fold<int>(0, (a, f) => a + f.bytes.length);
      if (_usedBytes + add > _maxBytes) {
        _msg('حجم الملفات كبير (الحد حوالي 18 ميجابايت).');
        return;
      }
      setState(() => _pending.addAll(added));
    } catch (e) {
      _msg('تعذّر إرفاق الملف.\nالسبب: $e');
    }
  }

  // ---------------- بناء أدوار المحادثة ----------------
  List<AiTurn> _buildTurns() {
    var lastPlanIdx = -1;
    for (var i = 0; i < _msgs.length; i++) {
      if (!_msgs[i].user && _msgs[i].res?.plan != null) lastPlanIdx = i;
    }
    final turns = <AiTurn>[];
    for (var i = 0; i < _msgs.length; i++) {
      final m = _msgs[i];
      if (m.error) continue;
      var text = m.text;
      if (!m.user && m.res != null) {
        text = (m.res!.plan != null && i != lastPlanIdx) ? '(مخطط سابق)' : m.res!.raw;
      }
      final role = m.user ? 'user' : 'assistant';
      if (turns.isNotEmpty && turns.last.role == role) {
        final prev = turns.removeLast();
        turns.add(AiTurn(role, '${prev.text}\n\n$text', [...prev.files, ...m.files]));
      } else {
        turns.add(AiTurn(role, text, m.files));
      }
    }
    if (_plan != null && turns.isNotEmpty && turns.last.role == 'user') {
      final last = turns.removeLast();
      turns.add(AiTurn(
          'user',
          '${last.text}\n\n[المخطط الحالي (بعد أي تعديل):\n${jsonEncode({'plan': _plan!.toJson()})}\n]',
          last.files));
    }
    return turns;
  }

  // ---------------- الإرسال ----------------
  Future<void> _send([String? preset]) async {
    final text = (preset ?? _ctl.text).trim();
    if ((text.isEmpty && _pending.isEmpty) || _busy) return;
    setState(() {
      _msgs.add(_Msg(true, text, files: List.of(_pending)));
      _pending.clear();
      _ctl.clear();
    });
    await _ask();
  }

  Future<void> _ask() async {
    setState(() => _busy = true);
    _scrollEnd();
    try {
      final turns = _buildTurns();
      var raw = await AiTextService.chatFiles(kPlanSystem, turns, maxTokens: 16000);
      var res = PlanAiResult.parse(raw);
      var issues = <PlanIssue>[];

      // تصحيح آلي لمشاكل التداخل والحدود (حتى جولتين)
      for (var round = 0; round < 2 && res.plan != null; round++) {
        issues = res.plan!.validate();
        final hard = issues.where((x) => x.hard).toList();
        if (hard.isEmpty) break;
        try {
          final fixTurns = [
            ...turns,
            AiTurn('assistant', raw),
            AiTurn('user',
                'اكتشف التطبيق مشاكل هندسية في المخطط:\n${hard.map((e) => '- ${e.text}').join('\n')}\nأعد المخطط مصححاً كاملاً (status="ready") بنفس الأبعاد المعتمدة.'),
          ];
          final raw2 = await AiTextService.chatFiles(kPlanSystem, fixTurns, maxTokens: 16000);
          final res2 = PlanAiResult.parse(raw2);
          if (res2.plan == null) break;
          final issues2 = res2.plan!.validate();
          if (issues2.where((x) => x.hard).length <= hard.length) {
            raw = raw2;
            res = res2;
            issues = issues2;
          } else {
            break;
          }
        } catch (_) {
          break;
        }
      }
      if (res.plan != null) issues = res.plan!.validate();

      if (!mounted) return;
      String? snap;
      if (res.plan != null) {
        final np = res.plan!;
        if (_plan != null) np.copyMetaFrom(_plan!, keepOptions: !res.optionsGiven);
        _plan = np;
        snap = np.toJsonString();
        await PlanStore.save(np);
      }
      setState(() {
        _msgs.add(_Msg(false, res.message,
            res: res, planJson: snap, issues: issues));
      });
    } on AiException catch (e) {
      if (mounted) setState(() => _msgs.add(_Msg(false, e.message, error: true)));
    } on FormatException catch (e) {
      final src = e.source is String ? e.source as String : '';
      final head = src.length > 400 ? src.substring(0, 400) : src;
      if (mounted) {
        setState(() => _msgs.add(_Msg(false,
            'لم أستطع فهم رد النموذج. أعد المحاولة أو بسّط الطلب.${head.isEmpty ? '' : '\n\nبداية الرد:\n$head'}',
            error: true)));
      }
    } catch (e) {
      if (mounted) setState(() => _msgs.add(_Msg(false, 'حدث خطأ: $e', error: true)));
    } finally {
      if (mounted) setState(() => _busy = false);
      _scrollEnd();
    }
  }

  // ---------------- قائمة الرسالة (تعديل / نسخ / حذف) ----------------
  Future<void> _userMenu(int i) async {
    final m = _msgs[i];
    final act = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('تعديل'),
                onTap: () => Navigator.pop(ctx, 'edit')),
            ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('نسخ'),
                onTap: () => Navigator.pop(ctx, 'copy')),
            ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('حذف هذه الرسالة وما بعدها'),
                onTap: () => Navigator.pop(ctx, 'del')),
          ],
        ),
      ),
    );
    if (act == null || _busy) return;
    if (act == 'copy') {
      await Clipboard.setData(ClipboardData(text: m.text));
      if (mounted) _msg('تم النسخ');
      return;
    }
    if (act == 'del') {
      _truncate(i);
      return;
    }
    final c = TextEditingController(text: m.text);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الرسالة'),
        content: TextField(controller: c, minLines: 2, maxLines: 8, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إرسال')),
        ],
      ),
    );
    final newText = c.text.trim();
    c.dispose();
    if (ok != true || (newText.isEmpty && m.files.isEmpty)) return;
    final files = m.files;
    _truncate(i);
    setState(() => _msgs.add(_Msg(true, newText, files: files)));
    await _ask();
  }

  /// يحذف الرسائل من الفهرس i فصاعداً ويعيد المخطط لحالته قبلها.
  void _truncate(int i) {
    setState(() {
      _msgs.removeRange(i, _msgs.length);
      String? json = _initialJson;
      for (final m in _msgs.reversed) {
        if (!m.user && m.planJson != null) {
          json = m.planJson;
          break;
        }
      }
      if (json == null) {
        _plan = null;
      } else {
        try {
          final keepId = _plan?.id;
          _plan = FloorPlan.fromJson(Map<String, dynamic>.from(jsonDecode(json) as Map));
          if (keepId != null) _plan!.id = keepId;
        } catch (_) {}
      }
    });
  }

  void _openViewer([FloorPlan? p]) {
    final plan = p ?? _plan;
    if (plan == null) return;
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => PlanViewer(plan: plan)))
        .then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مولد المخططات'),
        actions: [
          if (_plan != null)
            IconButton(
              tooltip: 'فتح المخطط',
              icon: const Icon(Icons.architecture),
              onPressed: _openViewer,
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _msgs.isEmpty ? _empty() : _list()),
          if (_pending.isNotEmpty) _pendingBar(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _empty() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Icon(Icons.architecture, size: 44),
        const SizedBox(height: 10),
        Text('صمّم مخططك بالحوار',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text(
          'أعطني أبعاد الأرض وطلباتك (أو أرفق صورتها). سأسألك عمّا ينقص ولن أفترضه، ثم أرسم المخطط بالأثاث والأعمدة، ونتناقش ونعدّله معاً، وتصدّره PDF أو صورة أو DXF.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.7, fontSize: 13.5),
        ),
        const SizedBox(height: 16),
        for (final s in _starters)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                title: Text(s, style: const TextStyle(fontSize: 14)),
                trailing: const Icon(Icons.north_west, size: 18),
                onTap: () => setState(() => _ctl.text = s),
              ),
            ),
          ),
      ],
    );
  }

  Widget _list() {
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(12),
      itemCount: _msgs.length + (_busy ? 1 : 0),
      itemBuilder: (context, i) {
        if (i == _msgs.length) return _typing();
        return _bubble(i);
      },
    );
  }

  Widget _typing() => Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            SizedBox(
                height: 16,
                width: 16,
                child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 10),
            Text('أصمّم وأتحقق من المخطط...'),
          ]),
        ),
      );

  Widget _bubble(int i) {
    final m = _msgs[i];
    final maxW = MediaQuery.of(context).size.width * 0.88;
    if (m.user) {
      return Align(
        alignment: AlignmentDirectional.centerStart,
        child: GestureDetector(
          onLongPress: () => _userMenu(i),
          child: Container(
            constraints: BoxConstraints(maxWidth: maxW),
            margin: const EdgeInsets.symmetric(vertical: 5),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.ink,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (m.files.isNotEmpty)
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final f in m.files)
                        Chip(
                          avatar: Icon(f.isPdf ? Icons.picture_as_pdf : Icons.image, size: 16),
                          label: Text(f.name,
                              style: const TextStyle(fontSize: 11),
                              overflow: TextOverflow.ellipsis),
                          visualDensity: VisualDensity.compact,
                        ),
                    ],
                  ),
                if (m.text.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: m.files.isNotEmpty ? 8 : 0),
                    child: Text(m.text,
                        style: const TextStyle(color: Colors.white, height: 1.5)),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    final res = m.res;
    final plan = (m.planJson == null)
        ? null
        : FloorPlan.fromJson(
            Map<String, dynamic>.from(jsonDecode(m.planJson!) as Map));
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxW),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: m.error ? const Color(0xFFFFF1F0) : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (m.text.isNotEmpty)
              SelectableText(m.text,
                  style: TextStyle(
                      height: 1.6, color: m.error ? const Color(0xFFB42318) : null)),
            if (res != null && res.questions.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Text('أحتاج منك:', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              for (var k = 0; k < res.questions.length; k++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: SelectableText('${k + 1}. ${res.questions[k]}',
                      style: const TextStyle(height: 1.6)),
                ),
              const Text('أجب عنها في رسالتك التالية.', style: TextStyle(fontSize: 12.5)),
            ],
            if (plan != null) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: () => _openViewer(i == _lastPlanIndex() ? _plan : plan),
                child: Container(
                  color: Colors.white,
                  child: LayoutBuilder(builder: (context, c) {
                    final size = PlanPainter.sizeFor(plan, c.maxWidth);
                    return CustomPaint(size: size, painter: PlanPainter(plan));
                  }),
                ),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                children: [
                  FilledButton.tonalIcon(
                    onPressed: () => _openViewer(i == _lastPlanIndex() ? _plan : plan),
                    icon: const Icon(Icons.zoom_out_map),
                    label: const Text('فتح وتصدير'),
                  ),
                ],
              ),
              if (m.issues.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('مراجعة هندسية (${m.issues.length}):',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                for (final x in m.issues.take(6))
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text('${x.hard ? '⛔' : '⚠'} ${x.text}',
                        style: const TextStyle(fontSize: 12.5, height: 1.4)),
                  ),
              ],
              if (plan.notes.isNotEmpty) ...[
                const SizedBox(height: 8),
                for (final n in plan.notes)
                  Text('• $n', style: const TextStyle(fontSize: 12.5, height: 1.5)),
              ],
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                children: [
                  ActionChip(
                    label: const Text('اشرح لي قراراتك', style: TextStyle(fontSize: 12)),
                    onPressed: _busy
                        ? null
                        : () => _send('اشرح لي قراراتك التصميمية في هذا المخطط ولماذا اخترتها، وما البدائل الممكنة؟'),
                  ),
                  ActionChip(
                    label: const Text('أخرجه بدون أثاث وأعمدة', style: TextStyle(fontSize: 12)),
                    onPressed: _busy
                        ? null
                        : () => _send('أخفِ الأثاث والأعمدة من المخطط'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  int _lastPlanIndex() {
    for (var i = _msgs.length - 1; i >= 0; i--) {
      if (!_msgs[i].user && _msgs[i].planJson != null) return i;
    }
    return -1;
  }

  Widget _pendingBar() {
    final mb = (_usedBytes / (1024 * 1024)).toStringAsFixed(1);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              for (var i = 0; i < _pending.length; i++)
                InputChip(
                  avatar: Icon(_pending[i].isPdf ? Icons.picture_as_pdf : Icons.image, size: 16),
                  label: Text(_pending[i].name,
                      style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis),
                  onDeleted: () => setState(() => _pending.removeAt(i)),
                ),
            ],
          ),
          Text('الحجم الكلي المرسل: $mb ميجابايت (الحد 18)', style: const TextStyle(fontSize: 11)),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'إرفاق',
              icon: const Icon(Icons.attach_file),
              onPressed: _busy ? null : _attach,
            ),
            Expanded(
              child: TextField(
                controller: _ctl,
                minLines: 1,
                maxLines: 6,
                decoration: const InputDecoration(
                  hintText: 'اكتب طلبك أو ملاحظتك على المخطط...',
                  contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filled(
              onPressed: _busy ? null : () => _send(),
              style: IconButton.styleFrom(
                  backgroundColor: AppColors.ink, minimumSize: const Size(48, 48)),
              icon: const Icon(Icons.send, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
