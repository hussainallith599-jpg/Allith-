import 'package:flutter/material.dart';
import 'plan_chat_screen.dart';
import 'plan_models.dart';
import 'plan_viewer.dart';

/// المخططات المحفوظة + إنشاء مخطط جديد بالحوار.
class PlansHub extends StatefulWidget {
  const PlansHub({super.key});
  @override
  State<PlansHub> createState() => _PlansHubState();
}

class _PlansHubState extends State<PlansHub> {
  List<FloorPlan> _list = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final l = await PlanStore.load();
    if (!mounted) return;
    setState(() {
      _list = l;
      _loading = false;
    });
  }

  Future<void> _new([FloorPlan? existing]) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => PlanChatScreen(existing: existing)));
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مولد المخططات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _new(),
        icon: const Icon(Icons.architecture),
        label: const Text('مخطط جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _list.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'لا توجد مخططات بعد.\nاضغط "مخطط جديد" وابدأ الحوار مع المصمم الذكي.',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.7),
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                  itemCount: _list.length,
                  itemBuilder: (context, i) {
                    final p = _list[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          leading: const Icon(Icons.architecture, size: 30),
                          title: Text(p.title.isEmpty ? 'مخطط' : p.title,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              '${p.level} • ${fmtM(p.plotW)}×${fmtM(p.plotL)} م • ${p.rooms.length} غرفة'),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'chat') {
                                _new(p);
                              } else if (v == 'del') {
                                await PlanStore.delete(p.id);
                                _reload();
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'chat', child: Text('متابعة الحوار وتعديله')),
                              PopupMenuItem(value: 'del', child: Text('حذف')),
                            ],
                          ),
                          onTap: () async {
                            await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => PlanViewer(plan: p)));
                            _reload();
                          },
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
