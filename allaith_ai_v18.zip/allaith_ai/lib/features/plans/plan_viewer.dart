import 'package:flutter/material.dart';
import 'plan_export.dart';
import 'plan_models.dart';
import 'plan_painter.dart';

/// عرض المخطط مع تكبير وتصغير، وخيارات الإظهار، والتحقق الهندسي، والتصدير.
class PlanViewer extends StatefulWidget {
  final FloorPlan plan;
  const PlanViewer({super.key, required this.plan});
  @override
  State<PlanViewer> createState() => _PlanViewerState();
}

class _PlanViewerState extends State<PlanViewer> {
  late final FloorPlan p = widget.plan;
  bool _busy = false;

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _toggle(void Function(PlanOptions) f) async {
    setState(() => f(p.options));
    await PlanStore.save(p);
  }

  Future<void> _export(Future<void> Function(FloorPlan) fn, String err) async {
    setState(() => _busy = true);
    try {
      await fn(p);
    } catch (e) {
      if (mounted) _msg('$err\nالسبب: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _chip(String label, bool value, void Function(PlanOptions) f) {
    return FilterChip(
      label: Text(label, style: const TextStyle(fontSize: 12.5)),
      selected: value,
      onSelected: (_) => _toggle(f),
      visualDensity: VisualDensity.compact,
    );
  }

  @override
  Widget build(BuildContext context) {
    final issues = p.validate();
    final o = p.options;
    return Scaffold(
      appBar: AppBar(title: Text(p.title.isEmpty ? 'المخطط' : p.title)),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: Container(
              color: Colors.white,
              child: LayoutBuilder(builder: (context, c) {
                final size = PlanPainter.sizeFor(p, c.maxWidth);
                return InteractiveViewer(
                  minScale: 0.8,
                  maxScale: 8,
                  child: Center(
                    child: CustomPaint(size: size, painter: PlanPainter(p)),
                  ),
                );
              }),
            ),
          ),
          Expanded(
            flex: 4,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 20),
              children: [
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    _chip('الأعمدة', o.columns, (x) => x.columns = !x.columns),
                    _chip('الأثاث', o.furniture, (x) => x.furniture = !x.furniture),
                    _chip('الأبعاد', o.dims, (x) => x.dims = !x.dims),
                    _chip('أسماء الغرف', o.labels, (x) => x.labels = !x.labels),
                    _chip('الشبكة', o.grid, (x) => x.grid = !x.grid),
                  ],
                ),
                const SizedBox(height: 10),
                if (_busy)
                  const Center(child: CircularProgressIndicator())
                else
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: () => _export(PlanExport.sharePdf,
                            'تعذّر إنشاء PDF. تأكد من الإنترنت (لتحميل الخط).'),
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: const Text('PDF'),
                      ),
                      FilledButton.icon(
                        onPressed: () =>
                            _export(PlanExport.sharePng, 'تعذّر إنشاء الصورة.'),
                        icon: const Icon(Icons.image_outlined),
                        label: const Text('صورة'),
                      ),
                      FilledButton.icon(
                        onPressed: () =>
                            _export(PlanExport.shareDxf, 'تعذّر إنشاء DXF.'),
                        icon: const Icon(Icons.architecture),
                        label: const Text('DXF (AutoCAD)'),
                      ),
                    ],
                  ),
                const SizedBox(height: 6),
                const Text(
                  'ملف DXF يفتحه AutoCAD وBricsCAD، ويمكنك حفظه بصيغة DWG من البرنامج.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 10),
                Text('المراجعة الهندسية (${issues.length})',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                if (issues.isEmpty)
                  const Text('لا توجد مشاكل مكتشفة في الفحص الآلي.',
                      style: TextStyle(fontSize: 13)),
                for (final i in issues)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(i.hard ? Icons.error_outline : Icons.info_outline,
                            size: 16,
                            color: i.hard ? Colors.red : Colors.orange),
                        const SizedBox(width: 6),
                        Expanded(
                            child: Text(i.text,
                                style: const TextStyle(fontSize: 12.5, height: 1.4))),
                      ],
                    ),
                  ),
                if (p.notes.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  const Text('ملاحظات المصمم',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  for (final n in p.notes)
                    Text('• $n', style: const TextStyle(fontSize: 12.5, height: 1.5)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
