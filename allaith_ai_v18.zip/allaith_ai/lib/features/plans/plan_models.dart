import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' show Rect;
import 'package:shared_preferences/shared_preferences.dart';

double? _d(dynamic v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.replaceAll(',', '.'));
  return null;
}

String _s(dynamic v) => v == null ? '' : v.toString().trim();

String fmtM(double v, [int d = 2]) {
  final s = v.toStringAsFixed(d);
  if (!s.contains('.')) return s;
  return s.replaceFirst(RegExp(r'\.?0+$'), '');
}

const Map<String, String> kRoomTypeAr = {
  'bedroom': 'غرفة نوم',
  'master_bedroom': 'غرفة نوم رئيسية',
  'living': 'صالة معيشة',
  'majlis_men': 'مجلس رجال',
  'majlis_women': 'مجلس نساء',
  'dining': 'غرفة طعام',
  'kitchen': 'مطبخ',
  'bathroom': 'حمام',
  'toilet': 'دورة مياه',
  'corridor': 'ممر',
  'entrance': 'مدخل',
  'stairs': 'درج',
  'laundry': 'غسيل',
  'store': 'مخزن',
  'maid': 'غرفة خادمة',
  'courtyard': 'حوش/فناء',
  'garage': 'مواقف',
  'office': 'مكتب',
  'other': 'أخرى',
};

/// أحجام الأثاث الافتراضية: [العرض بمحاذاة الجدار, العمق] بالمتر.
const Map<String, List<double>> kFurnSizes = {
  'bed_double': [1.6, 2.0],
  'bed_king': [1.9, 2.1],
  'bed_single': [1.0, 2.0],
  'wardrobe': [1.8, 0.6],
  'bedside': [0.45, 0.4],
  'dresser': [1.2, 0.5],
  'sofa': [2.0, 0.9],
  'sofa_corner': [2.6, 0.9],
  'armchair': [0.9, 0.9],
  'coffee_table': [1.0, 0.6],
  'tv_unit': [1.6, 0.4],
  'dining_table': [1.6, 0.9],
  'dining_table_8': [2.4, 1.0],
  'chair': [0.45, 0.45],
  'desk': [1.4, 0.7],
  'bookshelf': [1.2, 0.35],
  'kitchen_counter': [2.4, 0.6],
  'fridge': [0.7, 0.7],
  'stove': [0.6, 0.6],
  'sink': [0.8, 0.5],
  'island': [1.8, 0.9],
  'wc': [0.4, 0.7],
  'basin': [0.55, 0.45],
  'shower': [0.9, 0.9],
  'bathtub': [1.7, 0.75],
  'washing_machine': [0.6, 0.6],
  'majlis': [3.0, 0.8],
  'stairs': [1.0, 3.0],
  'car': [2.0, 4.6],
};

class PlanRoom {
  String id, name, type;
  double x, y, w, h;
  PlanRoom(this.id, this.name, this.type, this.x, this.y, this.w, this.h);

  double get area => w * h;
  Rect get rect => Rect.fromLTWH(x, y, w, h);

  factory PlanRoom.fromJson(Map<String, dynamic> j) => PlanRoom(
        _s(j['id']),
        _s(j['name']),
        _s(j['type']).isEmpty ? 'other' : _s(j['type']),
        _d(j['x']) ?? 0,
        _d(j['y']) ?? 0,
        _d(j['w']) ?? 0,
        _d(j['h']) ?? 0,
      );

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'type': type, 'x': x, 'y': y, 'w': w, 'h': h};
}

class PlanDoor {
  String room, wall, to, swing, hinge;
  double offset, width;
  PlanDoor(this.room, this.wall, this.offset, this.width, this.to, this.swing,
      this.hinge);

  factory PlanDoor.fromJson(Map<String, dynamic> j) => PlanDoor(
        _s(j['room']),
        _s(j['wall']).toUpperCase(),
        _d(j['offset']) ?? 0,
        _d(j['width']) ?? 0.9,
        _s(j['to']),
        _s(j['swing']).isEmpty ? 'in' : _s(j['swing']).toLowerCase(),
        _s(j['hinge']).isEmpty ? 'start' : _s(j['hinge']).toLowerCase(),
      );

  Map<String, dynamic> toJson() => {
        'room': room,
        'wall': wall,
        'offset': offset,
        'width': width,
        'to': to,
        'swing': swing,
        'hinge': hinge,
      };
}

class PlanWindow {
  String room, wall;
  double offset, width;
  PlanWindow(this.room, this.wall, this.offset, this.width);

  factory PlanWindow.fromJson(Map<String, dynamic> j) => PlanWindow(
        _s(j['room']),
        _s(j['wall']).toUpperCase(),
        _d(j['offset']) ?? 0,
        _d(j['width']) ?? 1.2,
      );

  Map<String, dynamic> toJson() =>
      {'room': room, 'wall': wall, 'offset': offset, 'width': width};
}

class PlanColumn {
  double x, y, size;
  PlanColumn(this.x, this.y, this.size);

  factory PlanColumn.fromJson(Map<String, dynamic> j) =>
      PlanColumn(_d(j['x']) ?? 0, _d(j['y']) ?? 0, _d(j['size']) ?? 0.3);

  Map<String, dynamic> toJson() => {'x': x, 'y': y, 'size': size};
}

class PlanFurn {
  String room, type, wall, align, label;
  double? offset, w, d, dx, dy, rot;
  double gap;
  PlanFurn(this.room, this.type, this.wall, this.align, this.label, this.offset,
      this.w, this.d, this.dx, this.dy, this.rot, this.gap);

  factory PlanFurn.fromJson(Map<String, dynamic> j) => PlanFurn(
        _s(j['room']),
        _s(j['type']).toLowerCase(),
        _s(j['wall']).toUpperCase(),
        _s(j['align']).toLowerCase(),
        _s(j['label']),
        _d(j['offset']),
        _d(j['w']),
        _d(j['d']),
        _d(j['dx']),
        _d(j['dy']),
        _d(j['rot']),
        _d(j['gap']) ?? 0.05,
      );

  Map<String, dynamic> toJson() => {
        'room': room,
        'type': type,
        'wall': wall,
        'align': align,
        'label': label,
        'offset': offset,
        'w': w,
        'd': d,
        'dx': dx,
        'dy': dy,
        'rot': rot,
        'gap': gap,
      };
}

class PlanOptions {
  bool columns, furniture, dims, labels, grid;
  PlanOptions(
      {this.columns = true,
      this.furniture = true,
      this.dims = true,
      this.labels = true,
      this.grid = false});

  PlanOptions copy() => PlanOptions(
      columns: columns,
      furniture: furniture,
      dims: dims,
      labels: labels,
      grid: grid);

  Map<String, dynamic> toJson() => {
        'columns': columns,
        'furniture': furniture,
        'dims': dims,
        'labels': labels,
        'grid': grid,
      };

  void merge(Map<String, dynamic> j) {
    if (j['columns'] is bool) columns = j['columns'] as bool;
    if (j['furniture'] is bool) furniture = j['furniture'] as bool;
    if (j['dims'] is bool) dims = j['dims'] as bool;
    if (j['labels'] is bool) labels = j['labels'] as bool;
    if (j['grid'] is bool) grid = j['grid'] as bool;
  }
}

class PlanIssue {
  final String text;
  final bool hard;
  PlanIssue(this.text, this.hard);
}

/// موضع قطعة أثاث محسوب: المستطيل النهائي وعدد أرباع الدوران.
class FurnPlacement {
  final Rect rect;
  final int turns;
  FurnPlacement(this.rect, this.turns);
}

/// فتحة (باب/شباك) بإحداثيات مطلقة على جدار.
class Opening {
  final double x1, y1, x2, y2;
  final bool isDoor;
  final PlanDoor? door;
  Opening(this.x1, this.y1, this.x2, this.y2, this.isDoor, this.door);
}

class FloorPlan {
  String id;
  String title;
  String country;
  String level;
  double plotW, plotL;
  String north; // اتجاه الشمال في الرسم: up/right/down/left
  String street; // جهة الشارع في الرسم: top/bottom/left/right
  double sbTop, sbBottom, sbLeft, sbRight; // الارتدادات
  double maxCoverage; // نسبة البناء القصوى %
  List<PlanRoom> rooms;
  List<PlanDoor> doors;
  List<PlanWindow> windows;
  List<PlanColumn> columns;
  List<PlanFurn> furniture;
  PlanOptions options;
  List<String> notes;
  int updated;

  FloorPlan({
    String? id,
    this.title = '',
    this.country = '',
    this.level = 'الدور الأرضي',
    this.plotW = 0,
    this.plotL = 0,
    this.north = 'up',
    this.street = '',
    this.sbTop = 0,
    this.sbBottom = 0,
    this.sbLeft = 0,
    this.sbRight = 0,
    this.maxCoverage = 0,
    List<PlanRoom>? rooms,
    List<PlanDoor>? doors,
    List<PlanWindow>? windows,
    List<PlanColumn>? columns,
    List<PlanFurn>? furniture,
    PlanOptions? options,
    List<String>? notes,
    int? updated,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        rooms = rooms ?? [],
        doors = doors ?? [],
        windows = windows ?? [],
        columns = columns ?? [],
        furniture = furniture ?? [],
        options = options ?? PlanOptions(),
        notes = notes ?? [],
        updated = updated ?? DateTime.now().millisecondsSinceEpoch;

  bool get valid => plotW > 0 && plotL > 0 && rooms.isNotEmpty;
  double get builtArea => rooms
      .where((r) => r.type != 'courtyard')
      .fold(0.0, (a, r) => a + r.area);
  double get coveragePct =>
      plotW * plotL == 0 ? 0 : builtArea / (plotW * plotL) * 100;

  PlanRoom? roomById(String id) {
    for (final r in rooms) {
      if (r.id == id) return r;
    }
    return null;
  }

  factory FloorPlan.fromJson(Map<String, dynamic> j) {
    final plot = Map<String, dynamic>.from((j['plot'] as Map?) ?? {});
    final sb = Map<String, dynamic>.from((j['setbacks'] as Map?) ?? {});
    final p = FloorPlan(
      title: _s(j['title']),
      country: _s(j['country']),
      level: _s(j['level']).isEmpty ? 'الدور الأرضي' : _s(j['level']),
      plotW: _d(plot['w']) ?? 0,
      plotL: _d(plot['l']) ?? 0,
      north: _s(plot['north']).isEmpty ? 'up' : _s(plot['north']).toLowerCase(),
      street: _s(plot['street']).toLowerCase(),
      sbTop: _d(sb['top']) ?? 0,
      sbBottom: _d(sb['bottom']) ?? 0,
      sbLeft: _d(sb['left']) ?? 0,
      sbRight: _d(sb['right']) ?? 0,
      maxCoverage: _d(j['maxCoverage']) ?? 0,
      rooms: ((j['rooms'] as List?) ?? [])
          .map((e) => PlanRoom.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      doors: ((j['doors'] as List?) ?? [])
          .map((e) => PlanDoor.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      windows: ((j['windows'] as List?) ?? [])
          .map((e) => PlanWindow.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      columns: ((j['columns'] as List?) ?? [])
          .map((e) => PlanColumn.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      furniture: ((j['furniture'] as List?) ?? [])
          .map((e) => PlanFurn.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      notes: ((j['notes'] as List?) ?? [])
          .map((e) => _s(e))
          .where((e) => e.isNotEmpty)
          .toList(),
    );
    if (j['options'] is Map) {
      p.options.merge(Map<String, dynamic>.from(j['options'] as Map));
    }
    return p;
  }

  Map<String, dynamic> toJson() => {
        'title': title,
        'country': country,
        'level': level,
        'plot': {'w': plotW, 'l': plotL, 'north': north, 'street': street},
        'setbacks': {
          'top': sbTop,
          'bottom': sbBottom,
          'left': sbLeft,
          'right': sbRight
        },
        'maxCoverage': maxCoverage,
        'rooms': rooms.map((e) => e.toJson()).toList(),
        'doors': doors.map((e) => e.toJson()).toList(),
        'windows': windows.map((e) => e.toJson()).toList(),
        'columns': columns.map((e) => e.toJson()).toList(),
        'furniture': furniture.map((e) => e.toJson()).toList(),
        'options': options.toJson(),
        'notes': notes,
      };

  String toJsonString() => jsonEncode(toJson());

  /// ينسخ الإعدادات (الأوضاع) والمعرّف من مخطط سابق.
  void copyMetaFrom(FloorPlan o, {bool keepOptions = true}) {
    id = o.id;
    if (keepOptions) options = o.options.copy();
  }

  // ---------------- هندسة ----------------

  Opening openingFor(String roomId, String wall, double offset, double width,
      bool isDoor, PlanDoor? door) {
    final r = roomById(roomId)!;
    switch (wall) {
      case 'N':
        return Opening(r.x + offset, r.y, r.x + offset + width, r.y, isDoor, door);
      case 'S':
        return Opening(r.x + offset, r.y + r.h, r.x + offset + width, r.y + r.h,
            isDoor, door);
      case 'W':
        return Opening(r.x, r.y + offset, r.x, r.y + offset + width, isDoor, door);
      default:
        return Opening(r.x + r.w, r.y + offset, r.x + r.w, r.y + offset + width,
            isDoor, door);
    }
  }

  List<Opening> openings() {
    final out = <Opening>[];
    for (final d in doors) {
      if (roomById(d.room) == null) continue;
      out.add(openingFor(d.room, d.wall, d.offset, d.width, true, d));
    }
    for (final w in windows) {
      if (roomById(w.room) == null) continue;
      out.add(openingFor(w.room, w.wall, w.offset, w.width, false, null));
    }
    return out;
  }

  /// هل الضلع (من نقطة لأخرى) على المحيط الخارجي (غير مشترك مع غرفة أخرى)؟
  bool isExternalEdge(PlanRoom r, String wall) {
    double px, py;
    switch (wall) {
      case 'N':
        px = r.x + r.w / 2;
        py = r.y - 0.06;
        break;
      case 'S':
        px = r.x + r.w / 2;
        py = r.y + r.h + 0.06;
        break;
      case 'W':
        px = r.x - 0.06;
        py = r.y + r.h / 2;
        break;
      default:
        px = r.x + r.w + 0.06;
        py = r.y + r.h / 2;
    }
    for (final o in rooms) {
      if (identical(o, r)) continue;
      if (px >= o.x && px <= o.x + o.w && py >= o.y && py <= o.y + o.h) {
        return false;
      }
    }
    return true;
  }

  FurnPlacement? placeFurniture(PlanFurn f) {
    final r = roomById(f.room);
    if (r == null) return null;
    final sz = kFurnSizes[f.type] ?? [1.0, 1.0];
    final along = f.w ?? sz[0];
    final depth = f.d ?? sz[1];
    final wall = f.wall;
    if (wall.isEmpty || wall == 'C' || wall == 'CENTER') {
      final turns = ((f.rot ?? 0) / 90).round() % 4;
      final odd = turns.isOdd;
      final w = odd ? depth : along;
      final h = odd ? along : depth;
      final cx = r.x + r.w / 2 + (f.dx ?? 0);
      final cy = r.y + r.h / 2 + (f.dy ?? 0);
      return FurnPlacement(Rect.fromLTWH(cx - w / 2, cy - h / 2, w, h), turns);
    }
    final horizontal = wall == 'N' || wall == 'S';
    final len = horizontal ? r.w : r.h;
    double ox;
    if (f.offset != null) {
      ox = f.offset!;
    } else if (f.align == 'start') {
      ox = 0.1;
    } else if (f.align == 'end') {
      ox = len - along - 0.1;
    } else {
      ox = (len - along) / 2;
    }
    switch (wall) {
      case 'N':
        return FurnPlacement(
            Rect.fromLTWH(r.x + ox, r.y + f.gap, along, depth), 0);
      case 'S':
        return FurnPlacement(
            Rect.fromLTWH(r.x + ox, r.y + r.h - depth - f.gap, along, depth), 2);
      case 'W':
        return FurnPlacement(
            Rect.fromLTWH(r.x + f.gap, r.y + ox, depth, along), 3);
      default:
        return FurnPlacement(
            Rect.fromLTWH(r.x + r.w - depth - f.gap, r.y + ox, depth, along), 1);
    }
  }

  // ---------------- التحقق الهندسي ----------------
  List<PlanIssue> validate() {
    final out = <PlanIssue>[];
    const eps = 0.02;
    if (plotW <= 0 || plotL <= 0) {
      out.add(PlanIssue('أبعاد الأرض غير محددة.', true));
      return out;
    }
    if (rooms.isEmpty) {
      out.add(PlanIssue('لا توجد غرف في المخطط.', true));
      return out;
    }
    final ids = <String>{};
    for (final r in rooms) {
      if (!ids.add(r.id)) {
        out.add(PlanIssue('معرّف الغرفة "${r.id}" مكرر.', true));
      }
      if (r.w <= 0 || r.h <= 0) {
        out.add(PlanIssue('الغرفة "${r.name}" بأبعاد غير صالحة.', true));
        continue;
      }
      if (r.x < -eps ||
          r.y < -eps ||
          r.x + r.w > plotW + eps ||
          r.y + r.h > plotL + eps) {
        out.add(PlanIssue('الغرفة "${r.name}" تخرج عن حدود الأرض.', true));
      }
      if (sbLeft + sbRight + sbTop + sbBottom > 0 &&
          r.type != 'courtyard' &&
          (r.x < sbLeft - eps ||
              r.y < sbTop - eps ||
              r.x + r.w > plotW - sbRight + eps ||
              r.y + r.h > plotL - sbBottom + eps)) {
        out.add(PlanIssue('الغرفة "${r.name}" تدخل في منطقة الارتداد.', true));
      }
    }
    for (var i = 0; i < rooms.length; i++) {
      for (var k = i + 1; k < rooms.length; k++) {
        final a = rooms[i].rect, b = rooms[k].rect;
        final iw = math.min(a.right, b.right) - math.max(a.left, b.left);
        final ih = math.min(a.bottom, b.bottom) - math.max(a.top, b.top);
        if (iw > 0.05 && ih > 0.05 && iw * ih > 0.05) {
          out.add(PlanIssue(
              'تداخل بين "${rooms[i].name}" و"${rooms[k].name}" (${fmtM(iw * ih)} م²).',
              true));
        }
      }
    }
    if (maxCoverage > 0 && coveragePct > maxCoverage + 0.5) {
      out.add(PlanIssue(
          'نسبة البناء ${fmtM(coveragePct, 1)}% تتجاوز الحد ${fmtM(maxCoverage, 1)}%.',
          true));
    }
    const habitable = {
      'bedroom',
      'master_bedroom',
      'living',
      'majlis_men',
      'majlis_women',
      'dining',
      'maid',
      'office'
    };
    for (final r in rooms) {
      if (habitable.contains(r.type) && (r.area < 9 || math.min(r.w, r.h) < 2.4)) {
        out.add(PlanIssue(
            'الغرفة "${r.name}" صغيرة (${fmtM(r.area)} م² وأقل ضلع ${fmtM(math.min(r.w, r.h))} م) — عرف تصميمي شائع يطلب غالباً 9 م² و2.4 م على الأقل، فراجع اشتراطات البلدية.',
            false));
      }
    }
    for (final d in doors) {
      final r = roomById(d.room);
      if (r == null) {
        out.add(PlanIssue('باب يشير إلى غرفة غير موجودة "${d.room}".', true));
        continue;
      }
      final len = (d.wall == 'N' || d.wall == 'S') ? r.w : r.h;
      if (d.width < 0.6 || d.width > 2.6) {
        out.add(PlanIssue('عرض باب غير معقول في "${r.name}" (${fmtM(d.width)} م).', false));
      }
      if (d.offset < -eps || d.offset + d.width > len + eps) {
        out.add(PlanIssue('باب في "${r.name}" يخرج عن طول الجدار.', true));
      }
    }
    for (final w in windows) {
      final r = roomById(w.room);
      if (r == null) {
        out.add(PlanIssue('شباك يشير إلى غرفة غير موجودة "${w.room}".', true));
        continue;
      }
      final len = (w.wall == 'N' || w.wall == 'S') ? r.w : r.h;
      if (w.offset < -eps || w.offset + w.width > len + eps) {
        out.add(PlanIssue('شباك في "${r.name}" يخرج عن طول الجدار.', true));
      }
    }
    const needNoDoor = {'courtyard', 'garage'};
    for (final r in rooms) {
      if (needNoDoor.contains(r.type)) continue;
      if (!doors.any((d) => d.room == r.id || d.to == r.id)) {
        out.add(PlanIssue('الغرفة "${r.name}" بلا باب يوصل إليها.', false));
      }
    }
    if (!doors.any((d) => d.to.toLowerCase() == 'outside')) {
      out.add(PlanIssue('لا يوجد باب مدخل خارجي (to = outside).', false));
    }
    const needWindow = {
      'bedroom',
      'master_bedroom',
      'living',
      'majlis_men',
      'majlis_women',
      'dining',
      'kitchen',
      'maid',
      'office'
    };
    for (final r in rooms) {
      if (needWindow.contains(r.type) && !windows.any((w) => w.room == r.id)) {
        out.add(PlanIssue('الغرفة "${r.name}" بلا شباك (تهوية وإضاءة طبيعية).', false));
      }
    }
    for (final f in furniture) {
      final r = roomById(f.room);
      if (r == null) continue;
      final pl = placeFurniture(f);
      if (pl == null) continue;
      final rr = pl.rect;
      if (rr.left < r.x - 0.05 ||
          rr.top < r.y - 0.05 ||
          rr.right > r.x + r.w + 0.05 ||
          rr.bottom > r.y + r.h + 0.05) {
        out.add(PlanIssue(
            'قطعة أثاث (${f.type}) لا تتسع داخل "${r.name}".', false));
      }
    }
    return out;
  }
}

enum PlanStatus { needInfo, ready, message }

class PlanAiResult {
  final PlanStatus status;
  final String message;
  final List<String> questions;
  final FloorPlan? plan;
  final bool optionsGiven;
  final String raw;
  PlanAiResult(this.status, this.message, this.questions, this.plan,
      this.optionsGiven, this.raw);

  static PlanAiResult parse(String raw) {
    var clean = raw.trim().replaceAll('```json', '').replaceAll('```', '');
    final a = clean.indexOf('{');
    final b = clean.lastIndexOf('}');
    if (a < 0 || b <= a) throw FormatException('no json', raw);
    final Map<String, dynamic> m;
    try {
      m = Map<String, dynamic>.from(jsonDecode(clean.substring(a, b + 1)) as Map);
    } catch (_) {
      throw FormatException('bad json', raw);
    }
    final questions = ((m['questions'] as List?) ?? [])
        .map((e) => _s(e))
        .where((e) => e.isNotEmpty)
        .toList();
    FloorPlan? plan;
    var optionsGiven = false;
    if (m['plan'] is Map) {
      final pm = Map<String, dynamic>.from(m['plan'] as Map);
      optionsGiven = pm['options'] is Map;
      plan = FloorPlan.fromJson(pm);
      if (!plan.valid) plan = null;
    }
    final st = _s(m['status']);
    final status = (st == 'need_info' || (questions.isNotEmpty && plan == null))
        ? PlanStatus.needInfo
        : (plan != null ? PlanStatus.ready : PlanStatus.message);
    return PlanAiResult(status, _s(m['message']), questions, plan, optionsGiven,
        clean.substring(a, b + 1));
  }
}

class PlanStore {
  static const _key = 'floor_plans_v1';

  static Future<List<FloorPlan>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final l = (jsonDecode(raw) as List).map((e) {
        final m = Map<String, dynamic>.from(e);
        final plan = FloorPlan.fromJson(Map<String, dynamic>.from(m['plan'] as Map));
        plan.id = _s(m['id']);
        plan.updated = (m['updated'] as int?) ?? 0;
        return plan;
      }).toList();
      l.sort((a, b) => b.updated.compareTo(a.updated));
      return l;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<FloorPlan> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _key,
        jsonEncode(l
            .map((e) => {'id': e.id, 'updated': e.updated, 'plan': e.toJson()})
            .toList()));
  }

  static Future<void> save(FloorPlan pl) async {
    final l = await load();
    pl.updated = DateTime.now().millisecondsSinceEpoch;
    final i = l.indexWhere((x) => x.id == pl.id);
    if (i >= 0) {
      l[i] = pl;
    } else {
      l.add(pl);
    }
    await _write(l);
  }

  static Future<void> delete(String id) async {
    final l = await load();
    l.removeWhere((x) => x.id == id);
    await _write(l);
  }
}
