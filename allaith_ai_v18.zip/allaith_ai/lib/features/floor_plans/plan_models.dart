import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

double _n(dynamic v, [double d = 0]) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.replaceAll(',', '.')) ?? d;
  return d;
}

String _s(dynamic v) => v == null ? '' : v.toString().trim();

/// تقريب لأقرب 5 سم لتفادي الفجوات الصغيرة بين الغرف المتجاورة.
double snap(double v) => (v * 20).round() / 20;

const Map<String, String> kRoomTypes = {
  'living': 'صالة معيشة',
  'bedroom': 'غرفة نوم',
  'master_bedroom': 'غرفة نوم رئيسية',
  'bath': 'حمام',
  'wc': 'دورة مياه',
  'kitchen': 'مطبخ',
  'majlis': 'مجلس',
  'dining': 'سفرة',
  'corridor': 'ممر',
  'stair': 'درج',
  'maid': 'غرفة خادمة',
  'driver': 'غرفة سائق',
  'garage': 'موقف سيارات',
  'courtyard': 'فناء',
  'storage': 'مخزن',
  'laundry': 'غسيل',
  'office': 'مكتب',
  'entrance': 'مدخل',
  'lightwell': 'منور',
  'roof': 'سطح',
  'other': 'أخرى',
};

const Map<String, String> kFurnitureNames = {
  'bed_double': 'سرير مزدوج',
  'bed_single': 'سرير مفرد',
  'sofa': 'كنبة',
  'armchair': 'كرسي',
  'coffee_table': 'طاولة وسط',
  'dining_table': 'طاولة سفرة',
  'chair': 'كرسي',
  'wardrobe': 'دولاب',
  'desk': 'مكتب',
  'tv_unit': 'وحدة تلفاز',
  'counter': 'خزانة مطبخ',
  'sink_counter': 'حوض مطبخ',
  'stove': 'طباخ',
  'fridge': 'ثلاجة',
  'island': 'جزيرة',
  'wc': 'مرحاض',
  'squat_wc': 'مرحاض عربي',
  'washbasin': 'مغسلة',
  'shower': 'دش',
  'bathtub': 'بانيو',
  'washer': 'غسالة',
  'floor_seating': 'جلسة أرضية',
  'carpet': 'سجادة',
  'plant': 'نبات',
  'car': 'سيارة',
  'bookshelf': 'مكتبة',
  'generic': 'قطعة',
};

class PlanRoom {
  String id;
  String name;
  String type;
  double x, y, w, h;
  PlanRoom(this.id, this.name, this.type, this.x, this.y, this.w, this.h);

  double get area => w * h;
  double get right => x + w;
  double get bottom => y + h;

  factory PlanRoom.fromJson(Map<String, dynamic> j, int idx) {
    final t = _s(j['type']);
    return PlanRoom(
      _s(j['id']).isEmpty ? 'r${idx + 1}' : _s(j['id']),
      _s(j['name']),
      kRoomTypes.containsKey(t) ? t : 'other',
      snap(_n(j['x'])),
      snap(_n(j['y'])),
      snap(_n(j['w'])).clamp(0.5, 200).toDouble(),
      snap(_n(j['h'])).clamp(0.5, 200).toDouble(),
    );
  }

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'type': type, 'x': x, 'y': y, 'w': w, 'h': h};
}

class PlanOpening {
  String room;
  String side; // top, bottom, left, right
  double offset;
  double width;
  String kind; // door, window, opening
  String hinge; // start, end

  PlanOpening(this.room, this.side, this.offset, this.width, this.kind, this.hinge);

  factory PlanOpening.fromJson(Map<String, dynamic> j) {
    final side = _s(j['side']);
    final kind = _s(j['kind']);
    final hinge = _s(j['hinge']);
    return PlanOpening(
      _s(j['room']),
      const ['top', 'bottom', 'left', 'right'].contains(side) ? side : 'top',
      snap(_n(j['offset'])),
      snap(_n(j['width'], 0.9)).clamp(0.4, 12).toDouble(),
      const ['door', 'window', 'opening'].contains(kind) ? kind : 'door',
      hinge == 'end' ? 'end' : 'start',
    );
  }

  Map<String, dynamic> toJson() => {
        'room': room,
        'side': side,
        'offset': offset,
        'width': width,
        'kind': kind,
        'hinge': hinge,
      };
}

class PlanColumn {
  double x, y, size;
  PlanColumn(this.x, this.y, this.size);

  factory PlanColumn.fromJson(Map<String, dynamic> j) => PlanColumn(
        snap(_n(j['x'])),
        snap(_n(j['y'])),
        _n(j['size'], 0.25).clamp(0.15, 0.8).toDouble(),
      );

  Map<String, dynamic> toJson() => {'x': x, 'y': y, 'size': size};
}

class PlanFurn {
  String room;
  String type;
  String anchor; // nw n ne w c e sw s se
  double w, h;
  double dx, dy;
  int rot; // 0, 90, 180, 270
  String label;

  PlanFurn(this.room, this.type, this.anchor, this.w, this.h, this.dx, this.dy,
      this.rot, this.label);

  factory PlanFurn.fromJson(Map<String, dynamic> j) {
    final t = _s(j['type']);
    final a = _s(j['anchor']);
    var r = _n(j['rot']).round() % 360;
    if (r < 0) r += 360;
    r = ((r / 90).round() * 90) % 360;
    return PlanFurn(
      _s(j['room']),
      kFurnitureNames.containsKey(t) ? t : 'generic',
      const ['nw', 'n', 'ne', 'w', 'c', 'e', 'sw', 's', 'se'].contains(a) ? a : 'c',
      _n(j['w'], 0.6).clamp(0.2, 8).toDouble(),
      _n(j['h'], 0.6).clamp(0.2, 8).toDouble(),
      _n(j['dx']),
      _n(j['dy']),
      r,
      _s(j['label']),
    );
  }

  Map<String, dynamic> toJson() => {
        'room': room,
        'type': type,
        'anchor': anchor,
        'w': w,
        'h': h,
        'dx': dx,
        'dy': dy,
        'rot': rot,
        'label': label,
      };
}

class PlanFloor {
  String name;
  List<PlanRoom> rooms;
  List<PlanOpening> openings;
  List<PlanColumn> columns;
  List<PlanFurn> furniture;
  PlanFloor(this.name, this.rooms, this.openings, this.columns, this.furniture);

  PlanRoom? roomById(String id) {
    for (final r in rooms) {
      if (r.id == id) return r;
    }
    return null;
  }

  PlanFloor copy(String newName) {
    final j = toJson();
    final f = PlanFloor.fromJson(Map<String, dynamic>.from(jsonDecode(jsonEncode(j)) as Map));
    f.name = newName;
    return f;
  }

  factory PlanFloor.fromJson(Map<String, dynamic> j) => PlanFloor(
        _s(j['name']).isEmpty ? 'الدور' : _s(j['name']),
        [
          for (var i = 0; i < ((j['rooms'] as List?) ?? []).length; i++)
            PlanRoom.fromJson(
                Map<String, dynamic>.from((j['rooms'] as List)[i] as Map), i)
        ],
        ((j['openings'] as List?) ?? [])
            .map((e) => PlanOpening.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        ((j['columns'] as List?) ?? [])
            .map((e) => PlanColumn.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        ((j['furniture'] as List?) ?? [])
            .map((e) => PlanFurn.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'rooms': rooms.map((e) => e.toJson()).toList(),
        'openings': openings.map((e) => e.toJson()).toList(),
        'columns': columns.map((e) => e.toJson()).toList(),
        'furniture': furniture.map((e) => e.toJson()).toList(),
      };
}

class PlanDoc {
  String id;
  String title;
  String country;
  double plotW;
  double plotD;
  String street; // top, bottom, left, right
  String north; // up, right, down, left
  double sbTop, sbBottom, sbLeft, sbRight;
  double wallExt;
  double wallInt;
  bool showColumns;
  bool showFurniture;
  bool showDims;
  List<PlanFloor> floors;
  List<String> notes;
  int updated;

  PlanDoc({
    String? id,
    this.title = '',
    this.country = '',
    this.plotW = 15,
    this.plotD = 20,
    this.street = 'bottom',
    this.north = 'up',
    this.sbTop = 0,
    this.sbBottom = 0,
    this.sbLeft = 0,
    this.sbRight = 0,
    this.wallExt = 0.25,
    this.wallInt = 0.12,
    this.showColumns = true,
    this.showFurniture = true,
    this.showDims = true,
    List<PlanFloor>? floors,
    List<String>? notes,
    int? updated,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        floors = floors ?? [],
        notes = notes ?? [],
        updated = updated ?? DateTime.now().millisecondsSinceEpoch;

  int get roomCount => floors.fold(0, (a, f) => a + f.rooms.length);

  /// المنطقة المسموح البناء فيها بعد الارتدادات.
  ({double x, double y, double w, double h}) get buildable => (
        x: sbLeft,
        y: sbTop,
        w: plotW - sbLeft - sbRight,
        h: plotD - sbTop - sbBottom,
      );

  factory PlanDoc.fromJson(Map<String, dynamic> j) {
    final plot = Map<String, dynamic>.from((j['plot'] as Map?) ?? {});
    final sb = Map<String, dynamic>.from((j['setbacks'] as Map?) ?? {});
    final disp = Map<String, dynamic>.from((j['display'] as Map?) ?? {});
    final street = _s(j['street']);
    final north = _s(j['north']);
    final floors = <PlanFloor>[];
    final raw = (j['floors'] as List?) ?? [];
    for (final e in raw) {
      final m = Map<String, dynamic>.from(e as Map);
      final same = m['sameAs'];
      if (same is num &&
          same.toInt() >= 0 &&
          same.toInt() < floors.length &&
          (m['rooms'] == null || (m['rooms'] as List).isEmpty)) {
        floors.add(floors[same.toInt()].copy(_s(m['name']).isEmpty ? 'الدور المتكرر' : _s(m['name'])));
      } else {
        floors.add(PlanFloor.fromJson(m));
      }
    }
    return PlanDoc(
      id: _s(j['id']).isEmpty ? null : _s(j['id']),
      title: _s(j['title']),
      country: _s(j['country']),
      plotW: _n(plot['width'], 15).clamp(3, 500).toDouble(),
      plotD: _n(plot['depth'], 20).clamp(3, 500).toDouble(),
      street: const ['top', 'bottom', 'left', 'right'].contains(street) ? street : 'bottom',
      north: const ['up', 'right', 'down', 'left'].contains(north) ? north : 'up',
      sbTop: _n(sb['top']).clamp(0, 50).toDouble(),
      sbBottom: _n(sb['bottom']).clamp(0, 50).toDouble(),
      sbLeft: _n(sb['left']).clamp(0, 50).toDouble(),
      sbRight: _n(sb['right']).clamp(0, 50).toDouble(),
      wallExt: _n(j['wallExt'], 0.25).clamp(0.1, 0.6).toDouble(),
      wallInt: _n(j['wallInt'], 0.12).clamp(0.05, 0.4).toDouble(),
      showColumns: disp['columns'] is bool ? disp['columns'] as bool : true,
      showFurniture: disp['furniture'] is bool ? disp['furniture'] as bool : true,
      showDims: disp['dimensions'] is bool ? disp['dimensions'] as bool : true,
      floors: floors,
      notes: ((j['notes'] as List?) ?? [])
          .map((e) => _s(e))
          .where((e) => e.isNotEmpty)
          .toList(),
      updated: (j['updated'] as int?),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'country': country,
        'plot': {'width': plotW, 'depth': plotD},
        'street': street,
        'north': north,
        'setbacks': {
          'top': sbTop,
          'bottom': sbBottom,
          'left': sbLeft,
          'right': sbRight
        },
        'wallExt': wallExt,
        'wallInt': wallInt,
        'display': {
          'columns': showColumns,
          'furniture': showFurniture,
          'dimensions': showDims
        },
        'floors': floors.map((f) => f.toJson()).toList(),
        'notes': notes,
        'updated': updated,
      };

  /// تحققات هندسية يجريها التطبيق (لا النموذج).
  List<String> validate() {
    final w = <String>[];
    final b = buildable;
    if (b.w <= 0 || b.h <= 0) {
      w.add('الارتدادات تلغي مساحة البناء بالكامل.');
    }
    for (final f in floors) {
      for (final r in f.rooms) {
        if (r.x < -0.01 || r.y < -0.01 || r.right > plotW + 0.01 || r.bottom > plotD + 0.01) {
          w.add('${f.name}: الغرفة "${r.name}" تخرج عن حدود الأرض.');
        } else if (r.x < b.x - 0.01 ||
            r.y < b.y - 0.01 ||
            r.right > b.x + b.w + 0.01 ||
            r.bottom > b.y + b.h + 0.01) {
          w.add('${f.name}: الغرفة "${r.name}" تدخل في منطقة الارتدادات.');
        }
      }
      for (var i = 0; i < f.rooms.length; i++) {
        for (var k = i + 1; k < f.rooms.length; k++) {
          final a = f.rooms[i], c = f.rooms[k];
          final ox = (a.right < c.right ? a.right : c.right) - (a.x > c.x ? a.x : c.x);
          final oy = (a.bottom < c.bottom ? a.bottom : c.bottom) - (a.y > c.y ? a.y : c.y);
          if (ox > 0.1 && oy > 0.1) {
            w.add('${f.name}: تداخل بين "${a.name}" و"${c.name}".');
          }
        }
      }
      for (final o in f.openings) {
        final r = f.roomById(o.room);
        if (r == null) {
          w.add('${f.name}: فتحة مرتبطة بغرفة غير موجودة (${o.room}).');
          continue;
        }
        final len = (o.side == 'top' || o.side == 'bottom') ? r.w : r.h;
        if (o.offset < -0.01 || o.offset + o.width > len + 0.01) {
          w.add('${f.name}: فتحة في "${r.name}" تتجاوز طول الجدار.');
        }
      }
    }
    return w;
  }

  /// إجمالي مساحة الغرف في الدور (بدون سماكة الجدران).
  double floorArea(int i) =>
      floors[i].rooms.fold(0.0, (a, r) => a + r.area);

  /// نسبة تغطية الدور الأرضي من الأرض (تقريبية).
  double get groundCoverage =>
      floors.isEmpty ? 0 : floorArea(0) / (plotW * plotD) * 100;
}

class PlanStore {
  static const _key = 'floor_plans_v1';

  static Future<List<PlanDoc>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final l = (jsonDecode(raw) as List)
          .map((e) => PlanDoc.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      l.sort((a, b) => b.updated.compareTo(a.updated));
      return l;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<PlanDoc> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(l.map((e) => e.toJson()).toList()));
  }

  static Future<void> save(PlanDoc d) async {
    final l = await load();
    d.updated = DateTime.now().millisecondsSinceEpoch;
    final i = l.indexWhere((x) => x.id == d.id);
    if (i >= 0) {
      l[i] = d;
    } else {
      l.add(d);
    }
    await _write(l);
  }

  static Future<void> delete(String id) async {
    final l = await load();
    l.removeWhere((x) => x.id == id);
    await _write(l);
  }
}

enum PlanStatus { needInfo, ready, message }

class PlanParseFailure implements Exception {
  final String raw;
  PlanParseFailure(this.raw);
}

class PlanAiResult {
  final PlanStatus status;
  final String message;
  final List<String> questions;
  final PlanDoc? doc;
  final String raw;
  PlanAiResult(this.status, this.message, this.questions, this.doc, this.raw);

  static PlanAiResult parse(String raw) {
    var clean = raw.trim().replaceAll('```json', '').replaceAll('```', '');
    final a = clean.indexOf('{');
    final b = clean.lastIndexOf('}');
    if (a < 0 || b <= a) throw PlanParseFailure(raw);
    Map<String, dynamic> m;
    try {
      m = Map<String, dynamic>.from(jsonDecode(clean.substring(a, b + 1)) as Map);
    } catch (_) {
      throw PlanParseFailure(raw);
    }
    final questions = ((m['questions'] as List?) ?? [])
        .map((e) => _s(e))
        .where((e) => e.isNotEmpty)
        .toList();
    PlanDoc? doc;
    if (m['plan'] is Map) {
      try {
        doc = PlanDoc.fromJson(Map<String, dynamic>.from(m['plan'] as Map));
        if (doc.floors.isEmpty || doc.roomCount == 0) doc = null;
      } catch (_) {
        throw PlanParseFailure(raw);
      }
    }
    final st = _s(m['status']);
    final status = (st == 'need_info' || (questions.isNotEmpty && doc == null))
        ? PlanStatus.needInfo
        : (doc != null ? PlanStatus.ready : PlanStatus.message);
    return PlanAiResult(status, _s(m['message']), questions, doc, clean.substring(a, b + 1));
  }
}
