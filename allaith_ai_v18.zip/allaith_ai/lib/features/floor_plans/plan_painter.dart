import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'plan_models.dart';

/// خيارات عرض المخطط (طبقات).
class PlanView {
  bool columns;
  bool furniture;
  bool dims;
  bool names;
  bool areas;
  bool grid;
  PlanView({
    this.columns = true,
    this.furniture = true,
    this.dims = true,
    this.names = true,
    this.areas = true,
    this.grid = false,
  });
}

/// يرسم المخطط (غرف، جدران، أبواب، شبابيك، أعمدة، أثاث، أبعاد).
class PlanPainter extends CustomPainter {
  final PlanDoc doc;
  final int floorIndex;
  final PlanView view;
  final bool whiteBg;

  PlanPainter(this.doc, this.floorIndex, this.view, {this.whiteBg = false});

  /// هامش حول الأرض بالمتر لمساحة الأبعاد.
  static const double margin = 2.2;

  static double aspect(PlanDoc d) =>
      (d.plotW + 2 * margin) / (d.plotD + 2 * margin);

  static Color roomColor(String type) {
    switch (type) {
      case 'living':
      case 'majlis':
      case 'hall':
        return const Color(0xFFFFF4DC);
      case 'bedroom':
      case 'master_bedroom':
        return const Color(0xFFE8F1FB);
      case 'bathroom':
      case 'laundry':
        return const Color(0xFFDDF2F2);
      case 'kitchen':
      case 'dining':
        return const Color(0xFFFCE9E6);
      case 'courtyard':
      case 'terrace':
        return const Color(0xFFE4F1DE);
      case 'garage':
      case 'store':
        return const Color(0xFFEDEDED);
      case 'corridor':
      case 'entrance':
      case 'stairs':
        return const Color(0xFFF6F6F6);
      default:
        return const Color(0xFFFBFBFB);
    }
  }

  @override
  bool shouldRepaint(covariant PlanPainter old) => true;

  @override
  void paint(Canvas c, Size s) {
    if (whiteBg) {
      c.drawRect(Offset.zero & s, Paint()..color = Colors.white);
    }
    if (doc.floors.isEmpty) return;
    final f = doc.floors[floorIndex.clamp(0, doc.floors.length - 1)];
    final worldW = doc.plotW + 2 * margin;
    final worldH = doc.plotD + 2 * margin;
    final sc = math.min(s.width / worldW, s.height / worldH);
    final ox = (s.width - doc.plotW * sc) / 2;
    final oy = (s.height - doc.plotD * sc) / 2;
    Offset p(double x, double y) => Offset(ox + x * sc, oy + y * sc);
    Rect rect(double x, double y, double w, double h) =>
        Rect.fromLTWH(ox + x * sc, oy + y * sc, w * sc, h * sc);

    // الشبكة
    if (view.grid) {
      final g = Paint()
        ..color = const Color(0xFFE6E6E6)
        ..strokeWidth = 0.6;
      for (var x = 0.0; x <= doc.plotW + 0.001; x += 1) {
        c.drawLine(p(x, 0), p(x, doc.plotD), g);
      }
      for (var y = 0.0; y <= doc.plotD + 0.001; y += 1) {
        c.drawLine(p(0, y), p(doc.plotW, y), g);
      }
    }

    // حد الأرض وحدود البناء
    _dashedRect(c, rect(0, 0, doc.plotW, doc.plotD), const Color(0xFF7A7A7A), 1.2, sc);
    if (doc.bx != null && doc.by != null && doc.bw != null && doc.bd != null) {
      _dashedRect(c, rect(doc.bx!, doc.by!, doc.bw!, doc.bd!),
          const Color(0xFFB04A4A), 0.9, sc);
    }

    // تعبئة الغرف
    for (final r in f.rooms) {
      c.drawRect(rect(r.x, r.y, r.w, r.h), Paint()..color = roomColor(r.type));
      if (r.type == 'stairs') _stairs(c, r, rect(r.x, r.y, r.w, r.h));
    }

    // الجدران
    final wallPaint = Paint()..color = const Color(0xFF222222);
    for (final r in f.rooms) {
      for (final side in ['N', 'S', 'E', 'W']) {
        final ext = _isExterior(f, r, side);
        final t = ext ? doc.wallExt : doc.wallInt;
        late Rect wr;
        switch (side) {
          case 'N':
            wr = rect(r.x - t / 2, r.y - t / 2, r.w + t, t);
            break;
          case 'S':
            wr = rect(r.x - t / 2, r.bottom - t / 2, r.w + t, t);
            break;
          case 'W':
            wr = rect(r.x - t / 2, r.y - t / 2, t, r.h + t);
            break;
          default:
            wr = rect(r.right - t / 2, r.y - t / 2, t, r.h + t);
        }
        c.drawRect(wr, wallPaint);
      }
    }

    // الفتحات
    for (final o in f.openings) {
      final r = f.roomById(o.room);
      if (r == null) continue;
      _opening(c, f, r, o, p, sc);
    }

    // الأعمدة
    if (view.columns) {
      final cp = Paint()..color = const Color(0xFF111111);
      for (final col in f.columns) {
        c.drawRect(rect(col.x - col.size / 2, col.y - col.size / 2, col.size, col.size), cp);
      }
    }

    // الأثاث
    if (view.furniture) {
      for (final fu in f.furniture) {
        _furniture(c, fu, rect(fu.x, fu.y, fu.w, fu.h));
      }
    }

    // الأسماء والمساحات
    if (view.names || view.areas) {
      for (final r in f.rooms) {
        final lines = <String>[];
        if (view.names && r.name.isNotEmpty) lines.add(r.name);
        if (view.areas) lines.add('${r.area.toStringAsFixed(1)} م²');
        if (view.dims) lines.add('${r.w.toStringAsFixed(2)}×${r.h.toStringAsFixed(2)}');
        final rc = rect(r.x, r.y, r.w, r.h);
        final fs = math.max(7.0, math.min(rc.width / 8, 14.0));
        _label(c, lines, rc.center, fs, rc.width * 0.95);
      }
    }

    // الأبعاد الخارجية
    if (view.dims) _dims(c, f, p, sc);

    _north(c, s);
    _scaleBar(c, s, sc);
    _street(c, p);
  }

  // ---------- أدوات الرسم ----------
  void _dashedRect(Canvas c, Rect r, Color col, double w, double sc) {
    final paint = Paint()
      ..color = col
      ..strokeWidth = w
      ..style = PaintingStyle.stroke;
    void dash(Offset a, Offset b) {
      final len = (b - a).distance;
      if (len == 0) return;
      final dir = (b - a) / len;
      var d = 0.0;
      const dl = 8.0, gap = 5.0;
      while (d < len) {
        final e = math.min(d + dl, len);
        c.drawLine(a + dir * d, a + dir * e, paint);
        d += dl + gap;
      }
    }

    dash(r.topLeft, r.topRight);
    dash(r.topRight, r.bottomRight);
    dash(r.bottomRight, r.bottomLeft);
    dash(r.bottomLeft, r.topLeft);
  }

  bool _isExterior(PlanFloor f, PlanRoom r, String side) {
    double px, py;
    const d = 0.1;
    switch (side) {
      case 'N':
        px = r.x + r.w / 2;
        py = r.y - d;
        break;
      case 'S':
        px = r.x + r.w / 2;
        py = r.bottom + d;
        break;
      case 'W':
        px = r.x - d;
        py = r.y + r.h / 2;
        break;
      default:
        px = r.right + d;
        py = r.y + r.h / 2;
    }
    for (final o in f.rooms) {
      if (!identical(o, r) && o.contains(px, py)) return false;
    }
    return true;
  }

  void _opening(Canvas c, PlanFloor f, PlanRoom r, PlanOpening o,
      Offset Function(double, double) p, double sc) {
    final g = OpeningGeom.of(r, o);
    final ext = _isExterior(f, r, o.side);
    final t = (ext ? doc.wallExt : doc.wallInt) + 0.04;
    final a = p(g.sx, g.sy), b = p(g.ex, g.ey);
    // مسح الجدار
    final clear = Paint()..color = Colors.white;
    final half = t * sc / 2;
    final rectClear = g.horizontal
        ? Rect.fromLTRB(a.dx, a.dy - half, b.dx, b.dy + half)
        : Rect.fromLTRB(a.dx - half, a.dy, b.dx + half, b.dy);
    c.drawRect(rectClear, clear);

    final line = Paint()
      ..color = const Color(0xFF222222)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;

    if (o.kind == 'window') {
      final off = t * sc / 4;
      if (g.horizontal) {
        c.drawLine(a + Offset(0, -off), b + Offset(0, -off), line);
        c.drawLine(a + Offset(0, off), b + Offset(0, off), line);
        c.drawLine(a, b, Paint()
          ..color = const Color(0xFF5B9BD5)
          ..strokeWidth = 1.4);
      } else {
        c.drawLine(a + Offset(-off, 0), b + Offset(-off, 0), line);
        c.drawLine(a + Offset(off, 0), b + Offset(off, 0), line);
        c.drawLine(a, b, Paint()
          ..color = const Color(0xFF5B9BD5)
          ..strokeWidth = 1.4);
      }
      return;
    }
    if (o.kind == 'opening') return;

    // باب: ورقة وقوس الفتح
    final sgn = o.swing == 'out' ? -1.0 : 1.0;
    final hingeStart = o.hinge != 'end';
    final hx = hingeStart ? g.sx : g.ex;
    final hy = hingeStart ? g.sy : g.ey;
    final ex = hingeStart ? g.ex : g.sx;
    final ey = hingeStart ? g.ey : g.sy;
    final lx = hx + g.nx * sgn * o.width;
    final ly = hy + g.ny * sgn * o.width;
    final H = p(hx, hy), E = p(ex, ey), L = p(lx, ly);
    final leaf = Paint()
      ..color = const Color(0xFF222222)
      ..strokeWidth = o.kind == 'main_door' ? 2.0 : 1.4;
    c.drawLine(H, L, leaf);
    final a1 = math.atan2(E.dy - H.dy, E.dx - H.dx);
    final a2 = math.atan2(L.dy - H.dy, L.dx - H.dx);
    var sweep = a2 - a1;
    while (sweep > math.pi) {
      sweep -= 2 * math.pi;
    }
    while (sweep <= -math.pi) {
      sweep += 2 * math.pi;
    }
    c.drawArc(Rect.fromCircle(center: H, radius: o.width * sc), a1, sweep, false,
        Paint()
          ..color = const Color(0xFF555555)
          ..strokeWidth = 0.8
          ..style = PaintingStyle.stroke);
  }

  void _stairs(Canvas c, PlanRoom r, Rect rc) {
    final paint = Paint()
      ..color = const Color(0xFF777777)
      ..strokeWidth = 0.8;
    final vertical = r.h >= r.w;
    const tread = 0.28;
    if (vertical) {
      final n = (r.h / tread).floor();
      for (var i = 1; i < n; i++) {
        final y = rc.top + rc.height * i / n;
        c.drawLine(Offset(rc.left, y), Offset(rc.right, y), paint);
      }
      c.drawLine(Offset(rc.center.dx, rc.bottom - 4), Offset(rc.center.dx, rc.top + 8),
          Paint()..color = const Color(0xFF444444)..strokeWidth = 1.2);
    } else {
      final n = (r.w / tread).floor();
      for (var i = 1; i < n; i++) {
        final x = rc.left + rc.width * i / n;
        c.drawLine(Offset(x, rc.top), Offset(x, rc.bottom), paint);
      }
      c.drawLine(Offset(rc.left + 4, rc.center.dy), Offset(rc.right - 8, rc.center.dy),
          Paint()..color = const Color(0xFF444444)..strokeWidth = 1.2);
    }
  }

  void _label(Canvas c, List<String> lines, Offset center, double fs, double maxW) {
    if (lines.isEmpty) return;
    final tp = TextPainter(
      text: TextSpan(
        children: [
          for (var i = 0; i < lines.length; i++)
            TextSpan(
              text: lines[i] + (i == lines.length - 1 ? '' : '\n'),
              style: TextStyle(
                color: i == 0 && view.names ? const Color(0xFF111111) : const Color(0xFF555555),
                fontSize: i == 0 ? fs : fs * 0.82,
                fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w400,
                height: 1.25,
              ),
            ),
        ],
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.rtl,
    )..layout(maxWidth: math.max(20, maxW));
    tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
  }

  void _text(Canvas c, String t, Offset center, double fs, {double angle = 0, Color color = const Color(0xFF333333)}) {
    final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(color: color, fontSize: fs)),
      textDirection: TextDirection.rtl,
    )..layout();
    c.save();
    c.translate(center.dx, center.dy);
    c.rotate(angle);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  void _dimLine(Canvas c, Offset a, Offset b, String label, double fs, {bool vertical = false}) {
    final paint = Paint()
      ..color = const Color(0xFF444444)
      ..strokeWidth = 0.9;
    c.drawLine(a, b, paint);
    const tick = 4.0;
    if (vertical) {
      c.drawLine(a + const Offset(-tick, 0), a + const Offset(tick, 0), paint);
      c.drawLine(b + const Offset(-tick, 0), b + const Offset(tick, 0), paint);
      _text(c, label, Offset((a.dx + b.dx) / 2 - fs * 0.9, (a.dy + b.dy) / 2), fs, angle: -math.pi / 2);
    } else {
      c.drawLine(a + const Offset(0, -tick), a + const Offset(0, tick), paint);
      c.drawLine(b + const Offset(0, -tick), b + const Offset(0, tick), paint);
      _text(c, label, Offset((a.dx + b.dx) / 2, (a.dy + b.dy) / 2 - fs * 0.9), fs);
    }
  }

  void _dims(Canvas c, PlanFloor f, Offset Function(double, double) p, double sc) {
    final fs = math.max(8.0, math.min(sc * 0.42, 13.0));
    // أبعاد الأرض: أعلى ويسار
    _dimLine(p(0, -0.9), p(doc.plotW, -0.9), '${doc.plotW.toStringAsFixed(2)} م', fs);
    _dimLine(p(-0.9, 0), p(-0.9, doc.plotD), '${doc.plotD.toStringAsFixed(2)} م', fs, vertical: true);
    if (f.rooms.isEmpty) return;
    var minX = double.infinity, minY = double.infinity;
    var maxX = -double.infinity, maxY = -double.infinity;
    for (final r in f.rooms) {
      minX = math.min(minX, r.x);
      minY = math.min(minY, r.y);
      maxX = math.max(maxX, r.right);
      maxY = math.max(maxY, r.bottom);
    }
    // أبعاد المبنى: أسفل ويمين
    _dimLine(p(minX, doc.plotD + 0.9), p(maxX, doc.plotD + 0.9),
        '${(maxX - minX).toStringAsFixed(2)} م', fs);
    _dimLine(p(doc.plotW + 0.9, minY), p(doc.plotW + 0.9, maxY),
        '${(maxY - minY).toStringAsFixed(2)} م', fs, vertical: true);
  }

  void _north(Canvas c, Size s) {
    const r = 18.0;
    final center = Offset(s.width - 34, 34);
    c.drawCircle(center, r, Paint()
      ..color = const Color(0xFF333333)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2);
    final ang = {'up': -math.pi / 2, 'right': 0.0, 'down': math.pi / 2, 'left': math.pi}[doc.north] ?? -math.pi / 2;
    final tip = center + Offset(math.cos(ang), math.sin(ang)) * (r - 2);
    final tail = center - Offset(math.cos(ang), math.sin(ang)) * (r - 6);
    c.drawLine(tail, tip, Paint()
      ..color = const Color(0xFF222222)
      ..strokeWidth = 2);
    final left = tip + Offset(math.cos(ang + 2.6), math.sin(ang + 2.6)) * 7;
    final right = tip + Offset(math.cos(ang - 2.6), math.sin(ang - 2.6)) * 7;
    c.drawPath(
        Path()
          ..moveTo(tip.dx, tip.dy)
          ..lineTo(left.dx, left.dy)
          ..lineTo(right.dx, right.dy)
          ..close(),
        Paint()..color = const Color(0xFF222222));
    _text(c, 'ش', center + Offset(0, r + 9), 10);
  }

  void _scaleBar(Canvas c, Size s, double sc) {
    final len = 5 * sc;
    final y = s.height - 16;
    const x0 = 16.0;
    final paint = Paint()
      ..color = const Color(0xFF333333)
      ..strokeWidth = 2;
    c.drawLine(Offset(x0, y), Offset(x0 + len, y), paint);
    c.drawLine(Offset(x0, y - 4), Offset(x0, y + 4), paint);
    c.drawLine(Offset(x0 + len, y - 4), Offset(x0 + len, y + 4), paint);
    _text(c, '5 م', Offset(x0 + len / 2, y - 10), 9);
  }

  void _street(Canvas c, Offset Function(double, double) p) {
    final paint = Paint()
      ..color = const Color(0xFF8A8A8A)
      ..strokeWidth = 3;
    switch (doc.street) {
      case 'N':
        c.drawLine(p(0, -1.55), p(doc.plotW, -1.55), paint);
        _text(c, 'الشارع', p(doc.plotW / 2, -1.55) + const Offset(0, -9), 10);
        break;
      case 'S':
        c.drawLine(p(0, doc.plotD + 1.55), p(doc.plotW, doc.plotD + 1.55), paint);
        _text(c, 'الشارع', p(doc.plotW / 2, doc.plotD + 1.55) + const Offset(0, 10), 10);
        break;
      case 'E':
        c.drawLine(p(doc.plotW + 1.55, 0), p(doc.plotW + 1.55, doc.plotD), paint);
        _text(c, 'الشارع', p(doc.plotW + 1.55, doc.plotD / 2) + const Offset(14, 0), 10, angle: math.pi / 2);
        break;
      default:
        c.drawLine(p(-1.55, 0), p(-1.55, doc.plotD), paint);
        _text(c, 'الشارع', p(-1.55, doc.plotD / 2) + const Offset(-14, 0), 10, angle: -math.pi / 2);
    }
  }

  // ---------- الأثاث ----------
  void _furniture(Canvas c, PlanFurn fu, Rect rc) {
    final swap = fu.rot == 90 || fu.rot == 270;
    final lw = swap ? rc.height : rc.width;
    final lh = swap ? rc.width : rc.height;
    c.save();
    c.translate(rc.center.dx, rc.center.dy);
    c.rotate(fu.rot * math.pi / 180);
    final r = Rect.fromCenter(center: Offset.zero, width: lw, height: lh);
    final fill = Paint()..color = const Color(0xFFF3EFE7);
    final stroke = Paint()
      ..color = const Color(0xFF555555)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final thin = Paint()
      ..color = const Color(0xFF777777)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7;
    RRect rr(Rect x, [double k = 3]) => RRect.fromRectAndRadius(x, Radius.circular(k));

    switch (fu.type) {
      case 'bed_double':
      case 'bed_single':
      case 'crib':
        c.drawRRect(rr(r, 3), fill);
        c.drawRRect(rr(r, 3), stroke);
        final ph = lh * 0.2;
        if (fu.type == 'bed_double') {
          final pw = lw * 0.4;
          c.drawRRect(rr(Rect.fromLTWH(r.left + lw * 0.07, r.top + 3, pw, ph), 3), stroke);
          c.drawRRect(rr(Rect.fromLTWH(r.right - lw * 0.07 - pw, r.top + 3, pw, ph), 3), stroke);
        } else {
          c.drawRRect(rr(Rect.fromLTWH(r.left + lw * 0.15, r.top + 3, lw * 0.7, ph), 3), stroke);
        }
        c.drawLine(Offset(r.left, r.top + lh * 0.38), Offset(r.right, r.top + lh * 0.38), thin);
        break;
      case 'sofa_3':
      case 'sofa_2':
      case 'armchair':
      case 'majlis_seat':
        c.drawRRect(rr(r, 4), fill);
        c.drawRRect(rr(r, 4), stroke);
        final back = math.min(lh * 0.28, 12.0);
        c.drawRect(Rect.fromLTWH(r.left, r.top, lw, back), stroke);
        if (fu.type != 'majlis_seat') {
          c.drawRect(Rect.fromLTWH(r.left, r.top, back, lh), stroke);
          c.drawRect(Rect.fromLTWH(r.right - back, r.top, back, lh), stroke);
        } else {
          final n = math.max(2, (lw / (lh * 1.1)).round());
          for (var i = 1; i < n; i++) {
            final x = r.left + lw * i / n;
            c.drawLine(Offset(x, r.top + back), Offset(x, r.bottom), thin);
          }
        }
        break;
      case 'coffee_table':
      case 'dining_table':
      case 'dining_table_8':
      case 'desk':
        c.drawRRect(rr(r, 3), fill);
        c.drawRRect(rr(r, 3), stroke);
        break;
      case 'rug':
        c.drawRRect(rr(r, 6), Paint()..color = const Color(0x22C9A66B));
        c.drawRRect(rr(r.deflate(3), 4), thin);
        break;
      case 'chair':
        c.drawRRect(rr(r, 3), fill);
        c.drawRRect(rr(r, 3), stroke);
        break;
      case 'wardrobe':
      case 'dresser':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        c.drawLine(r.topLeft, r.bottomRight, thin);
        c.drawLine(r.topRight, r.bottomLeft, thin);
        break;
      case 'tv_unit':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        c.drawRect(r.deflate(math.min(lh * 0.25, 4)), thin);
        break;
      case 'kitchen_counter':
      case 'kitchen_island':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        c.drawLine(Offset(r.left, r.center.dy), Offset(r.right, r.center.dy), thin);
        break;
      case 'sink_kitchen':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        c.drawRRect(rr(r.deflate(math.min(lw, lh) * 0.2), 3), thin);
        break;
      case 'stove':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        final rad = math.min(lw, lh) * 0.14;
        for (final dx in [-0.22, 0.22]) {
          for (final dy in [-0.22, 0.22]) {
            c.drawCircle(Offset(lw * dx, lh * dy), rad, thin);
          }
        }
        break;
      case 'fridge':
      case 'washing_machine':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        if (fu.type == 'washing_machine') c.drawCircle(Offset.zero, math.min(lw, lh) * 0.28, thin);
        break;
      case 'wc':
        c.drawRect(Rect.fromLTWH(r.left, r.top, lw, lh * 0.3), stroke);
        c.drawOval(Rect.fromLTWH(r.left + lw * 0.1, r.top + lh * 0.28, lw * 0.8, lh * 0.7), fill);
        c.drawOval(Rect.fromLTWH(r.left + lw * 0.1, r.top + lh * 0.28, lw * 0.8, lh * 0.7), stroke);
        break;
      case 'basin':
        c.drawRRect(rr(r, 4), fill);
        c.drawRRect(rr(r, 4), stroke);
        c.drawOval(r.deflate(math.min(lw, lh) * 0.22), thin);
        break;
      case 'shower':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        c.drawLine(r.topLeft, r.bottomRight, thin);
        c.drawCircle(Offset.zero, math.min(lw, lh) * 0.08, thin);
        break;
      case 'bathtub':
        c.drawRRect(rr(r, 8), fill);
        c.drawRRect(rr(r, 8), stroke);
        c.drawRRect(rr(r.deflate(math.min(lw, lh) * 0.12), 8), thin);
        break;
      case 'car':
        c.drawRRect(rr(r, 10), fill);
        c.drawRRect(rr(r, 10), stroke);
        c.drawRRect(rr(Rect.fromLTWH(r.left + lw * 0.18, r.top + lh * 0.12, lw * 0.5, lh * 0.76), 6), thin);
        break;
      case 'stairs':
        c.drawRect(r, fill);
        c.drawRect(r, stroke);
        final n = math.max(3, (math.max(lw, lh) / 14).floor());
        for (var i = 1; i < n; i++) {
          if (lh >= lw) {
            final y = r.top + lh * i / n;
            c.drawLine(Offset(r.left, y), Offset(r.right, y), thin);
          } else {
            final x = r.left + lw * i / n;
            c.drawLine(Offset(x, r.top), Offset(x, r.bottom), thin);
          }
        }
        break;
      case 'plant':
        c.drawOval(r, Paint()..color = const Color(0x5539A845));
        c.drawOval(r, thin);
        break;
      default:
        c.drawRRect(rr(r, 3), fill);
        c.drawRRect(rr(r, 3), stroke);
    }
    c.restore();
  }
}
