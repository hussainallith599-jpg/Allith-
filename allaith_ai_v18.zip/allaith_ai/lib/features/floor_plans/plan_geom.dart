import 'dart:math' as math;
import 'plan_models.dart';

/// نقطة (بالمتر).
class Pt {
  final double x, y;
  const Pt(this.x, this.y);
}

/// قطعة جدار: أفقية أو رأسية، ثابتها fixed ومداها من a إلى b، وسماكتها t.
/// (الامتدادات عند الأطراف مضمّنة لسدّ زوايا التقاطع.)
class WallPiece {
  final bool horizontal;
  final double fixed, a, b, t;
  WallPiece(this.horizontal, this.fixed, this.a, this.b, this.t);
}

class _Edge {
  final bool h;
  final double fixed, a, b;
  _Edge(this.h, this.fixed, this.a, this.b);
}

class _Seg {
  final bool h;
  final double fixed;
  double a, b;
  final int cls; // 1 خارجي، 2 داخلي
  _Seg(this.h, this.fixed, this.a, this.b, this.cls);
}

class OpenGap {
  final bool h;
  final double fixed, a, b;
  final PlanRoom room;
  final PlanOpening opening;
  OpenGap(this.h, this.fixed, this.a, this.b, this.room, this.opening);
}

String _key(bool h, double fixed) => '${h ? 'h' : 'v'}${(fixed * 100).round()}';

/// فجوات الفتحات (أبواب/شبابيك) على حواف الغرف.
List<OpenGap> openingGaps(PlanFloor f) {
  final out = <OpenGap>[];
  for (final o in f.openings) {
    final r = f.roomById(o.room);
    if (r == null) continue;
    final g = openingGeom(r, o);
    out.add(OpenGap(g.h, g.fixed, g.a, g.b, r, o));
  }
  return out;
}

/// جدران الدور: تُشتق من حواف الغرف (الحافة المشتركة جدار داخلي، والمنفردة خارجي).
List<WallPiece> buildWalls(PlanFloor f, double ext, double intr) {
  final edges = <_Edge>[];
  for (final r in f.rooms) {
    edges.add(_Edge(true, r.y, r.x, r.right));
    edges.add(_Edge(true, r.bottom, r.x, r.right));
    edges.add(_Edge(false, r.x, r.y, r.bottom));
    edges.add(_Edge(false, r.right, r.y, r.bottom));
  }
  final groups = <String, List<_Edge>>{};
  for (final e in edges) {
    groups.putIfAbsent(_key(e.h, e.fixed), () => []).add(e);
  }
  final segs = <_Seg>[];
  groups.forEach((k, list) {
    final pts = <double>{};
    for (final e in list) {
      pts.add((e.a * 1000).round() / 1000);
      pts.add((e.b * 1000).round() / 1000);
    }
    final sorted = pts.toList()..sort();
    _Seg? prev;
    for (var i = 0; i < sorted.length - 1; i++) {
      final p = sorted[i], q = sorted[i + 1];
      if (q - p < 0.01) continue;
      final mid = (p + q) / 2;
      final count = list.where((e) => e.a <= mid && e.b >= mid).length;
      if (count == 0) {
        prev = null;
        continue;
      }
      final cls = count == 1 ? 1 : 2;
      final h = list.first.h;
      final fx = list.first.fixed;
      if (prev != null && prev.cls == cls && (prev.b - p).abs() < 0.011) {
        prev.b = q;
      } else {
        prev = _Seg(h, fx, p, q, cls);
        segs.add(prev);
      }
    }
  });

  final gaps = openingGaps(f);
  final pieces = <WallPiece>[];
  for (final s in segs) {
    final t = s.cls == 1 ? ext : intr;
    final mine = gaps
        .where((g) =>
            g.h == s.h &&
            _key(g.h, g.fixed) == _key(s.h, s.fixed) &&
            g.b > s.a + 0.005 &&
            g.a < s.b - 0.005)
        .toList()
      ..sort((x, y) => x.a.compareTo(y.a));
    var cursor = s.a;
    var first = true;
    for (final g in mine) {
      if (g.a > cursor + 0.005) {
        pieces.add(WallPiece(s.h, s.fixed, first ? cursor - t / 2 : cursor, g.a, t));
      }
      first = false;
      cursor = math.max(cursor, g.b);
    }
    if (s.b > cursor + 0.005) {
      pieces.add(WallPiece(s.h, s.fixed, first ? cursor - t / 2 : cursor, s.b + t / 2, t));
    } else if (!first) {
      // انتهى الجدار بفتحة؛ لا امتداد.
    }
  }
  return pieces;
}

/// هل الجانب المعطى للغرفة جدار خارجي؟
bool isExteriorSide(PlanFloor f, PlanRoom r, String side) {
  double px, py;
  const d = 0.1;
  switch (side) {
    case 'top':
      px = r.x + r.w / 2;
      py = r.y - d;
      break;
    case 'bottom':
      px = r.x + r.w / 2;
      py = r.bottom + d;
      break;
    case 'left':
      px = r.x - d;
      py = r.y + r.h / 2;
      break;
    default:
      px = r.right + d;
      py = r.y + r.h / 2;
  }
  for (final o in f.rooms) {
    if (identical(o, r)) continue;
    if (px >= o.x && px <= o.right && py >= o.y && py <= o.bottom) return false;
  }
  return true;
}

/// هندسة فتحة: مدى الفجوة على الجدار + مفصلة الباب وقوس الدوران (إحداثيات y لأسفل).
class OpenGeom {
  final bool h;
  final double fixed, a, b;
  final Pt hinge, leafEnd;
  final double arcStart, arcSweep;
  final double width;
  OpenGeom(this.h, this.fixed, this.a, this.b, this.hinge, this.leafEnd,
      this.arcStart, this.arcSweep, this.width);
}

OpenGeom openingGeom(PlanRoom r, PlanOpening o) {
  late bool h;
  late double fixed, edgeStart, edgeEnd;
  late double nx, ny; // اتجاه الدخول للغرفة
  switch (o.side) {
    case 'top':
      h = true;
      fixed = r.y;
      edgeStart = r.x;
      edgeEnd = r.right;
      nx = 0;
      ny = 1;
      break;
    case 'bottom':
      h = true;
      fixed = r.bottom;
      edgeStart = r.x;
      edgeEnd = r.right;
      nx = 0;
      ny = -1;
      break;
    case 'left':
      h = false;
      fixed = r.x;
      edgeStart = r.y;
      edgeEnd = r.bottom;
      nx = 1;
      ny = 0;
      break;
    default:
      h = false;
      fixed = r.right;
      edgeStart = r.y;
      edgeEnd = r.bottom;
      nx = -1;
      ny = 0;
  }
  var a = edgeStart + o.offset;
  a = a.clamp(edgeStart, math.max(edgeStart, edgeEnd - 0.3)).toDouble();
  final b = math.min(a + o.width, edgeEnd);
  final w = b - a;
  final p0 = h ? Pt(a, fixed) : Pt(fixed, a);
  final p1 = h ? Pt(b, fixed) : Pt(fixed, b);
  final atStart = o.hinge != 'end';
  final hinge = atStart ? p0 : p1;
  final ux = h ? 1.0 : 0.0, uy = h ? 0.0 : 1.0;
  final dx = atStart ? ux : -ux, dy = atStart ? uy : -uy;
  final leaf = Pt(hinge.x + nx * w, hinge.y + ny * w);
  final aN = math.atan2(ny, nx);
  final aD = math.atan2(dy, dx);
  var sweep = aD - aN;
  while (sweep > math.pi) {
    sweep -= 2 * math.pi;
  }
  while (sweep <= -math.pi) {
    sweep += 2 * math.pi;
  }
  return OpenGeom(h, fixed, a, b, hinge, leaf, aN, sweep, w);
}

/// موضع قطعة أثاث داخل غرفة (مركز + أبعاد غير مدوّرة + تدوير).
class FurnPlace {
  final double cx, cy, w0, h0;
  final int rot;
  FurnPlace(this.cx, this.cy, this.w0, this.h0, this.rot);

  bool get swapped => rot == 90 || rot == 270;
  double get fw => swapped ? h0 : w0;
  double get fh => swapped ? w0 : h0;
}

FurnPlace? placeFurniture(PlanRoom r, PlanFurn fu, double inset) {
  var w0 = fu.w, h0 = fu.h;
  final swapped = fu.rot == 90 || fu.rot == 270;
  var fw = swapped ? h0 : w0;
  var fh = swapped ? w0 : h0;
  final maxW = r.w - 2 * inset;
  final maxH = r.h - 2 * inset;
  if (maxW <= 0.2 || maxH <= 0.2) return null;
  final s = math.min(1.0, math.min(maxW / fw, maxH / fh));
  if (s < 1) {
    w0 *= s;
    h0 *= s;
    fw *= s;
    fh *= s;
  }
  final a = fu.anchor;
  double x;
  if (a.contains('w')) {
    x = r.x + inset;
  } else if (a.contains('e')) {
    x = r.right - inset - fw;
  } else {
    x = r.x + (r.w - fw) / 2;
  }
  double y;
  if (a.contains('n')) {
    y = r.y + inset;
  } else if (a.contains('s')) {
    y = r.bottom - inset - fh;
  } else {
    y = r.y + (r.h - fh) / 2;
  }
  x += fu.dx;
  y += fu.dy;
  x = x.clamp(r.x + inset, math.max(r.x + inset, r.right - inset - fw)).toDouble();
  y = y.clamp(r.y + inset, math.max(r.y + inset, r.bottom - inset - fh)).toDouble();
  return FurnPlace(x + fw / 2, y + fh / 2, w0, h0, fu.rot);
}

/// حدود المبنى (أصغر مستطيل يحوي كل الغرف في الدور).
({double x, double y, double r, double b})? buildingBounds(PlanFloor f) {
  if (f.rooms.isEmpty) return null;
  var x = double.infinity, y = double.infinity;
  var r = -double.infinity, b = -double.infinity;
  for (final room in f.rooms) {
    x = math.min(x, room.x);
    y = math.min(y, room.y);
    r = math.max(r, room.right);
    b = math.max(b, room.bottom);
  }
  return (x: x, y: y, r: r, b: b);
}
