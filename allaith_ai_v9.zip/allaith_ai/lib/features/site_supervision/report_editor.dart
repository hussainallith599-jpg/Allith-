import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'checklist_data.dart';
import 'report_pdf.dart';
import 'site_models.dart';

class ReportEditor extends StatefulWidget {
  final SiteReport report;
  const ReportEditor({super.key, required this.report});
  @override
  State<ReportEditor> createState() => _ReportEditorState();
}

class _ReportEditorState extends State<ReportEditor> {
  late final SiteReport r = widget.report;
  late final _project = TextEditingController(text: r.project);
  late final _location = TextEditingController(text: r.location);
  late final _engineer = TextEditingController(text: r.engineer);
  late final _general = TextEditingController(text: r.general);
  bool _busy = false;

  @override
  void dispose() {
    _project.dispose();
    _location.dispose();
    _engineer.dispose();
    _general.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    r.project = _project.text.trim();
    r.location = _location.text.trim();
    r.engineer = _engineer.text.trim();
    r.general = _general.text.trim();
    await ReportsStore.save(r);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.fromMillisecondsSinceEpoch(r.date),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) {
      setState(() => r.date = d.millisecondsSinceEpoch);
      await _save();
    }
  }

  Future<String?> _grabPhoto(ImageSource source) async {
    try {
      final x = await ImagePicker()
          .pickImage(source: source, maxWidth: 1280, imageQuality: 70);
      if (x == null) return null;
      final dir = await getApplicationDocumentsDirectory();
      final folder = Directory(p.join(dir.path, 'site_photos'));
      if (!folder.existsSync()) folder.createSync(recursive: true);
      final dest = p.join(
          folder.path, '${DateTime.now().microsecondsSinceEpoch}.jpg');
      await File(x.path).copy(dest);
      return dest;
    } catch (e) {
      if (mounted) _msg('تعذّر الحصول على الصورة. تحقق من الصلاحيات.');
      return null;
    }
  }

  Future<void> _addNote() async {
    final text = TextEditingController();
    String? photo;
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('ملاحظة جديدة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: text,
                  minLines: 2,
                  maxLines: 5,
                  decoration: const InputDecoration(hintText: 'اكتب الملاحظة...'),
                ),
                const SizedBox(height: 10),
                if (photo != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(File(photo!), height: 140),
                  ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        final f = await _grabPhoto(ImageSource.camera);
                        if (f != null) setD(() => photo = f);
                      },
                      icon: const Icon(Icons.photo_camera_outlined),
                      label: const Text('كاميرا'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final f = await _grabPhoto(ImageSource.gallery);
                        if (f != null) setD(() => photo = f);
                      },
                      icon: const Icon(Icons.photo_library_outlined),
                      label: const Text('المعرض'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('إلغاء')),
            TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (saved == true && (text.text.trim().isNotEmpty || photo != null)) {
      setState(() =>
          r.notes.add(SiteNote(text: text.text.trim(), photoPath: photo)));
      await _save();
    }
    text.dispose();
  }

  Future<void> _makePdf() async {
    await _save();
    setState(() => _busy = true);
    try {
      await ReportPdf.shareReport(r);
    } catch (e) {
      if (mounted) {
        _msg('تعذّر إنشاء ملف PDF. تأكد من الاتصال بالإنترنت (لتحميل الخط) وأعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _statusChip(ChecklistItem it, ItemStatus s, String label, Color c) {
    final selected = r.statusOf(it.id) == s;
    return ChoiceChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      selected: selected,
      selectedColor: c.withOpacity(0.22),
      showCheckmark: false,
      visualDensity: VisualDensity.compact,
      onSelected: (_) async {
        setState(() => r.setStatus(it.id, selected ? ItemStatus.pending : s));
        await _save();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final phase = phaseById(r.phaseId);
    final done =
        phase.items.where((i) => r.statusOf(i.id) != ItemStatus.pending).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('تقرير إشراف'),
        actions: [
          IconButton(
            tooltip: 'حفظ',
            icon: const Icon(Icons.check),
            onPressed: () async {
              await _save();
              if (mounted) _msg('تم الحفظ');
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _project,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'اسم المشروع'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _location,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'الموقع'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _engineer,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'المهندس المشرف'),
          ),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: Text('التاريخ: ${fmtDate(r.date)}'),
            trailing: const Icon(Icons.edit_calendar_outlined),
            onTap: _pickDate,
          ),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: r.phaseId,
            decoration: const InputDecoration(labelText: 'المرحلة'),
            items: [
              for (final ph in kPhases)
                DropdownMenuItem(value: ph.id, child: Text(ph.title)),
            ],
            onChanged: (v) async {
              if (v == null) return;
              setState(() => r.phaseId = v);
              await _save();
            },
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: Text('قائمة الفحص',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              Text('$done / ${phase.items.length}'),
            ],
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(
            value: phase.items.isEmpty ? 0 : done / phase.items.length,
            minHeight: 6,
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 10),
          for (final it in phase.items)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(it.text, style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      children: [
                        _statusChip(it, ItemStatus.ok, 'مطابق', Colors.green),
                        _statusChip(
                            it, ItemStatus.notOk, 'غير مطابق', Colors.red),
                        _statusChip(it, ItemStatus.na, 'لا ينطبق', Colors.grey),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Text('الملاحظات والصور',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              TextButton.icon(
                onPressed: _addNote,
                icon: const Icon(Icons.add_a_photo_outlined),
                label: const Text('إضافة'),
              ),
            ],
          ),
          if (r.notes.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('لا توجد ملاحظات بعد.'),
            ),
          for (var i = 0; i < r.notes.length; i++)
            Card(
              child: ListTile(
                leading: r.notes[i].photoPath != null &&
                        File(r.notes[i].photoPath!).existsSync()
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(File(r.notes[i].photoPath!),
                            width: 56, height: 56, fit: BoxFit.cover),
                      )
                    : const Icon(Icons.notes),
                title: Text(r.notes[i].text.isEmpty ? '(صورة)' : r.notes[i].text),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    setState(() => r.notes.removeAt(i));
                    await _save();
                  },
                ),
              ),
            ),
          const SizedBox(height: 10),
          TextField(
            controller: _general,
            onChanged: (_) => _save(),
            minLines: 3,
            maxLines: 8,
            decoration: const InputDecoration(labelText: 'ملاحظات عامة'),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _busy ? null : _makePdf,
            icon: _busy
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('إنشاء تقرير PDF ومشاركته'),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
