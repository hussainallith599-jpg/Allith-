import 'package:flutter/material.dart';
import 'checklist_data.dart';
import 'report_editor.dart';
import 'site_models.dart';

class SupervisionHome extends StatefulWidget {
  const SupervisionHome({super.key});
  @override
  State<SupervisionHome> createState() => _SupervisionHomeState();
}

class _SupervisionHomeState extends State<SupervisionHome> {
  List<SiteReport> _reports = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final list = await ReportsStore.load();
    if (!mounted) return;
    setState(() {
      _reports = list;
      _loading = false;
    });
  }

  Future<void> _open(SiteReport r) async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => ReportEditor(report: r)));
    _reload();
  }

  Future<void> _create() async {
    final r = SiteReport.create();
    await ReportsStore.save(r);
    if (!mounted) return;
    await _open(r);
  }

  Future<void> _delete(SiteReport r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف التقرير'),
        content: const Text('سيتم حذف هذا التقرير نهائياً. هل أنت متأكد؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await ReportsStore.delete(r.id);
      _reload();
    }
  }

  String _progress(SiteReport r) {
    final phase = phaseById(r.phaseId);
    final done =
        phase.items.where((i) => r.statusOf(i.id) != ItemStatus.pending).length;
    return 'تم فحص $done من ${phase.items.length}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإشراف الهندسي')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add),
        label: const Text('تقرير جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _reports.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'لا توجد تقارير بعد.\nاضغط "تقرير جديد" لبدء قائمة فحص لمرحلة من مراحل البناء.',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.7),
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                  itemCount: _reports.length,
                  itemBuilder: (context, i) {
                    final r = _reports[i];
                    final phase = phaseById(r.phaseId);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          leading: Icon(phase.icon, size: 30),
                          title: Text(
                            r.project.isEmpty ? 'مشروع بدون اسم' : r.project,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(
                              '${phase.title} • ${fmtDate(r.date)}\n${_progress(r)}'),
                          isThreeLine: true,
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => _delete(r),
                          ),
                          onTap: () => _open(r),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
