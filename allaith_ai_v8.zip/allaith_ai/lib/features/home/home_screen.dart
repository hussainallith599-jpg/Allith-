import 'package:flutter/material.dart';
import '../../core/widgets/allaith_logo.dart';
import '../chat/chat_screen.dart';
import '../settings/settings_screen.dart';

class _Section {
  final String title;
  final String subtitle;
  final IconData icon;
  final WidgetBuilder? builder;
  const _Section(this.title, this.subtitle, this.icon, [this.builder]);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static final List<_Section> _sections = [
    _Section('المساعد الهندسي', 'استشارات معمارية وإنشائية وأكواد البناء',
        Icons.forum_outlined, (_) => const ChatScreen()),
    const _Section('استوديو الرندر والتصميم الداخلي',
        'توليد تصاميم واقعية واقتراح الأثاث', Icons.chair_outlined),
    const _Section('مولد المخططات المعمارية',
        'توزيع ذكي للمساحات حسب أبعاد الأرض', Icons.grid_view_outlined),
    const _Section('حاسبة الكميات BOQ', 'خرسانة، حديد، بلوك، لياسة، دهان',
        Icons.calculate_outlined),
    const _Section('الإشراف الهندسي', 'قوائم فحص وتقارير الموقع اليومية',
        Icons.fact_check_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الليث AI'),
        actions: [
          IconButton(
            tooltip: 'الإعدادات',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(child: AllaithLogo(height: 150)),
          const SizedBox(height: 8),
          Center(
            child: Text('مساعدك المعماري الذكي',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 20),
          for (final s in _sections)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  leading: Icon(s.icon, size: 32),
                  title: Text(s.title,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(s.subtitle),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () {
                    if (s.builder != null) {
                      Navigator.push(
                          context, MaterialPageRoute(builder: s.builder!));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content:
                              Text('قسم "${s.title}" قادم في الجزء التالي')));
                    }
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }
}
