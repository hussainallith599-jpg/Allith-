import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../../features/chat/chat_message.dart';
import 'settings_service.dart';

class AiException implements Exception {
  final String message;
  AiException(this.message);
  @override
  String toString() => message;
}

class AiTextService {
  AiTextService._();

  static const String systemPrompt = '''
أنت "الليث AI"، مستشار هندسي خبير متخصص حصرياً في الهندسة المعمارية والهندسة المدنية في العالم العربي وخارجه.

نطاق خبرتك:
- التصميم المعماري والإنشائي، التربة والأساسات، الخرسانة المسلحة والمعدنية، العزل والتشطيبات، الإشراف وإدارة المواقع، حساب الكميات.
- الأكواد والمواصفات: الكود السعودي SBC (خاصة 201 و301 و304 و601 وما يتعلق بالحريق والكهرباء والميكانيكا)، الأكواد الأمريكية (ACI 318 وASCE 7 وIBC وAISC وNFPA وASHRAE)، الأوروبية Eurocode، البريطانية BS، الكود المصري، الكود الأردني، كود دول الخليج، والممارسات المحلية في اليمن وغيرها.
- الهوية العمرانية السعودية: الطرز الإقليمية (النجدي، الحجازي، الجنوبي/العسيري، الأحسائي والشرقي)، وتوجهات رؤية 2030 وخريطة العمارة السعودية، وملامح الواجهات المعاصرة المستلهمة منها (الإيقاع، المشربيات، الفتحات الصغيرة، الطين والحجر، الظل والفناء الداخلي).
- العمارة اليمنية التقليدية (صنعاء، حضرموت، شبام، زبيد) وأساليبها ومواد بنائها.

قواعد الإجابة:
1. أجب بالعربية الفصحى المبسطة بأسلوب مهني منظم، وابدأ بالجواب ثم التفصيل.
2. عند أي حساب اذكر المعادلة والافتراضات والوحدات المترية، وتحقق من الأرقام.
3. حدّد الكود المعتمد قبل الإجابة. إن لم يذكر المستخدم البلد أو الكود فاسأله أو اذكر افتراضك صراحة. ولا تخلط بين اشتراطات كودين.
4. اذكر اسم الكود والبند عندما تكون متأكداً منه. وإن لم تكن متأكداً من رقم بند أو قيمة فقل ذلك صراحة ولا تخترع رقماً.
5. استخدم البحث في الويب عندما يتعلق السؤال بإصدار حديث من كود، أو اشتراطات بلدية أو أنظمة حديثة، أو أسعار، أو أي معلومة قد تكون تغيرت. وانسب المعلومة لمصدرها.
6. في المسائل الإنشائية والسلامة نبّه إلى وجوب اعتماد مهندس مرخّص ومراجعة الرسومات قبل التنفيذ.
7. إذا كان السؤال خارج الهندسة المعمارية والمدنية، فاعتذر بلطف ووجّه المستخدم لسؤال هندسي.
''';

  static Future<String> chat(List<ChatMessage> history) async {
    final key = SettingsService.instance.textKey;
    if (key.isEmpty) {
      throw AiException(
          'لم يتم إدخال مفتاح API للنصوص. افتح الإعدادات وأدخل المفتاح.');
    }

    var recent = history.length > 20
        ? history.sublist(history.length - 20)
        : List<ChatMessage>.from(history);
    while (recent.isNotEmpty && recent.first.role != 'user') {
      recent.removeAt(0);
    }
    if (recent.isEmpty) throw AiException('لا توجد رسالة لإرسالها.');

    final body = jsonEncode({
      'model': ApiConfig.textModel,
      'max_tokens': 4000,
      'tools': [
        {'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 5}
      ],
      'system': systemPrompt,
      'messages': recent.map((m) => {'role': m.role, 'content': m.text}).toList(),
    });

    http.Response res;
    try {
      res = await http
          .post(
            Uri.parse(ApiConfig.textApiUrl),
            headers: {
              'content-type': 'application/json',
              'x-api-key': key,
              'anthropic-version': ApiConfig.anthropicVersion,
            },
            body: body,
          )
          .timeout(const Duration(seconds: 150));
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال. تحقق من الإنترنت وحاول مرة أخرى.');
    } catch (_) {
      throw AiException('تعذّر الاتصال بالخادم. تحقق من الإنترنت.');
    }

    dynamic data;
    try {
      data = jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      throw AiException('رد غير مفهوم من الخادم (رمز ${res.statusCode}).');
    }

    if (res.statusCode != 200) {
      throw AiException(_friendly(res.statusCode, data));
    }

    final blocks = (data['content'] as List?) ?? [];
    final text = blocks
        .where((b) => b is Map && b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('')
        .trim();
    if (text.isEmpty) throw AiException('وصل رد فارغ من النموذج.');
    return text;
  }

  static String _friendly(int code, dynamic data) {
    String detail = '';
    try {
      detail = data['error']['message']?.toString() ?? '';
    } catch (_) {}
    switch (code) {
      case 401:
        return 'مفتاح API غير صحيح. راجع الإعدادات.';
      case 403:
        return 'المفتاح لا يملك صلاحية. راجع حسابك.';
      case 404:
        return 'اسم النموذج غير صحيح أو غير متاح لحسابك.\n$detail';
      case 429:
        return 'تجاوزت حد الاستخدام. انتظر قليلاً ثم حاول.';
      case 400:
        return 'طلب غير صالح: $detail';
      default:
        return 'خطأ من الخادم ($code). $detail';
    }
  }
}
