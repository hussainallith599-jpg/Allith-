import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

/// يحفظ مفاتيح الـ API على الجوال نفسه (من شاشة الإعدادات).
class SettingsService {
  SettingsService._();
  static final SettingsService instance = SettingsService._();

  static const _kText = 'text_api_key';
  static const _kImage = 'image_api_key';

  String _text = '';
  String _image = '';

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _text = p.getString(_kText) ?? '';
    _image = p.getString(_kImage) ?? '';
  }

  String get textKey =>
      _text.isNotEmpty ? _text : (ApiConfig.hasTextKey ? ApiConfig.textApiKey : '');
  String get imageKey =>
      _image.isNotEmpty ? _image : (ApiConfig.hasImageKey ? ApiConfig.imageApiKey : '');

  String get rawTextKey => _text;
  String get rawImageKey => _image;

  Future<void> save({required String textKey, required String imageKey}) async {
    _text = textKey.trim();
    _image = imageKey.trim();
    final p = await SharedPreferences.getInstance();
    await p.setString(_kText, _text);
    await p.setString(_kImage, _image);
  }
}
