import 'package:flutter/material.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/services/settings_service.dart';
import '../chat/chat_message.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _text =
      TextEditingController(text: SettingsService.instance.rawTextKey);
  late final TextEditingController _image =
      TextEditingController(text: SettingsService.instance.rawImageKey);
  bool _hideText = true;
  bool _hideImage = true;
  bool _testing = false;

  @override
  void dispose() {
    _text.dispose();
    _image.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    await SettingsService.instance
        .save(textKey: _text.text, imageKey: _image.text);
    if (mounted) _msg('تم حفظ المفاتيح على هذا الجهاز');
  }

  Future<void> _test() async {
    await _save();
    setState(() => _testing = true);
    try {
      await AiTextService.chat(
          [const ChatMessage(role: 'user', text: 'أجب بكلمة واحدة: مرحبا')]);
      if (mounted) _msg('نجح الاتصال ✅ المفتاح يعمل');
    } on AiException catch (e) {
      if (mounted) _msg(e.message);
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('مفاتيح الذكاء الاصطناعي',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text(
              'تُحفظ المفاتيح على جوالك فقط ولا تُرسل إلا إلى شركة الذكاء الاصطناعي عند الاستخدام.'),
          const SizedBox(height: 20),
          TextField(
            controller: _text,
            obscureText: _hideText,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: 'مفتاح المحادثة (Anthropic)',
              hintText: 'sk-ant-...',
              suffixIcon: IconButton(
                icon: Icon(_hideText ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hideText = !_hideText),
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _image,
            obscureText: _hideImage,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: 'مفتاح الصور (OpenAI)',
              hintText: 'sk-...',
              suffixIcon: IconButton(
                icon:
                    Icon(_hideImage ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hideImage = !_hideImage),
              ),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton(onPressed: _save, child: const Text('حفظ')),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _testing ? null : _test,
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(48)),
            child: _testing
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('حفظ واختبار مفتاح المحادثة'),
          ),
        ],
      ),
    );
  }
}
