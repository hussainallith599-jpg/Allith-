import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app.dart';
import 'core/services/settings_service.dart';
import 'features/site_supervision/checklist_data.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SettingsService.instance.load();
  await PhaseRegistry.instance.load();
  runApp(const AllaithApp());
}
