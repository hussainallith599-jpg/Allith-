import 'package:flutter/material.dart';

class AllaithLogo extends StatelessWidget {
  final double height;
  const AllaithLogo({super.key, this.height = 120});

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/logo.png',
      height: height,
      fit: BoxFit.contain,
      semanticLabel: 'شعار الليث AI',
    );
  }
}
