import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

/// يحفظ المزوّد والمفاتيح على الجوال نفسه (من شاشة الإعدادات).
class SettingsService {
  SettingsService._();
  static final SettingsService instance = SettingsService._();

  static const _kText = 'text_api_key';
  static const _kImage = 'image_api_key';
  static const _kGemini = 'gemini_api_key';
  static const _kProvider = 'text_provider';
  static const _kGeminiModel = 'gemini_model';
  static const _kWeb = 'web_search';

  String _text = '';
  String _image = '';
  String _gemini = '';
  String _geminiModel = '';
  bool _webSearch = false;
  String _provider = 'gemini'; // 'gemini' أو 'claude'

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _text = p.getString(_kText) ?? '';
    _image = p.getString(_kImage) ?? '';
    _gemini = p.getString(_kGemini) ?? '';
    _provider = p.getString(_kProvider) ?? 'gemini';
    _geminiModel = p.getString(_kGeminiModel) ?? '';
    _webSearch = p.getBool(_kWeb) ?? false;
  }

  String get provider => _provider;
  String get textKey =>
      _text.isNotEmpty ? _text : (ApiConfig.hasTextKey ? ApiConfig.textApiKey : '');
  String get imageKey =>
      _image.isNotEmpty ? _image : (ApiConfig.hasImageKey ? ApiConfig.imageApiKey : '');
  bool get webSearch => _webSearch;
  String get geminiKey => _gemini;
  String get rawGeminiModel => _geminiModel;
  String get geminiModel =>
      _geminiModel.isNotEmpty ? _geminiModel : ApiConfig.geminiModel;

  String get rawTextKey => _text;
  String get rawImageKey => _image;

  Future<void> save({
    required String provider,
    required String textKey,
    required String imageKey,
    required String geminiKey,
    required String geminiModel,
    required bool webSearch,
  }) async {
    _provider = provider;
    _text = textKey.trim();
    _image = imageKey.trim();
    _gemini = geminiKey.trim();
    _geminiModel = geminiModel.trim();
    _webSearch = webSearch;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kProvider, _provider);
    await p.setString(_kText, _text);
    await p.setString(_kImage, _image);
    await p.setString(_kGemini, _gemini);
    await p.setString(_kGeminiModel, _geminiModel);
    await p.setBool(_kWeb, _webSearch);
  }
}
