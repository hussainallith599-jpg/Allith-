import 'package:flutter/material.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/services/settings_service.dart';
import '../chat/chat_message.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _s = SettingsService.instance;
  late String _provider = _s.provider;
  late final TextEditingController _gemini =
      TextEditingController(text: _s.geminiKey);
  late final TextEditingController _model = TextEditingController(
      text: _s.rawGeminiModel.isNotEmpty ? _s.rawGeminiModel : _s.geminiModel);
  late final TextEditingController _text =
      TextEditingController(text: _s.rawTextKey);
  late final TextEditingController _image =
      TextEditingController(text: _s.rawImageKey);
  bool _testing = false;
  late bool _web = _s.webSearch;

  @override
  void dispose() {
    _gemini.dispose();
    _model.dispose();
    _text.dispose();
    _image.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    await _s.save(
      provider: _provider,
      textKey: _text.text,
      imageKey: _image.text,
      geminiKey: _gemini.text,
      geminiModel: _model.text,
      webSearch: _web,
    );
    if (mounted) _msg('تم الحفظ على هذا الجهاز');
  }

  Future<void> _test() async {
    await _save();
    setState(() => _testing = true);
    try {
      await AiTextService.chat(
          [const ChatMessage(role: 'user', text: 'أجب بكلمة واحدة: مرحبا')]);
      if (mounted) _msg('نجح الاتصال ✅ المفتاح يعمل');
    } on AiException catch (e) {
      if (mounted) _msg(e.message);
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Widget _keyField(TextEditingController c, String label, String hint) {
    return _KeyField(controller: c, label: label, hint: hint);
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('مزوّد المحادثة',
              style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'gemini', label: Text('Gemini (مجاني)')),
              ButtonSegment(value: 'claude', label: Text('Claude (مدفوع)')),
            ],
            selected: {_provider},
            onSelectionChanged: (v) => setState(() => _provider = v.first),
          ),
          const SizedBox(height: 16),
          if (_provider == 'gemini') ...[
            const Text(
                'مفتاح مجاني من aistudio.google.com بدون بطاقة بنكية. الحد المجاني محدود، وقد تُستخدم أسئلتك من Google لتحسين منتجاتها، فلا ترسل بيانات سرية.'),
            const SizedBox(height: 12),
            _keyField(_gemini, 'مفتاح Gemini', 'AIza...'),
            const SizedBox(height: 12),
            TextField(
              controller: _model,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                  labelText: 'اسم النموذج', hintText: 'gemini-3.8-flash'),
            ),
          ] else ...[
            const Text('مفتاح من console.anthropic.com (يحتاج رصيداً مدفوعاً).'),
            const SizedBox(height: 12),
            _keyField(_text, 'مفتاح Claude', 'sk-ant-...'),
          ],
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('البحث في الويب'),
            subtitle: const Text('يجعل الإجابة أبطأ، فعّله عند الحاجة فقط'),
            value: _web,
            onChanged: (v) => setState(() => _web = v),
          ),
          const SizedBox(height: 24),
          Text('مفتاح الصور (للرندر لاحقاً)',
              style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          _keyField(_image, 'مفتاح الصور', 'اتركه فارغاً الآن'),
          const SizedBox(height: 24),
          FilledButton(onPressed: _save, child: const Text('حفظ')),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _testing ? null : _test,
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(48)),
            child: _testing
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('حفظ واختبار المحادثة'),
          ),
        ],
      ),
    );
  }
}

class _KeyField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  const _KeyField(
      {required this.controller, required this.label, required this.hint});
  @override
  State<_KeyField> createState() => _KeyFieldState();
}

class _KeyFieldState extends State<_KeyField> {
  bool _hide = true;
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      obscureText: _hide,
      textDirection: TextDirection.ltr,
      decoration: InputDecoration(
        labelText: widget.label,
        hintText: widget.hint,
        suffixIcon: IconButton(
          icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
          onPressed: () => setState(() => _hide = !_hide),
        ),
      ),
    );
  }
}
