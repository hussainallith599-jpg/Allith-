class ChatMessage {
  final String role; // 'user' أو 'assistant'
  final String text;
  const ChatMessage({required this.role, required this.text});

  Map<String, dynamic> toJson() => {'role': role, 'text': text};

  factory ChatMessage.fromJson(Map<String, dynamic> j) =>
      ChatMessage(role: j['role'] as String, text: j['text'] as String);
}
