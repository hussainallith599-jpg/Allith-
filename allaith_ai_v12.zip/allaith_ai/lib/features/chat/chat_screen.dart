import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/theme/app_theme.dart';
import '../settings/settings_screen.dart';
import 'chat_message.dart';

class _Conv {
  String id;
  String title;
  int updated;
  List<ChatMessage> messages;
  _Conv({
    required this.id,
    this.title = 'محادثة جديدة',
    required this.updated,
    List<ChatMessage>? messages,
  }) : messages = messages ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'updated': updated,
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory _Conv.fromJson(Map<String, dynamic> j) => _Conv(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? 'محادثة',
        updated: (j['updated'] as int?) ?? 0,
        messages: ((j['messages'] as List?) ?? [])
            .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static const _prefsKey = 'chats_v2';
  static const _oldKey = 'chat_history_v1';
  static const _suggestions = [
    'ما الحد الأدنى لغطاء الخرسانة للأعمدة والقواعد؟',
    'كيف أحدد أبعاد قاعدة منفصلة لعمود؟',
    'ما الفرق بين السقف المصمت والهوردي؟',
    'كيف أعالج رطوبة الجدران في الطابق الأرضي؟',
  ];

  final _controller = TextEditingController();
  final _scroll = ScrollController();
  List<_Conv> _convs = [];
  late _Conv _cur = _newConv();
  bool _loading = false;
  String? _error;

  _Conv _newConv() => _Conv(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      updated: DateTime.now().millisecondsSinceEpoch);

  List<ChatMessage> get _messages => _cur.messages;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _titleOf(List<ChatMessage> msgs) {
    final first = msgs.firstWhere((m) => m.role == 'user',
        orElse: () => const ChatMessage(role: 'user', text: 'محادثة'));
    final t = first.text.replaceAll('\n', ' ').trim();
    return t.length > 40 ? '${t.substring(0, 40)}…' : t;
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_prefsKey);
    final list = <_Conv>[];
    if (raw != null) {
      try {
        list.addAll((jsonDecode(raw) as List)
            .map((e) => _Conv.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    } else {
      final old = p.getString(_oldKey);
      if (old != null) {
        try {
          final msgs = (jsonDecode(old) as List)
              .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
              .toList();
          if (msgs.isNotEmpty) {
            list.add(_Conv(
                id: 'old',
                title: _titleOf(msgs),
                updated: DateTime.now().millisecondsSinceEpoch,
                messages: msgs));
          }
        } catch (_) {}
      }
    }
    list.sort((a, b) => b.updated.compareTo(a.updated));
    if (!mounted) return;
    setState(() {
      _convs = list;
      _cur = list.isNotEmpty ? list.first : _newConv();
    });
    _scrollToEnd();
  }

  Future<void> _persist() async {
    if (_cur.messages.isNotEmpty) {
      _cur.title = _titleOf(_cur.messages);
      _cur.updated = DateTime.now().millisecondsSinceEpoch;
      if (!_convs.any((c) => c.id == _cur.id)) _convs.add(_cur);
    }
    _convs.sort((a, b) => b.updated.compareTo(a.updated));
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _prefsKey, jsonEncode(_convs.map((c) => c.toJson()).toList()));
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _controller.text).trim();
    if (text.isEmpty || _loading) return;
    setState(() {
      _messages.add(ChatMessage(role: 'user', text: text));
      _loading = true;
      _error = null;
      _controller.clear();
    });
    _scrollToEnd();
    try {
      final reply = await AiTextService.chat(_messages);
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(role: 'assistant', text: reply)));
      await _persist();
    } on AiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = 'حدث خطأ غير متوقع: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToEnd();
    }
  }

  void _startNew() {
    if (_loading) return;
    if (_cur.messages.isEmpty) return;
    setState(() {
      _cur = _newConv();
      _error = null;
    });
  }

  Future<void> _copy(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('تم النسخ')));
  }

  String _fmt(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}/${d.month}/${d.day}';
  }

  void _openHistory() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final list = _convs.where((c) => c.messages.isNotEmpty).toList();
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.7),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('المحادثات السابقة',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                if (list.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('لا توجد محادثات محفوظة بعد'),
                  )
                else
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final c = list[i];
                        return ListTile(
                          leading: Icon(c.id == _cur.id
                              ? Icons.chat_bubble
                              : Icons.chat_bubble_outline),
                          title: Text(c.title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(_fmt(c.updated)),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              _convs.removeWhere((x) => x.id == c.id);
                              if (c.id == _cur.id) {
                                setState(() => _cur = _newConv());
                              }
                              await _persist();
                              setSheet(() {});
                            },
                          ),
                          onTap: () {
                            if (_loading) return;
                            setState(() {
                              _cur = c;
                              _error = null;
                            });
                            Navigator.pop(ctx);
                            _scrollToEnd();
                          },
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المساعد الهندسي'),
        actions: [
          IconButton(
            tooltip: 'محادثة جديدة',
            icon: const Icon(Icons.add_comment_outlined),
            onPressed: _startNew,
          ),
          IconButton(
            tooltip: 'المحادثات السابقة',
            icon: const Icon(Icons.history),
            onPressed: _openHistory,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _messages.isEmpty ? _empty() : _list()),
          if (_error != null) _errorBar(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _empty() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 16),
        const Icon(Icons.architecture, size: 56),
        const SizedBox(height: 12),
        Text('اسأل الليث عن أي موضوع معماري أو إنشائي',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 20),
        for (final s in _suggestions)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                title: Text(s),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => _send(s),
              ),
            ),
          ),
      ],
    );
  }

  Widget _list() {
    return SelectionArea(
      child: ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.all(12),
        itemCount: _messages.length + (_loading ? 1 : 0),
        itemBuilder: (context, i) {
          if (i == _messages.length) return _typing();
          return _bubble(_messages[i]);
        },
      ),
    );
  }

  Widget _miniBtn(IconData icon, String label, VoidCallback onTap) {
    return TextButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: TextButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        foregroundColor: Colors.black54,
      ),
    );
  }

  Widget _bubble(ChatMessage m) {
    final isUser = m.role == 'user';
    final maxW = MediaQuery.of(context).size.width * 0.86;
    return Align(
      alignment: isUser
          ? AlignmentDirectional.centerStart
          : AlignmentDirectional.centerEnd,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxW),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isUser ? AppColors.ink : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: isUser ? null : Border.all(color: AppColors.border),
        ),
        child: isUser
            ? Text(m.text,
                style: const TextStyle(color: Colors.white, height: 1.5))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  MarkdownBody(
                    data: m.text,
                    selectable: false,
                    styleSheet:
                        MarkdownStyleSheet.fromTheme(Theme.of(context))
                            .copyWith(p: const TextStyle(height: 1.6, fontSize: 15)),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _miniBtn(Icons.copy, 'نسخ الرد', () => _copy(m.text)),
                      _miniBtn(Icons.share_outlined, 'مشاركة',
                          () => Share.share(m.text)),
                    ],
                  ),
                ],
              ),
      ),
    );
  }

  Widget _typing() {
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
              height: 16,
              width: 16,
              child: CircularProgressIndicator(strokeWidth: 2)),
          SizedBox(width: 10),
          Text('الليث يكتب...'),
        ]),
      ),
    );
  }

  Widget _errorBar() {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF1F0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Expanded(
              child: SelectableText(_error!,
                  style: const TextStyle(color: Color(0xFFB42318)))),
          TextButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
            child: const Text('الإعدادات'),
          ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: const InputDecoration(
                  hintText: 'اكتب سؤالك الهندسي...',
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: _loading ? null : () => _send(),
              style: IconButton.styleFrom(
                  backgroundColor: AppColors.ink,
                  minimumSize: const Size(48, 48)),
              icon: const Icon(Icons.send, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
