import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'brand_store.dart';
import 'checklist_data.dart';
import 'report_style.dart';
import 'site_models.dart';

class _Pic {
  final String rid;
  final String fileName;
  final Uint8List bytes;
  final int w;
  final int h;
  _Pic(this.rid, this.fileName, this.bytes, this.w, this.h);
}

/// ينشئ ملف Word (.docx) عربي RTL بدون أي مكتبة خارجية سوى الضغط.
class ReportDocx {
  ReportDocx._();

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static String _run(String text,
      {bool bold = false, int size = 22, String? color}) {
    return '<w:r><w:rPr>'
        '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
        '${bold ? '<w:b/><w:bCs/>' : ''}'
        '${color != null ? '<w:color w:val="$color"/>' : ''}'
        '<w:sz w:val="$size"/><w:szCs w:val="$size"/><w:rtl/>'
        '</w:rPr><w:t xml:space="preserve">${_esc(text)}</w:t></w:r>';
  }

  static String _p(String inner, {String? jc, int after = 80}) {
    return '<w:p><w:pPr><w:bidi/><w:spacing w:after="$after"/>'
        '${jc != null ? '<w:jc w:val="$jc"/>' : ''}</w:pPr>$inner</w:p>';
  }

  static String _text(String text,
          {bool bold = false,
          int size = 22,
          String? color,
          String? jc,
          int after = 80}) =>
      _p(_run(text, bold: bold, size: size, color: color),
          jc: jc, after: after);

  static String _tc(String inner, int w, {String? fill}) {
    return '<w:tc><w:tcPr><w:tcW w:w="$w" w:type="dxa"/>'
        '${fill != null ? '<w:shd w:val="clear" w:color="auto" w:fill="$fill"/>' : ''}'
        '</w:tcPr>$inner</w:tc>';
  }

  static String _table(List<int> widths, List<String> rows) {
    const b = '<w:{n} w:val="single" w:sz="4" w:space="0" w:color="9E9E9E"/>';
    String border(String n) => b.replaceAll('{n}', n);
    final total = widths.fold<int>(0, (a, x) => a + x);
    return '<w:tbl><w:tblPr><w:bidiVisual/>'
        '<w:tblW w:w="$total" w:type="dxa"/>'
        '<w:tblBorders>${border('top')}${border('left')}${border('bottom')}${border('right')}${border('insideH')}${border('insideV')}</w:tblBorders>'
        '<w:tblLayout w:type="fixed"/>'
        '<w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="80" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar>'
        '</w:tblPr><w:tblGrid>${widths.map((w) => '<w:gridCol w:w="$w"/>').join()}</w:tblGrid>'
        '${rows.join()}</w:tbl>';
  }

  static String _tr(List<String> cells) => '<w:tr>${cells.join()}</w:tr>';

  static String _image(_Pic pic, int id, double maxCm, {bool center = false}) {
    final maxEmu = (maxCm * 360000).round();
    final ratio = pic.h / pic.w;
    var cx = maxEmu;
    var cy = (maxEmu * ratio).round();
    const maxH = 3600000; // 10 سم
    if (cy > maxH) {
      cy = maxH;
      cx = (maxH / ratio).round();
    }
    return '<w:p><w:pPr><w:bidi/>${center ? '<w:jc w:val="center"/>' : ''}</w:pPr><w:r><w:drawing>'
        '<wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="$cx" cy="$cy"/>'
        '<wp:docPr id="$id" name="Picture $id"/>'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="$id" name="${pic.fileName}"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="${pic.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
        '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
  }

  /// ترويسة تحمل الشعار كعلامة مائية خلف النص في منتصف الصفحة.
  static String _headerXml(_Pic pic, double opacity) {
    const maxEmu = 4320000; // 12 سم
    final ratio = pic.h / pic.w;
    var cx = maxEmu;
    var cy = (maxEmu * ratio).round();
    if (cy > 5400000) {
      cy = 5400000;
      cx = (5400000 / ratio).round();
    }
    final alpha = (opacity * 100000).round();
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
        '<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:drawing>'
        '<wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="0" behindDoc="1" locked="0" layoutInCell="1" allowOverlap="1">'
        '<wp:simplePos x="0" y="0"/>'
        '<wp:positionH relativeFrom="page"><wp:align>center</wp:align></wp:positionH>'
        '<wp:positionV relativeFrom="page"><wp:align>center</wp:align></wp:positionV>'
        '<wp:extent cx="$cx" cy="$cy"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/>'
        '<wp:docPr id="900" name="Watermark"/><wp:cNvGraphicFramePr/>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="900" name="watermark"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="rIdWm"><a:alphaModFix amt="$alpha"/></a:blip><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
        '</pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p></w:hdr>';
  }

  static Future<(int, int)> _size(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final w = frame.image.width;
    final h = frame.image.height;
    frame.image.dispose();
    return (w, h);
  }

  static String _statusLabel(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return 'مطابق';
      case ItemStatus.notOk:
        return 'غير مطابق';
      case ItemStatus.na:
        return 'لا ينطبق';
      case ItemStatus.pending:
        return 'لم يُفحص';
    }
  }

  static String _statusColor(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return '2E7D32';
      case ItemStatus.notOk:
        return 'C62828';
      case ItemStatus.na:
        return '616161';
      case ItemStatus.pending:
        return 'EF6C00';
    }
  }

  static Future<void> shareReport(SiteReport r) async {
    final style = ReportStyle.fromJsonString(r.styleJson);
    final accent = style.accentColor;
    final tint = style.tintHex(0.15);
    final phase = phaseById(r.phaseId);
    final items = reportItems(r);
    final pics = <_Pic>[];
    var imgCounter = 0;

    Future<_Pic?> addPic(Uint8List bytes, String ext) async {
      try {
        final (w, h) = await _size(bytes);
        imgCounter++;
        final pic = _Pic('rId${imgCounter + 10}', 'image$imgCounter.$ext',
            bytes, w, h);
        pics.add(pic);
        return pic;
      } catch (_) {
        return null;
      }
    }

    _Pic? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) logo = await addPic(lb.bytes, lb.ext);
    } catch (_) {}

    var ok = 0, bad = 0, na = 0, pending = 0;
    for (final it in items) {
      switch (r.statusOf(it.id)) {
        case ItemStatus.ok:
          ok++;
          break;
        case ItemStatus.notOk:
          bad++;
          break;
        case ItemStatus.na:
          na++;
          break;
        case ItemStatus.pending:
          pending++;
          break;
      }
    }

    final body = StringBuffer();
    var drawId = 1;

    if (logo != null && style.logoInHeader) {
      body.write(_image(logo, drawId++, 3.2, center: true));
      if (style.officeName != null) {
        body.write(_text(style.officeName!, size: 20, jc: 'center', after: 60));
      }
    }
    body.write(_text(style.title ?? 'تقرير الإشراف الهندسي',
        bold: true, size: 36, color: accent, jc: 'center', after: 40));
    body.write(
        _text('المرحلة: ${phase.title}', size: 26, jc: 'center', after: 160));
    if (style.introText != null) {
      body.write(_text(style.introText!, after: 160));
    }

    const infoW = [2500, 7400];
    String info(String label, String value) => _tr([
          _tc(_text(label, bold: true, after: 0), infoW[0], fill: tint),
          _tc(_text(value.isEmpty ? '—' : value, after: 0), infoW[1]),
        ]);
    body.write(_table(infoW, [
      info('المشروع', r.project),
      info('الموقع', r.location),
      info('المهندس المشرف', r.engineer),
      info('التاريخ', fmtDate(r.date)),
    ]));
    body.write(_text('', after: 60));
    body.write(_text(
        'نسبة الإنجاز الكلية: ${overallProgress(r)}%   |   مطابق $ok   |   غير مطابق $bad   |   لا ينطبق $na   |   لم يُفحص $pending',
        bold: true,
        size: 22,
        after: 120));

    final sp = style.showProgress;
    final w = sp ? [600, 5600, 1900, 1800] : [700, 7200, 2000];
    final rows = <String>[
      _tr([
        _tc(_text('#', bold: true, jc: 'center', after: 0), w[0], fill: tint),
        _tc(_text('بند الفحص', bold: true, after: 0), w[1], fill: tint),
        _tc(_text('الحالة', bold: true, jc: 'center', after: 0), w[2],
            fill: tint),
        if (sp)
          _tc(_text('الإنجاز', bold: true, jc: 'center', after: 0), w[3],
              fill: tint),
      ]),
      for (var i = 0; i < items.length; i++)
        _tr([
          _tc(_text('${i + 1}', size: 20, jc: 'center', after: 0), w[0]),
          _tc(_text(items[i].text, size: 20, after: 0), w[1]),
          _tc(
              _text(_statusLabel(r.statusOf(items[i].id)),
                  bold: true,
                  size: 20,
                  color: _statusColor(r.statusOf(items[i].id)),
                  jc: 'center',
                  after: 0),
              w[2]),
          if (sp)
            _tc(
                _text('${r.progressOf(items[i].id)}%',
                    size: 20, jc: 'center', after: 0),
                w[3]),
        ]),
    ];
    body.write(_table(w, rows));

    if (r.notes.isNotEmpty) {
      body.write(_text('', after: 80));
      body.write(_text('الملاحظات والصور', bold: true, size: 26, after: 100));
      for (var i = 0; i < r.notes.length; i++) {
        final n = r.notes[i];
        if (n.text.trim().isNotEmpty) {
          body.write(_text('${i + 1}. ${n.text}', after: 60));
        }
        if (n.photoPath != null && File(n.photoPath!).existsSync()) {
          final bytes = await File(n.photoPath!).readAsBytes();
          final pic = await addPic(bytes, 'jpg');
          if (pic != null) {
            body.write(_image(pic, drawId++, 9));
          }
        }
      }
    }

    if (r.general.trim().isNotEmpty) {
      body.write(_text('', after: 80));
      body.write(_text('ملاحظات عامة', bold: true, size: 26, after: 80));
      body.write(_text(r.general));
    }

    body.write(_text('', after: 200));
    final sigs = style.signatures;
    final cols = <String>[
      for (final sg in sigs)
        _text(sg, bold: true, jc: 'center', after: 400),
      if (style.stampBox) _text('مكان الختم', jc: 'center', after: 400),
    ];
    if (cols.isNotEmpty) {
      final cw = (9900 / cols.length).floor();
      body.write(_table(
        List<int>.filled(cols.length, cw),
        [
          _tr([for (final c in cols) _tc(c, cw)]),
          _tr([
            for (var i = 0; i < cols.length; i++)
              _tc(_text('______________', jc: 'center', after: 0), cw)
          ]),
        ],
      ));
    }
    body.write(_text('', after: 120));
    body.write(_text(style.footerText ?? 'أُنشئ بواسطة تطبيق الليث AI',
        size: 16, color: '757575'));

    final wm = (style.watermark && logo != null) ? logo : null;
    final headerXml = wm == null
        ? ''
        : _headerXml(wm, style.watermarkOpacity);

    final documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
        '<w:body>$body'
        '<w:sectPr>${wm != null ? '<w:headerReference w:type="default" r:id="rIdHdr"/>' : ''}<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000" w:header="708" w:footer="708" w:gutter="0"/>'
        '<w:bidi/></w:sectPr></w:body></w:document>';

    final contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Default Extension="png" ContentType="image/png"/>'
        '<Default Extension="jpg" ContentType="image/jpeg"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '${wm != null ? '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' : ''}'
        '</Types>';

    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '</Relationships>';

    final docRels = StringBuffer(
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">');
    for (final p in pics) {
      docRels.write(
          '<Relationship Id="${p.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${p.fileName}"/>');
    }
    if (wm != null) {
      docRels.write(
          '<Relationship Id="rIdHdr" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>');
    }
    docRels.write('</Relationships>');

    final archive = Archive();
    void add(String name, List<int> data) =>
        archive.addFile(ArchiveFile(name, data.length, data));
    add('[Content_Types].xml', utf8.encode(contentTypes));
    add('_rels/.rels', utf8.encode(rootRels));
    add('word/document.xml', utf8.encode(documentXml));
    add('word/_rels/document.xml.rels', utf8.encode(docRels.toString()));
    if (wm != null) {
      add('word/header1.xml', utf8.encode(headerXml));
      add(
          'word/_rels/header1.xml.rels',
          utf8.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
              '<Relationship Id="rIdWm" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${wm.fileName}"/>'
              '</Relationships>'));
    }
    for (final p in pics) {
      add('word/media/${p.fileName}', p.bytes);
    }

    final zipped = ZipEncoder().encode(archive);
    if (zipped == null) throw Exception('zip failed');

    final d = DateTime.fromMillisecondsSinceEpoch(r.date);
    final name =
        'site_report_${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}.docx';
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(zipped, flush: true);
    await Share.shareXFiles([
      XFile(file.path,
          mimeType:
              'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    ]);
  }
}
