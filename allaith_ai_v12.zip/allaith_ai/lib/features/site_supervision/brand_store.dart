import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BrandLogo {
  final Uint8List bytes;
  final String ext; // png أو jpg
  BrandLogo(this.bytes, this.ext);
}

/// شعار المكتب المرفوع من المستخدم (يُستخدم في التقارير بدل الشعار الافتراضي).
class BrandStore {
  BrandStore._();
  static const _key = 'office_logo_path';

  static Future<String?> customPath() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString(_key);
    if (path != null && File(path).existsSync()) return path;
    return null;
  }

  static String? _extOf(String path) {
    final e = p.extension(path).toLowerCase().replaceAll('.', '');
    if (e == 'png') return 'png';
    if (e == 'jpg' || e == 'jpeg') return 'jpg';
    return null;
  }

  /// يعيد false إذا كان نوع الصورة غير مدعوم (يلزم PNG أو JPG).
  static Future<bool> setLogo(String sourcePath) async {
    final ext = _extOf(sourcePath);
    if (ext == null) return false;
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(dir.path, 'brand'));
    if (!folder.existsSync()) folder.createSync(recursive: true);
    final dest = p.join(
        folder.path, 'logo_${DateTime.now().microsecondsSinceEpoch}.$ext');
    await File(sourcePath).copy(dest);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, dest);
    return true;
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  static Future<BrandLogo?> logoBytes() async {
    final path = await customPath();
    if (path != null) {
      final ext = _extOf(path);
      if (ext != null) {
        return BrandLogo(await File(path).readAsBytes(), ext);
      }
    }
    try {
      final data = await rootBundle.load('assets/images/logo.png');
      return BrandLogo(data.buffer.asUint8List(), 'png');
    } catch (_) {
      return null;
    }
  }
}
