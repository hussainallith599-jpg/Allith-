import 'dart:convert';
import '../../core/services/ai_text_service.dart';

/// إعدادات شكل التقرير، يولّدها الذكاء الاصطناعي من طلب المستخدم النصي.
class ReportStyle {
  bool watermark = false;
  double watermarkOpacity = 0.08;
  bool logoInHeader = true;
  String? officeName;
  String accentColor = '000000';
  String? title;
  String? introText;
  bool stampBox = false;
  List<String> signatures = ['المهندس المشرف', 'المقاول'];
  String? footerText;
  bool showProgress = true;

  static final _hex = RegExp(r'^[0-9A-Fa-f]{6}$');

  /// لون فاتح مشتق من لون التمييز (للخلفيات).
  String tintHex(double f) {
    final r = int.parse(accentColor.substring(0, 2), radix: 16);
    final g = int.parse(accentColor.substring(2, 4), radix: 16);
    final b = int.parse(accentColor.substring(4, 6), radix: 16);
    int t(int c) => (255 - (255 - c) * f).round().clamp(0, 255);
    String h(int v) => v.toRadixString(16).padLeft(2, '0');
    return (h(t(r)) + h(t(g)) + h(t(b))).toUpperCase();
  }

  Map<String, dynamic> toJson() => {
        'watermark': watermark,
        'watermarkOpacity': watermarkOpacity,
        'logoInHeader': logoInHeader,
        'officeName': officeName,
        'accentColor': accentColor,
        'title': title,
        'introText': introText,
        'stampBox': stampBox,
        'signatures': signatures,
        'footerText': footerText,
        'showProgress': showProgress,
      };

  String toJsonString() => jsonEncode(toJson());

  static ReportStyle fromJsonString(String s) {
    final st = ReportStyle();
    if (s.trim().isEmpty) return st;
    try {
      st.merge(Map<String, dynamic>.from(jsonDecode(s) as Map));
    } catch (_) {}
    return st;
  }

  String? _str(dynamic v) {
    if (v is String && v.trim().isNotEmpty) return v.trim();
    return null;
  }

  /// يدمج التغييرات الواردة فقط؛ القيم الفارغة (null) تُتجاهل.
  void merge(Map<String, dynamic> j) {
    if (j['watermark'] is bool) watermark = j['watermark'] as bool;
    if (j['watermarkOpacity'] is num) {
      watermarkOpacity =
          (j['watermarkOpacity'] as num).toDouble().clamp(0.04, 0.25);
    }
    if (j['logoInHeader'] is bool) logoInHeader = j['logoInHeader'] as bool;
    final on = _str(j['officeName']);
    if (on != null) officeName = on;
    final ac = _str(j['accentColor'])?.replaceAll('#', '');
    if (ac != null && _hex.hasMatch(ac)) accentColor = ac.toUpperCase();
    final t = _str(j['title']);
    if (t != null) title = t;
    final it = _str(j['introText']);
    if (it != null) introText = it;
    if (j['stampBox'] is bool) stampBox = j['stampBox'] as bool;
    if (j['signatures'] is List) {
      final l = (j['signatures'] as List)
          .map((e) => e.toString().trim())
          .where((e) => e.isNotEmpty)
          .take(4)
          .toList();
      signatures = l;
    }
    final ft = _str(j['footerText']);
    if (ft != null) footerText = ft;
    if (j['showProgress'] is bool) showProgress = j['showProgress'] as bool;
  }

  List<String> summary() {
    final out = <String>[];
    if (watermark) {
      out.add('علامة مائية (${(watermarkOpacity * 100).round()}%)');
    }
    if (!logoInHeader) out.add('بدون شعار في الترويسة');
    if (officeName != null) out.add('اسم المكتب: $officeName');
    if (accentColor != '000000') out.add('لون العناوين: #$accentColor');
    if (title != null) out.add('عنوان: $title');
    if (introText != null) out.add('فقرة افتتاحية');
    if (stampBox) out.add('مكان للختم');
    if (signatures.isEmpty) {
      out.add('بدون خانات توقيع');
    } else {
      out.add('توقيعات: ${signatures.join('، ')}');
    }
    if (footerText != null) out.add('تذييل مخصص');
    if (!showProgress) out.add('بدون عمود الإنجاز');
    return out;
  }

  static const _system = '''
أنت مساعد يحوّل طلب المستخدم عن شكل تقرير هندسي إلى إعدادات تنسيق.
أعد كائن JSON فقط، بدون أي شرح وبدون علامات ```، وبالمفاتيح التالية فقط. اكتب فقط المفاتيح التي يطلبها المستخدم صراحة أو ضمناً، واترك الباقي غير موجود:
- "watermark": true أو false (استخدام الشعار علامة مائية خلف نص التقرير)
- "watermarkOpacity": رقم بين 0.04 و 0.25 (وضوح العلامة المائية)
- "logoInHeader": true أو false (إظهار الشعار أعلى التقرير)
- "officeName": اسم المكتب ليظهر تحت الشعار
- "accentColor": لون سداسي بدون # مثل "1A3C6E" لعناوين التقرير وخلفيات الجدول (اختر لوناً هادئاً مناسباً إن طلب "هوية بصرية" دون لون محدد)
- "title": عنوان بديل للتقرير
- "introText": فقرة افتتاحية رسمية قصيرة تُكتب قبل الجدول
- "stampBox": true أو false (مكان لختم المكتب)
- "signatures": قائمة بعناوين خانات التوقيع، مثل ["المهندس المشرف","المقاول","مدير المشروع"] (حتى 4)
- "footerText": نص التذييل
- "showProgress": true أو false (عمود نسبة الإنجاز)
اكتب النصوص بالعربية الفصحى.
''';

  /// يرسل الطلب للذكاء الاصطناعي ثم يدمج النتيجة في هذا الكائن.
  Future<void> applyRequest(String request) async {
    final raw = await AiTextService.askOnce(_system, 'طلب المستخدم: $request');
    var clean = raw.trim();
    clean = clean.replaceAll(RegExp(r'^```(?:json)?', multiLine: false), '');
    clean = clean.replaceAll('```', '').trim();
    final start = clean.indexOf('{');
    final end = clean.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw const FormatException('no json');
    }
    final map = Map<String, dynamic>.from(
        jsonDecode(clean.substring(start, end + 1)) as Map);
    merge(map);
  }
}
