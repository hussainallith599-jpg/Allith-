import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'brand_store.dart';
import 'checklist_data.dart';
import 'report_style.dart';
import 'site_models.dart';

class ReportPdf {
  ReportPdf._();

  static pw.Widget _t(String text,
      {double size = 11,
      bool bold = false,
      PdfColor color = PdfColors.black,
      pw.TextAlign align = pw.TextAlign.right}) {
    return pw.Text(
      text,
      textDirection: pw.TextDirection.rtl,
      textAlign: align,
      style: pw.TextStyle(
        fontSize: size,
        color: color,
        fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
      ),
    );
  }

  static String _statusLabel(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return 'مطابق';
      case ItemStatus.notOk:
        return 'غير مطابق';
      case ItemStatus.na:
        return 'لا ينطبق';
      case ItemStatus.pending:
        return 'لم يُفحص';
    }
  }

  static PdfColor _statusColor(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return PdfColors.green800;
      case ItemStatus.notOk:
        return PdfColors.red800;
      case ItemStatus.na:
        return PdfColors.grey700;
      case ItemStatus.pending:
        return PdfColors.orange800;
    }
  }

  static pw.Widget _cell(pw.Widget child, {PdfColor? bg}) => pw.Container(
        color: bg,
        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        child: child,
      );

  /// يبني ملف PDF ويفتح نافذة المشاركة.
  static Future<void> shareReport(SiteReport r) async {
    final style = ReportStyle.fromJsonString(r.styleJson);
    final accent = PdfColor.fromHex('#${style.accentColor}');
    final tint = PdfColor.fromHex('#${style.tintHex(0.15)}');
    final regular = await PdfGoogleFonts.cairoRegular();
    final bold = await PdfGoogleFonts.cairoBold();
    final phase = phaseById(r.phaseId);
    final items = reportItems(r);

    pw.MemoryImage? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) logo = pw.MemoryImage(lb.bytes);
    } catch (_) {}
    final wmLogo = logo;

    var ok = 0, bad = 0, na = 0, pending = 0;
    for (final it in items) {
      switch (r.statusOf(it.id)) {
        case ItemStatus.ok:
          ok++;
          break;
        case ItemStatus.notOk:
          bad++;
          break;
        case ItemStatus.na:
          na++;
          break;
        case ItemStatus.pending:
          pending++;
          break;
      }
    }

    final photos = <pw.Widget>[];
    for (final n in r.notes) {
      pw.Widget? img;
      if (n.photoPath != null && File(n.photoPath!).existsSync()) {
        final bytes = await File(n.photoPath!).readAsBytes();
        img = pw.Container(
          height: 130,
          child: pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.contain),
        );
      }
      photos.add(pw.Container(
        width: 250,
        margin: const pw.EdgeInsets.only(bottom: 8),
        padding: const pw.EdgeInsets.all(6),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey400, width: 0.5),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            if (img != null) img,
            if (img != null) pw.SizedBox(height: 4),
            if (n.text.trim().isNotEmpty) _t(n.text, size: 10),
          ],
        ),
      ));
    }

    // رؤوس الجدول وصفوفه (الترتيب من اليسار لليمين بصرياً)
    final sp = style.showProgress;
    final headerCells = <pw.Widget>[
      if (sp) _cell(_t('الإنجاز', bold: true, align: pw.TextAlign.center)),
      _cell(_t('الحالة', bold: true, align: pw.TextAlign.center)),
      _cell(_t('بند الفحص', bold: true)),
      _cell(_t('#', bold: true, align: pw.TextAlign.center)),
    ];

    final sigWidgets = <pw.Widget>[
      for (final s in style.signatures.reversed)
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            _t(s, size: 10, align: pw.TextAlign.center),
            pw.SizedBox(height: 22),
            pw.Container(width: 110, height: 0.6, color: PdfColors.grey700),
          ],
        ),
    ];

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(28),
          theme: pw.ThemeData.withFont(base: regular, bold: bold),
          buildBackground: (style.watermark && wmLogo != null)
              ? (ctx) => pw.FullPage(
                    ignoreMargins: true,
                    child: pw.Center(
                      child: pw.Opacity(
                        opacity: style.watermarkOpacity,
                        child: pw.Image(wmLogo, width: 380),
                      ),
                    ),
                  )
              : null,
        ),
        build: (ctx) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logo != null && style.logoInHeader)
                pw.Column(
                  children: [
                    pw.Container(height: 60, child: pw.Image(logo)),
                    if (style.officeName != null)
                      _t(style.officeName!,
                          size: 9, align: pw.TextAlign.center),
                  ],
                )
              else
                pw.SizedBox(width: 60),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  _t(style.title ?? 'تقرير الإشراف الهندسي',
                      size: 18, bold: true, color: accent),
                  pw.SizedBox(height: 2),
                  _t('مرحلة: ${phase.title}', size: 12),
                ],
              ),
            ],
          ),
          pw.Divider(color: accent),
          if (style.introText != null) ...[
            _t(style.introText!, size: 11),
            pw.SizedBox(height: 8),
          ],
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(3),
              1: const pw.FlexColumnWidth(1.4),
            },
            children: [
              pw.TableRow(children: [
                _cell(_t(r.project.isEmpty ? '—' : r.project)),
                _cell(_t('المشروع', bold: true), bg: tint),
              ]),
              pw.TableRow(children: [
                _cell(_t(r.location.isEmpty ? '—' : r.location)),
                _cell(_t('الموقع', bold: true), bg: tint),
              ]),
              pw.TableRow(children: [
                _cell(_t(r.engineer.isEmpty ? '—' : r.engineer)),
                _cell(_t('المهندس المشرف', bold: true), bg: tint),
              ]),
              pw.TableRow(children: [
                _cell(_t(fmtDate(r.date))),
                _cell(_t('التاريخ', bold: true), bg: tint),
              ]),
            ],
          ),
          pw.SizedBox(height: 10),
          _t('نسبة الإنجاز الكلية: ${overallProgress(r)}%   |   مطابق $ok  |  غير مطابق $bad  |  لا ينطبق $na  |  لم يُفحص $pending',
              size: 11, bold: true),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: {
              if (sp) 0: const pw.FlexColumnWidth(1.0),
              (sp ? 1 : 0): const pw.FlexColumnWidth(1.2),
              (sp ? 2 : 1): const pw.FlexColumnWidth(5),
              (sp ? 3 : 2): const pw.FlexColumnWidth(0.5),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: tint),
                children: headerCells,
              ),
              for (var i = 0; i < items.length; i++)
                pw.TableRow(children: [
                  if (sp)
                    _cell(_t('${r.progressOf(items[i].id)}%',
                        size: 10, align: pw.TextAlign.center)),
                  _cell(_t(_statusLabel(r.statusOf(items[i].id)),
                      size: 10,
                      bold: true,
                      color: _statusColor(r.statusOf(items[i].id)),
                      align: pw.TextAlign.center)),
                  _cell(_t(items[i].text, size: 10)),
                  _cell(_t('${i + 1}', size: 10, align: pw.TextAlign.center)),
                ]),
            ],
          ),
          if (photos.isNotEmpty) ...[
            pw.SizedBox(height: 14),
            _t('الملاحظات والصور', size: 13, bold: true, color: accent),
            pw.SizedBox(height: 6),
            pw.Wrap(
              spacing: 8,
              runSpacing: 4,
              alignment: pw.WrapAlignment.end,
              children: photos,
            ),
          ],
          if (r.general.trim().isNotEmpty) ...[
            pw.SizedBox(height: 10),
            _t('ملاحظات عامة', size: 13, bold: true, color: accent),
            pw.SizedBox(height: 4),
            _t(r.general),
          ],
          pw.SizedBox(height: 24),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              if (style.stampBox)
                pw.Container(
                  width: 90,
                  height: 90,
                  alignment: pw.Alignment.center,
                  decoration: pw.BoxDecoration(
                    shape: pw.BoxShape.circle,
                    border: pw.Border.all(color: PdfColors.grey600, width: 0.8),
                  ),
                  child: _t('مكان الختم',
                      size: 9,
                      color: PdfColors.grey600,
                      align: pw.TextAlign.center),
                )
              else
                pw.SizedBox(width: 1),
              ...sigWidgets,
            ],
          ),
          pw.SizedBox(height: 14),
          _t(style.footerText ?? 'أُنشئ بواسطة تطبيق الليث AI',
              size: 8, color: PdfColors.grey600),
        ],
      ),
    );

    final bytes = await doc.save();
    final d = DateTime.fromMillisecondsSinceEpoch(r.date);
    final name =
        'site_report_${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}.pdf';
    await Printing.sharePdf(bytes: bytes, filename: name);
  }
}
