import 'package:flutter/material.dart';
import 'checklist_data.dart';

/// نافذة إضافة مرحلة. تُعيد معرّف المرحلة الجديدة أو null عند الإلغاء.
Future<String?> showAddPhaseDialog(BuildContext context) async {
  final reg = PhaseRegistry.instance;
  final title = TextEditingController();
  final items = TextEditingController();
  final n = reg.phases.length;
  var pos = n;
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setD) => AlertDialog(
        title: const Text('إضافة مرحلة'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'اسم المرحلة'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: pos,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'الترتيب'),
                items: [
                  for (var i = 0; i <= n; i++)
                    DropdownMenuItem(
                      value: i,
                      child: Text(
                        i == n
                            ? 'الترتيب ${i + 1} (في النهاية)'
                            : 'الترتيب ${i + 1} (قبل: ${reg.phases[i].title})',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                ],
                onChanged: (v) {
                  if (v != null) setD(() => pos = v);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: items,
                minLines: 3,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: 'بنود الفحص (بند في كل سطر، اختياري)',
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('إضافة')),
        ],
      ),
    ),
  );
  final t = title.text.trim();
  final lines = items.text
      .split('\n')
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .toList();
  title.dispose();
  items.dispose();
  if (ok == true && t.isNotEmpty) {
    return reg.addPhase(t, lines, pos);
  }
  return null;
}

class PhasesScreen extends StatefulWidget {
  const PhasesScreen({super.key});
  @override
  State<PhasesScreen> createState() => _PhasesScreenState();
}

class _PhasesScreenState extends State<PhasesScreen> {
  final reg = PhaseRegistry.instance;

  Future<void> _delete(ChecklistPhase ph) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف المرحلة'),
        content: Text('سيتم حذف مرحلة "${ph.title}". التقارير القديمة المرتبطة بها ستعرض أول مرحلة بدلاً منها.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await reg.deleteCustom(ph.id);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final phases = reg.phases;
    return Scaffold(
      appBar: AppBar(title: const Text('مراحل المشروع')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await showAddPhaseDialog(context);
          if (mounted) setState(() {});
        },
        icon: const Icon(Icons.add),
        label: const Text('إضافة مرحلة'),
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text('اسحب المقبض ≡ لتغيير ترتيب المراحل.'),
          ),
          Expanded(
            child: ReorderableListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
              buildDefaultDragHandles: false,
              itemCount: phases.length,
              onReorder: (o, n) async {
                await reg.move(o, n);
                if (mounted) setState(() {});
              },
              itemBuilder: (context, i) {
                final ph = phases[i];
                return Card(
                  key: ValueKey(ph.id),
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${i + 1}')),
                    title: Text(ph.title,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(
                        '${ph.items.length} بند${ph.custom ? ' • مضافة' : ''}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (ph.custom)
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => _delete(ph),
                          ),
                        ReorderableDragStartListener(
                          index: i,
                          child: const Padding(
                            padding: EdgeInsets.all(8),
                            child: Icon(Icons.drag_handle),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
