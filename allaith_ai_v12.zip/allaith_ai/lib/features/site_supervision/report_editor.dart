import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../core/services/ai_text_service.dart';
import 'brand_store.dart';
import 'checklist_data.dart';
import 'phases_screen.dart';
import 'report_docx.dart';
import 'report_pdf.dart';
import 'report_style.dart';
import 'site_models.dart';

class ReportEditor extends StatefulWidget {
  final SiteReport report;
  const ReportEditor({super.key, required this.report});
  @override
  State<ReportEditor> createState() => _ReportEditorState();
}

class _ReportEditorState extends State<ReportEditor> {
  late final SiteReport r = widget.report;
  late final _project = TextEditingController(text: r.project);
  late final _location = TextEditingController(text: r.location);
  late final _engineer = TextEditingController(text: r.engineer);
  late final _general = TextEditingController(text: r.general);
  late final _request = TextEditingController(text: r.request);
  bool _busy = false;
  bool _styleBusy = false;
  String? _logoPath;

  @override
  void initState() {
    super.initState();
    BrandStore.customPath().then((v) {
      if (mounted) setState(() => _logoPath = v);
    });
    final phs = PhaseRegistry.instance.phases;
    if (!phs.any((x) => x.id == r.phaseId)) r.phaseId = phs.first.id;
  }

  @override
  void dispose() {
    _project.dispose();
    _location.dispose();
    _engineer.dispose();
    _general.dispose();
    _request.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    r.project = _project.text.trim();
    r.location = _location.text.trim();
    r.engineer = _engineer.text.trim();
    r.general = _general.text.trim();
    await ReportsStore.save(r);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.fromMillisecondsSinceEpoch(r.date),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) {
      setState(() => r.date = d.millisecondsSinceEpoch);
      await _save();
    }
  }

  Future<String?> _grabPhoto(ImageSource source) async {
    try {
      final x = await ImagePicker()
          .pickImage(source: source, maxWidth: 1280, imageQuality: 70);
      if (x == null) return null;
      final dir = await getApplicationDocumentsDirectory();
      final folder = Directory(p.join(dir.path, 'site_photos'));
      if (!folder.existsSync()) folder.createSync(recursive: true);
      final dest = p.join(
          folder.path, '${DateTime.now().microsecondsSinceEpoch}.jpg');
      await File(x.path).copy(dest);
      return dest;
    } catch (e) {
      if (mounted) _msg('تعذّر الحصول على الصورة. تحقق من الصلاحيات.');
      return null;
    }
  }

  Future<void> _addNote() async {
    final text = TextEditingController();
    String? photo;
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('ملاحظة جديدة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: text,
                  minLines: 2,
                  maxLines: 5,
                  decoration: const InputDecoration(hintText: 'اكتب الملاحظة...'),
                ),
                const SizedBox(height: 10),
                if (photo != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(File(photo!), height: 140),
                  ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        final f = await _grabPhoto(ImageSource.camera);
                        if (f != null) setD(() => photo = f);
                      },
                      icon: const Icon(Icons.photo_camera_outlined),
                      label: const Text('كاميرا'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final f = await _grabPhoto(ImageSource.gallery);
                        if (f != null) setD(() => photo = f);
                      },
                      icon: const Icon(Icons.photo_library_outlined),
                      label: const Text('المعرض'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('إلغاء')),
            TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (saved == true && (text.text.trim().isNotEmpty || photo != null)) {
      setState(() =>
          r.notes.add(SiteNote(text: text.text.trim(), photoPath: photo)));
      await _save();
    }
    text.dispose();
  }

  Future<void> _makePdf() async {
    await _save();
    setState(() => _busy = true);
    try {
      await ReportPdf.shareReport(r);
    } catch (e) {
      if (mounted) {
        _msg('تعذّر إنشاء ملف PDF. تأكد من الاتصال بالإنترنت (لتحميل الخط) وأعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickLogo() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (x == null) return;
      final ok = await BrandStore.setLogo(x.path);
      if (!ok) {
        _msg('يلزم شعار بصيغة PNG أو JPG.');
        return;
      }
      final v = await BrandStore.customPath();
      if (mounted) setState(() => _logoPath = v);
      _msg('تم اعتماد شعار المكتب');
    } catch (_) {
      _msg('تعذّر اختيار الصورة.');
    }
  }

  Future<void> _removeLogo() async {
    await BrandStore.clear();
    if (mounted) setState(() => _logoPath = null);
  }

  Future<void> _applyRequest() async {
    final req = _request.text.trim();
    if (req.isEmpty) {
      _msg('اكتب طلبك أولاً');
      return;
    }
    setState(() => _styleBusy = true);
    try {
      final style = ReportStyle.fromJsonString(r.styleJson);
      await style.applyRequest(req);
      r.styleJson = style.toJsonString();
      r.request = req;
      await _save();
      if (mounted) _msg('تم تطبيق الطلب على التقرير');
    } on AiException catch (e) {
      if (mounted) _msg(e.message);
    } catch (_) {
      if (mounted) _msg('لم أستطع فهم الطلب. أعد صياغته بوضوح.');
    } finally {
      if (mounted) setState(() => _styleBusy = false);
    }
  }

  Future<void> _resetStyle() async {
    setState(() {
      r.styleJson = '';
      r.request = '';
      _request.clear();
    });
    await _save();
  }

  Future<void> _makeDocx() async {
    await _save();
    setState(() => _busy = true);
    try {
      await ReportDocx.shareReport(r);
    } catch (e) {
      if (mounted) _msg('تعذّر إنشاء ملف Word. أعد المحاولة.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _addItem() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة بند فحص'),
        content: TextField(
          controller: c,
          autofocus: true,
          minLines: 1,
          maxLines: 4,
          decoration: const InputDecoration(hintText: 'نص البند...'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('إضافة')),
        ],
      ),
    );
    final text = c.text.trim();
    c.dispose();
    if (ok == true && text.isNotEmpty) {
      setState(() => r.custom.add(CustomItem(
          id: 'c_${DateTime.now().microsecondsSinceEpoch}',
          phaseId: r.phaseId,
          text: text)));
      await _save();
    }
  }

  Future<void> _removeCustom(String id) async {
    setState(() {
      r.custom.removeWhere((c) => c.id == id);
      r.statuses.remove(id);
      r.progress.remove(id);
    });
    await _save();
  }

  Widget _statusChip(ChecklistItem it, ItemStatus s, String label, Color c) {
    final selected = r.statusOf(it.id) == s;
    return ChoiceChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      selected: selected,
      selectedColor: c.withOpacity(0.22),
      showCheckmark: false,
      visualDensity: VisualDensity.compact,
      onSelected: (_) async {
        setState(() => r.setStatus(it.id, selected ? ItemStatus.pending : s));
        await _save();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = reportItems(r);
    final done =
        items.where((i) => r.statusOf(i.id) != ItemStatus.pending).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('تقرير إشراف'),
        actions: [
          IconButton(
            tooltip: 'حفظ',
            icon: const Icon(Icons.check),
            onPressed: () async {
              await _save();
              if (mounted) _msg('تم الحفظ');
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _project,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'اسم المشروع'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _location,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'الموقع'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _engineer,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(labelText: 'المهندس المشرف'),
          ),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: Text('التاريخ: ${fmtDate(r.date)}'),
            trailing: const Icon(Icons.edit_calendar_outlined),
            onTap: _pickDate,
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: r.phaseId,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'المرحلة'),
                  items: [
                    for (var i = 0; i < PhaseRegistry.instance.phases.length; i++)
                      DropdownMenuItem(
                        value: PhaseRegistry.instance.phases[i].id,
                        child: Text(
                            '${i + 1}. ${PhaseRegistry.instance.phases[i].title}',
                            overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) async {
                    if (v == null) return;
                    setState(() => r.phaseId = v);
                    await _save();
                  },
                ),
              ),
              IconButton(
                tooltip: 'إضافة مرحلة',
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () async {
                  final id = await showAddPhaseDialog(context);
                  if (id != null) {
                    setState(() => r.phaseId = id);
                    await _save();
                  }
                },
              ),
              IconButton(
                tooltip: 'ترتيب المراحل',
                icon: const Icon(Icons.low_priority),
                onPressed: () async {
                  await Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const PhasesScreen()));
                  if (!mounted) return;
                  final phs = PhaseRegistry.instance.phases;
                  setState(() {
                    if (!phs.any((x) => x.id == r.phaseId)) {
                      r.phaseId = phs.first.id;
                    }
                  });
                },
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: Text('قائمة الفحص',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              Text('فُحص $done/${items.length} • إنجاز ${overallProgress(r)}%'),
            ],
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(
            value: overallProgress(r) / 100,
            minHeight: 6,
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 10),
          for (final it in items)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                            child: Text(it.text,
                                style: const TextStyle(height: 1.5))),
                        if (r.custom.any((c) => c.id == it.id))
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            tooltip: 'حذف البند',
                            icon: const Icon(Icons.delete_outline, size: 20),
                            onPressed: () => _removeCustom(it.id),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      children: [
                        _statusChip(it, ItemStatus.ok, 'مطابق', Colors.green),
                        _statusChip(
                            it, ItemStatus.notOk, 'غير مطابق', Colors.red),
                        _statusChip(it, ItemStatus.na, 'لا ينطبق', Colors.grey),
                      ],
                    ),
                    Row(
                      children: [
                        const Text('الإنجاز', style: TextStyle(fontSize: 12)),
                        Expanded(
                          child: Slider(
                            value: r.progressOf(it.id).toDouble(),
                            min: 0,
                            max: 100,
                            divisions: 20,
                            label: '${r.progressOf(it.id)}%',
                            onChanged: (v) => setState(
                                () => r.setProgress(it.id, v.round())),
                            onChangeEnd: (_) => _save(),
                          ),
                        ),
                        SizedBox(
                          width: 44,
                          child: Text('${r.progressOf(it.id)}%',
                              textAlign: TextAlign.end),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          OutlinedButton.icon(
            onPressed: _addItem,
            icon: const Icon(Icons.add),
            label: const Text('إضافة بند للفحص'),
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(46)),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Text('الملاحظات والصور',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              TextButton.icon(
                onPressed: _addNote,
                icon: const Icon(Icons.add_a_photo_outlined),
                label: const Text('إضافة'),
              ),
            ],
          ),
          if (r.notes.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('لا توجد ملاحظات بعد.'),
            ),
          for (var i = 0; i < r.notes.length; i++)
            Card(
              child: ListTile(
                leading: r.notes[i].photoPath != null &&
                        File(r.notes[i].photoPath!).existsSync()
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(File(r.notes[i].photoPath!),
                            width: 56, height: 56, fit: BoxFit.cover),
                      )
                    : const Icon(Icons.notes),
                title: Text(r.notes[i].text.isEmpty ? '(صورة)' : r.notes[i].text),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    setState(() => r.notes.removeAt(i));
                    await _save();
                  },
                ),
              ),
            ),
          const SizedBox(height: 10),
          TextField(
            controller: _general,
            onChanged: (_) => _save(),
            minLines: 3,
            maxLines: 8,
            decoration: const InputDecoration(labelText: 'ملاحظات عامة'),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('تخصيص التقرير بالذكاء الاصطناعي',
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          width: 64,
                          height: 64,
                          color: Colors.white,
                          child: _logoPath != null
                              ? Image.file(File(_logoPath!), fit: BoxFit.contain)
                              : Image.asset('assets/images/logo.png',
                                  fit: BoxFit.contain),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(_logoPath != null
                            ? 'شعار المكتب المرفق'
                            : 'الشعار الافتراضي'),
                      ),
                      TextButton(
                          onPressed: _pickLogo, child: const Text('إرفاق شعار')),
                      if (_logoPath != null)
                        IconButton(
                          tooltip: 'إزالة',
                          icon: const Icon(Icons.close),
                          onPressed: _removeLogo,
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _request,
                    minLines: 3,
                    maxLines: 6,
                    decoration: const InputDecoration(
                      labelText: 'اكتب طلبك للتقرير',
                      hintText:
                          'مثال: استخدم الشعار علامة مائية، وأضف مكاناً لختم المكتب وتوقيع المقاول ومدير المشروع، ولوّن العناوين بلون هادئ يناسب هوية المكتب، وأضف فقرة افتتاحية رسمية',
                      alignLabelWithHint: true,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _styleBusy ? null : _applyRequest,
                          icon: _styleBusy
                              ? const SizedBox(
                                  height: 18,
                                  width: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.auto_awesome),
                          label: const Text('طبّق الطلب'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton(
                          onPressed: _resetStyle,
                          child: const Text('إعادة الضبط')),
                    ],
                  ),
                  Builder(builder: (context) {
                    final sum =
                        ReportStyle.fromJsonString(r.styleJson).summary();
                    if (r.styleJson.isEmpty) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          for (final x in sum)
                            Chip(
                              label: Text(x, style: const TextStyle(fontSize: 12)),
                              visualDensity: VisualDensity.compact,
                            ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          if (_busy)
            const Center(child: CircularProgressIndicator())
          else
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _makePdf,
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    label: const Text('تقرير PDF'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _makeDocx,
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('تقرير Word'),
                  ),
                ),
              ],
            ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
