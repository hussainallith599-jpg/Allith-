import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChecklistItem {
  final String id;
  final String text;
  const ChecklistItem(this.id, this.text);
}

class ChecklistPhase {
  final String id;
  final String title;
  final IconData icon;
  final List<ChecklistItem> items;
  final bool custom;
  const ChecklistPhase(this.id, this.title, this.icon, this.items,
      [this.custom = false]);
}

List<ChecklistItem> _mk(String phase, List<String> texts) => [
      for (var i = 0; i < texts.length; i++)
        ChecklistItem('${phase}_$i', texts[i]),
    ];

final List<ChecklistPhase> _builtinPhases = [
  ChecklistPhase('excavation', 'الحفر والتسوية', Icons.landscape_outlined, _mk('excavation', [
    'مطابقة موقع الحفر وأبعاده ومناسيبه للمخططات المعتمدة',
    'التحقق من نقاط الربط (البنش مارك) والمحاور',
    'فحص نوع التربة ومطابقتها لتقرير التربة',
    'الوصول لمنسوب التأسيس المطلوب وسلامة قاع الحفر',
    'خلو القاع من المياه والطين والمواد العضوية',
    'دمك التربة وإجراء اختبارات الدمك المطلوبة',
    'تأمين جوانب الحفر ومنع الانهيار',
    'التحقق من المرافق المدفونة وتأمينها',
    'وجود سياج وعلامات تحذير حول الحفر',
    'توفر وسيلة لتصريف المياه من الحفر',
  ])),
  ChecklistPhase('foundations', 'القواعد والأساسات', Icons.foundation, _mk('foundations', [
    'اعتماد المخططات الإنشائية وآخر تعديل عليها',
    'فحص منسوب وأبعاد الخرسانة العادية (النظافة)',
    'مطابقة أبعاد القواعد وسماكاتها للمخططات',
    'مطابقة حديد التسليح: النوع والأقطار والعدد والتباعد',
    'التحقق من أطوال التراكب وأطوال الأشاير',
    'التحقق من الغطاء الخرساني وتوفر الفواصل (الكراسي)',
    'سلامة الشدات الجانبية وتثبيتها',
    'العزل تحت القواعد أو حولها حسب المواصفات',
    'مواقع أشاير الأعمدة ومحاورها',
    'اعتماد الخلطة الخرسانية وأخذ عينات المكعبات',
    'نظافة الموقع والحديد قبل الصب',
    'المعالجة بعد الصب (رش أو تغطية)',
  ])),
  ChecklistPhase('columns', 'الأعمدة', Icons.view_column_outlined, _mk('columns', [
    'مطابقة مواقع الأعمدة ومحاورها',
    'شاقولية الأعمدة وسلامة الشدة وتدعيمها',
    'أبعاد القطاع ومطابقتها للمخططات',
    'حديد التسليح الرئيسي: الأقطار والعدد',
    'الكانات: القطر والتباعد وزيادة التقارب عند الأطراف حسب المخطط',
    'أطوال التراكب ومواضعها',
    'الغطاء الخرساني وتوفر الفواصل',
    'إحكام الشدة وعدم وجود فتحات تسرّب',
    'فحص الخرسانة (الهبوط ودرجة الحرارة) وأخذ المكعبات',
    'الدمك بالهزاز وعدم وجود تعشيش',
    'المعالجة بعد الصب',
  ])),
  ChecklistPhase('slabs', 'الأسقف', Icons.layers_outlined, _mk('slabs', [
    'مطابقة مناسيب الشدة وأبعادها للمخططات',
    'سلامة الدعامات والتقوية وتثبيتها',
    'حديد التسليح السفلي والعلوي: الأقطار والتباعد',
    'الغطاء الخرساني وتوفر الفواصل',
    'حديد الجسور والكانات',
    'مواقع الفتحات والمواسير المدفونة وتنسيقها مع الكهرباء والسباكة',
    'نظافة الشدة والحديد قبل الصب',
    'اعتماد الخلطة وأخذ عينات المكعبات',
    'الدمك والتسوية ومنع التشققات',
    'المعالجة بعد الصب',
    'عدم فك الشدات قبل المدة المسموحة',
  ])),
  ChecklistPhase('masonry', 'المباني (البلوك)', Icons.grid_on, _mk('masonry', [
    'مطابقة نوع البلوك وسماكته للمواصفات',
    'استقامة الجدران وشاقوليتها',
    'خلطة المونة وسماكة الفواصل',
    'الربط بين الجدران والأعمدة',
    'الأعتاب فوق الفتحات',
    'مطابقة أبعاد فتحات الأبواب والشبابيك',
    'العزل الحراري أو المائي للجدران الخارجية حسب المخططات',
    'ترك فراغات التمديدات الكهربائية والسباكة',
  ])),
  ChecklistPhase('finishing', 'التشطيبات', Icons.format_paint_outlined, _mk('finishing', [
    'اللياسة: استواء السطح وخلوه من الشقوق',
    'العزل المائي للحمامات والأسطح مع اختبار الغمر',
    'اختبار ضغط تمديدات السباكة',
    'التمديدات الكهربائية: الأسلاك والأفياش ولوحة التوزيع والتأريض',
    'البلاط والسيراميك: الاستواء والفواصل والميول نحو المصارف',
    'الدهانات: عدد الطبقات والتجانس ونظافة الحواف',
    'تركيب الأبواب والنوافذ وإحكامها وعملها',
    'تجهيزات الإنارة والأدوات الصحية',
    'تمديدات التكييف والتصريف',
    'التنظيف النهائي والاستلام',
  ])),
];

/// سجل المراحل: المراحل الجاهزة + المضافة، بالترتيب الذي يختاره المستخدم.
class PhaseRegistry {
  PhaseRegistry._();
  static final PhaseRegistry instance = PhaseRegistry._();
  static const _key = 'phases_v1';

  List<ChecklistPhase> phases = List.of(_builtinPhases);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return;
    try {
      final j = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final customs = ((j['custom'] as List?) ?? []).map((e) {
        final m = Map<String, dynamic>.from(e);
        final id = m['id'] as String;
        final texts = ((m['items'] as List?) ?? []).cast<String>();
        return ChecklistPhase(
            id, m['title'] as String, Icons.add_task, _mk(id, texts), true);
      }).toList();
      final all = [..._builtinPhases, ...customs];
      final order = ((j['order'] as List?) ?? []).cast<String>();
      final out = <ChecklistPhase>[];
      for (final id in order) {
        final f = all.where((x) => x.id == id);
        if (f.isNotEmpty && !out.contains(f.first)) out.add(f.first);
      }
      for (final ph in all) {
        if (!out.contains(ph)) out.add(ph);
      }
      phases = out;
    } catch (_) {}
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _key,
      jsonEncode({
        'order': phases.map((x) => x.id).toList(),
        'custom': phases
            .where((x) => x.custom)
            .map((x) => {
                  'id': x.id,
                  'title': x.title,
                  'items': x.items.map((i) => i.text).toList(),
                })
            .toList(),
      }),
    );
  }

  Future<String> addPhase(String title, List<String> itemTexts, int position) async {
    final id = 'p_${DateTime.now().microsecondsSinceEpoch}';
    final ph = ChecklistPhase(id, title, Icons.add_task, _mk(id, itemTexts), true);
    phases.insert(position.clamp(0, phases.length), ph);
    await save();
    return id;
  }

  Future<void> move(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final ph = phases.removeAt(oldIndex);
    phases.insert(newIndex, ph);
    await save();
  }

  Future<void> deleteCustom(String id) async {
    phases.removeWhere((x) => x.id == id && x.custom);
    await save();
  }
}

ChecklistPhase phaseById(String id) {
  final list = PhaseRegistry.instance.phases;
  return list.firstWhere((p) => p.id == id, orElse: () => list.first);
}
