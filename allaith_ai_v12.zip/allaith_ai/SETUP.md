# إعداد مشروع الليث AI

1. flutter create --org com.allaith --project-name allaith_ai --platforms=android .
   (شغّلها داخل مجلد المشروع؛ لن تستبدل ملفاتك الحالية)
2. استبدل android/app/src/main/AndroidManifest.xml بالملف المرفق (إن استبدله الأمر).
3. في android/app/build.gradle(.kts) اضبط minSdk = 21.
4. flutter pub get
5. dart run flutter_launcher_icons
6. flutter run  (للتجربة)
7. APK نهائي:
   flutter build apk --release --dart-define=TEXT_API_KEY=مفتاحك --dart-define=IMAGE_API_KEY=مفتاحك
   المسار: build/app/outputs/flutter-apk/app-release.apk
