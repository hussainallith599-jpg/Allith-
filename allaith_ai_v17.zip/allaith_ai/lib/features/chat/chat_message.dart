import '../../core/services/ai_file.dart';

class ChatMessage {
  final String role; // 'user' أو 'assistant'
  final String text;

  /// الملفات المرفقة (في الذاكرة فقط أثناء الجلسة، لا تُحفظ).
  final List<AiFile> files;

  /// أسماء الملفات المرفقة (تُحفظ للعرض).
  final List<String> fileNames;

  const ChatMessage({
    required this.role,
    required this.text,
    this.files = const [],
    this.fileNames = const [],
  });

  Map<String, dynamic> toJson() =>
      {'role': role, 'text': text, 'files': fileNames};

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        role: j['role'] as String,
        text: j['text'] as String,
        fileNames: ((j['files'] as List?) ?? []).map((e) => e.toString()).toList(),
      );
}
