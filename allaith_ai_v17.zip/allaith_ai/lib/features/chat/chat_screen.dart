import 'dart:convert';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart' show Share;
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/services/file_text.dart';
import '../../core/theme/app_theme.dart';
import '../settings/settings_screen.dart';
import 'chat_message.dart';

class _Conv {
  String id;
  String title;
  int updated;
  List<ChatMessage> messages;
  _Conv({
    required this.id,
    this.title = 'محادثة جديدة',
    required this.updated,
    List<ChatMessage>? messages,
  }) : messages = messages ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'updated': updated,
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory _Conv.fromJson(Map<String, dynamic> j) => _Conv(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? 'محادثة',
        updated: (j['updated'] as int?) ?? 0,
        messages: ((j['messages'] as List?) ?? [])
            .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static const _prefsKey = 'chats_v2';
  static const _oldKey = 'chat_history_v1';
  static const _maxBytes = 15 * 1024 * 1024;
  static const _suggestions = [
    'ما الحد الأدنى لغطاء الخرسانة للأعمدة والقواعد؟',
    'كيف أحدد أبعاد قاعدة منفصلة لعمود؟',
    'ما الفرق بين السقف المصمت والهوردي؟',
    'كيف أعالج رطوبة الجدران في الطابق الأرضي؟',
  ];

  final _controller = TextEditingController();
  final _scroll = ScrollController();
  final List<AiFile> _pending = [];
  List<_Conv> _convs = [];
  late _Conv _cur = _newConv();
  bool _loading = false;
  String? _error;
  int? _editIdx;

  _Conv _newConv() => _Conv(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      updated: DateTime.now().millisecondsSinceEpoch);

  List<ChatMessage> get _messages => _cur.messages;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  String _titleOf(List<ChatMessage> msgs) {
    final first = msgs.firstWhere((m) => m.role == 'user',
        orElse: () => const ChatMessage(role: 'user', text: 'محادثة'));
    var t = first.text.replaceAll('\n', ' ').trim();
    if (t.isEmpty && first.fileNames.isNotEmpty) t = '📎 ${first.fileNames.first}';
    if (t.isEmpty) t = 'محادثة';
    return t.length > 40 ? '${t.substring(0, 40)}…' : t;
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_prefsKey);
    final list = <_Conv>[];
    if (raw != null) {
      try {
        list.addAll((jsonDecode(raw) as List)
            .map((e) => _Conv.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    } else {
      final old = p.getString(_oldKey);
      if (old != null) {
        try {
          final msgs = (jsonDecode(old) as List)
              .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
              .toList();
          if (msgs.isNotEmpty) {
            list.add(_Conv(
                id: 'old',
                title: _titleOf(msgs),
                updated: DateTime.now().millisecondsSinceEpoch,
                messages: msgs));
          }
        } catch (_) {}
      }
    }
    list.sort((a, b) => b.updated.compareTo(a.updated));
    if (!mounted) return;
    setState(() {
      _convs = list;
      _cur = list.isNotEmpty ? list.first : _newConv();
    });
    _scrollToEnd();
  }

  Future<void> _persist() async {
    if (_cur.messages.isNotEmpty) {
      _cur.title = _cur.title == 'محادثة جديدة' || !_convs.any((c) => c.id == _cur.id)
          ? _titleOf(_cur.messages)
          : _cur.title;
      _cur.updated = DateTime.now().millisecondsSinceEpoch;
      if (!_convs.any((c) => c.id == _cur.id)) _convs.add(_cur);
    }
    _convs.sort((a, b) => b.updated.compareTo(a.updated));
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _prefsKey, jsonEncode(_convs.map((c) => c.toJson()).toList()));
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  int get _pendingBytes => _pending.fold(0, (a, f) => a + f.bytes.length);

  // ---------------- الإرفاق ----------------
  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('كاميرا'),
              subtitle: const Text('صوّر الموقع أو العيب مباشرة'),
              onTap: () => Navigator.pop(ctx, 'cam'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('صور من المعرض'),
              onTap: () => Navigator.pop(ctx, 'img'),
            ),
            ListTile(
              leading: const Icon(Icons.attach_file),
              title: const Text('ملف: PDF أو Word (docx) أو نص'),
              onTap: () => Navigator.pop(ctx, 'file'),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    try {
      final added = <AiFile>[];
      if (choice == 'cam') {
        final x = await ImagePicker()
            .pickImage(source: ImageSource.camera, maxWidth: 2400, imageQuality: 88);
        if (x != null) {
          added.add(AiFile(x.name, 'image/jpeg', await x.readAsBytes()));
        }
      } else if (choice == 'img') {
        final xs = await ImagePicker()
            .pickMultiImage(maxWidth: 2400, imageQuality: 88);
        for (final x in xs) {
          final png = x.name.toLowerCase().endsWith('.png');
          added.add(AiFile(x.name, png ? 'image/png' : 'image/jpeg',
              await x.readAsBytes()));
        }
      } else {
        final xs = await openFiles(acceptedTypeGroups: [
          const XTypeGroup(
              label: 'مستندات',
              extensions: ['pdf', 'docx', 'txt', 'md', 'csv', 'json'])
        ]);
        for (final x in xs) {
          final name = x.name;
          final lower = name.toLowerCase();
          final bytes = await x.readAsBytes();
          if (lower.endsWith('.pdf')) {
            added.add(AiFile(name, 'application/pdf', bytes));
          } else if (lower.endsWith('.docx')) {
            final t = FileText.docxToText(bytes);
            if (t == null) {
              _msg('تعذّرت قراءة $name. جرّب حفظه PDF.');
              continue;
            }
            final cut = t.length > 60000 ? '${t.substring(0, 60000)}\n[...اقتُطع الباقي]' : t;
            added.add(AiFile(name, 'text/plain', Uint8List.fromList(utf8.encode(cut))));
          } else {
            var t = FileText.plain(bytes);
            if (t.length > 60000) t = '${t.substring(0, 60000)}\n[...اقتُطع الباقي]';
            added.add(AiFile(name, 'text/plain', Uint8List.fromList(utf8.encode(t))));
          }
        }
      }
      if (added.isEmpty) return;
      final add = added.fold<int>(0, (a, f) => a + f.bytes.length);
      if (_pendingBytes + add > _maxBytes) {
        _msg('حجم المرفقات كبير (الحد حوالي 15 ميجابايت).');
        return;
      }
      setState(() => _pending.addAll(added));
    } catch (e) {
      _msg('تعذّر إرفاق الملف.\nالسبب: $e');
    }
  }

  // ---------------- الإرسال والتعديل ----------------
  Future<void> _send([String? preset]) async {
    final text = (preset ?? _controller.text).trim();
    if ((text.isEmpty && _pending.isEmpty) || _loading) return;
    final files = List<AiFile>.of(_pending);
    setState(() {
      if (_editIdx != null) {
        _messages.removeRange(_editIdx!, _messages.length);
        _editIdx = null;
      }
      _messages.add(ChatMessage(
          role: 'user',
          text: text,
          files: files,
          fileNames: files.map((f) => f.name).toList()));
      _pending.clear();
      _loading = true;
      _error = null;
      _controller.clear();
    });
    _scrollToEnd();
    try {
      final reply = await AiTextService.chat(_messages);
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(role: 'assistant', text: reply)));
      await _persist();
    } on AiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (e) {
      if (mounted) setState(() => _error = 'حدث خطأ غير متوقع: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
      _scrollToEnd();
    }
  }

  Future<void> _msgMenu(int idx) async {
    final m = _messages[idx];
    final c = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.copy),
              title: const Text('نسخ الرسالة'),
              onTap: () => Navigator.pop(ctx, 'copy'),
            ),
            if (m.role == 'user')
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('تعديل الرسالة وإعادة الإرسال'),
                subtitle: const Text('ستُحذف الردود التي بعدها'),
                onTap: () => Navigator.pop(ctx, 'edit'),
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('حذف هذه الرسالة وما بعدها'),
              onTap: () => Navigator.pop(ctx, 'del'),
            ),
          ],
        ),
      ),
    );
    if (c == 'copy') {
      await Clipboard.setData(ClipboardData(text: m.text));
      _msg('تم النسخ');
    } else if (c == 'edit' && !_loading) {
      setState(() {
        _editIdx = idx;
        _controller.text = m.text;
        _pending
          ..clear()
          ..addAll(m.files);
      });
    } else if (c == 'del' && !_loading) {
      setState(() => _messages.removeRange(idx, _messages.length));
      await _persist();
    }
  }

  void _startNew() {
    if (_loading || _cur.messages.isEmpty) return;
    setState(() {
      _cur = _newConv();
      _error = null;
      _editIdx = null;
      _pending.clear();
    });
  }

  Future<void> _copy(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _msg('تم النسخ');
  }

  String _fmt(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}/${d.month}/${d.day}';
  }

  Future<String?> _askTitle(String initial) async {
    final c = TextEditingController(text: initial);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('اسم المحادثة'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    final t = c.text.trim();
    c.dispose();
    return (ok == true && t.isNotEmpty) ? t : null;
  }

  void _openHistory() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final list = _convs.where((c) => c.messages.isNotEmpty).toList();
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.7),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('المحادثات السابقة',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                if (list.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('لا توجد محادثات محفوظة بعد'),
                  )
                else
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final c = list[i];
                        return ListTile(
                          leading: Icon(c.id == _cur.id
                              ? Icons.chat_bubble
                              : Icons.chat_bubble_outline),
                          title: Text(c.title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(_fmt(c.updated)),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'rename') {
                                final t = await _askTitle(c.title);
                                if (t != null) {
                                  c.title = t;
                                  await _persist();
                                  setSheet(() {});
                                }
                              } else if (v == 'del') {
                                _convs.removeWhere((x) => x.id == c.id);
                                if (c.id == _cur.id) {
                                  setState(() => _cur = _newConv());
                                }
                                await _persist();
                                setSheet(() {});
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'rename', child: Text('إعادة تسمية')),
                              PopupMenuItem(value: 'del', child: Text('حذف')),
                            ],
                          ),
                          onTap: () {
                            if (_loading) return;
                            setState(() {
                              _cur = c;
                              _error = null;
                              _editIdx = null;
                              _pending.clear();
                            });
                            Navigator.pop(ctx);
                            _scrollToEnd();
                          },
                          onLongPress: () async {
                            final t = await _askTitle(c.title);
                            if (t != null) {
                              c.title = t;
                              await _persist();
                              setSheet(() {});
                            }
                          },
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المساعد الهندسي'),
        actions: [
          IconButton(
            tooltip: 'محادثة جديدة',
            icon: const Icon(Icons.add_comment_outlined),
            onPressed: _startNew,
          ),
          IconButton(
            tooltip: 'المحادثات السابقة',
            icon: const Icon(Icons.history),
            onPressed: _openHistory,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _messages.isEmpty ? _empty() : _list()),
          if (_error != null) _errorBar(),
          if (_editIdx != null) _editBanner(),
          if (_pending.isNotEmpty) _pendingBar(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _empty() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 16),
        const Icon(Icons.architecture, size: 56),
        const SizedBox(height: 12),
        Text('اسأل الليث عن أي موضوع معماري أو إنشائي',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text(
          'يمكنك إرفاق صور من الموقع أو مخططات PDF أو ملفات Word ليحللها ويستشيرك فيها (زر 📎).',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.6, fontSize: 13.5),
        ),
        const SizedBox(height: 20),
        for (final s in _suggestions)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                title: Text(s),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => _send(s),
              ),
            ),
          ),
      ],
    );
  }

  Widget _list() {
    return SelectionArea(
      child: ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.all(12),
        itemCount: _messages.length + (_loading ? 1 : 0),
        itemBuilder: (context, i) {
          if (i == _messages.length) return _typing();
          return _bubble(_messages[i], i);
        },
      ),
    );
  }

  Widget _miniBtn(IconData icon, String label, VoidCallback onTap) {
    return TextButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: TextButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        foregroundColor: Colors.black54,
      ),
    );
  }

  Widget _fileChips(ChatMessage m, {bool dark = false}) {
    final names = m.fileNames;
    if (names.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Wrap(
        spacing: 6,
        runSpacing: 4,
        children: [
          for (final n in names)
            Chip(
              avatar: Icon(
                  n.toLowerCase().endsWith('.pdf')
                      ? Icons.picture_as_pdf
                      : (n.toLowerCase().endsWith('.docx') ||
                              n.toLowerCase().endsWith('.txt'))
                          ? Icons.description
                          : Icons.image,
                  size: 16),
              label: Text(n,
                  style: const TextStyle(fontSize: 11),
                  overflow: TextOverflow.ellipsis),
              visualDensity: VisualDensity.compact,
            ),
        ],
      ),
    );
  }

  Widget _bubble(ChatMessage m, int idx) {
    final isUser = m.role == 'user';
    final maxW = MediaQuery.of(context).size.width * 0.86;
    return Align(
      alignment: isUser
          ? AlignmentDirectional.centerStart
          : AlignmentDirectional.centerEnd,
      child: GestureDetector(
        onLongPress: () => _msgMenu(idx),
        child: Container(
          constraints: BoxConstraints(maxWidth: maxW),
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: isUser ? AppColors.ink : AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: isUser ? null : Border.all(color: AppColors.border),
          ),
          child: isUser
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _fileChips(m),
                    if (m.text.isNotEmpty)
                      Text(m.text,
                          style: const TextStyle(color: Colors.white, height: 1.5)),
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: InkWell(
                        onTap: () => _msgMenu(idx),
                        child: const Padding(
                          padding: EdgeInsets.only(top: 6),
                          child: Icon(Icons.more_horiz,
                              size: 18, color: Colors.white70),
                        ),
                      ),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MarkdownBody(
                      data: m.text,
                      selectable: false,
                      styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context))
                          .copyWith(p: const TextStyle(height: 1.6, fontSize: 15)),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _miniBtn(Icons.copy, 'نسخ الرد', () => _copy(m.text)),
                        _miniBtn(Icons.share_outlined, 'مشاركة',
                            () => Share.share(m.text)),
                        _miniBtn(Icons.more_horiz, 'خيارات', () => _msgMenu(idx)),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _typing() {
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
              height: 16,
              width: 16,
              child: CircularProgressIndicator(strokeWidth: 2)),
          SizedBox(width: 10),
          Text('الليث يكتب...'),
        ]),
      ),
    );
  }

  Widget _errorBar() {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF1F0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Expanded(
              child: SelectableText(_error!,
                  style: const TextStyle(color: Color(0xFFB42318)))),
          TextButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
            child: const Text('الإعدادات'),
          ),
        ],
      ),
    );
  }

  Widget _editBanner() {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF8E1),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.edit_outlined, size: 18),
          const SizedBox(width: 8),
          const Expanded(
              child: Text('تعديل رسالة — سيُعاد الإرسال وتُحذف الردود بعدها',
                  style: TextStyle(fontSize: 12.5))),
          TextButton(
            onPressed: () => setState(() {
              _editIdx = null;
              _controller.clear();
              _pending.clear();
            }),
            child: const Text('إلغاء'),
          ),
        ],
      ),
    );
  }

  Widget _pendingBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      child: Wrap(
        spacing: 6,
        runSpacing: 4,
        children: [
          for (var i = 0; i < _pending.length; i++)
            InputChip(
              avatar: Icon(
                  _pending[i].isPdf
                      ? Icons.picture_as_pdf
                      : (_pending[i].isText ? Icons.description : Icons.image),
                  size: 16),
              label: Text(_pending[i].name,
                  style: const TextStyle(fontSize: 11),
                  overflow: TextOverflow.ellipsis),
              onDeleted: () => setState(() => _pending.removeAt(i)),
            ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'إرفاق صور أو ملفات',
              icon: const Icon(Icons.attach_file),
              onPressed: _loading ? null : _attach,
            ),
            Expanded(
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: const InputDecoration(
                  hintText: 'اكتب سؤالك الهندسي...',
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filled(
              onPressed: _loading ? null : () => _send(),
              style: IconButton.styleFrom(
                  backgroundColor: AppColors.ink,
                  minimumSize: const Size(48, 48)),
              icon: const Icon(Icons.send, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
