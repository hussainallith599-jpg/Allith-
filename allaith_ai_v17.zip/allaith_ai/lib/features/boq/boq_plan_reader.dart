import 'dart:convert';
import 'dart:typed_data';
import '../../core/services/ai_text_service.dart';
import 'boq_models.dart';

/// قراءة مخطط (صورة) بالذكاء الاصطناعي واستخراج عناصر كميات مبدئية.
/// النتيجة تقريبية وتحتاج مراجعة المهندس.
class BoqPlanReader {
  BoqPlanReader._();

  static const _system = '''
أنت مهندس كميات خبير تقرأ مخططاً معمارياً أو إنشائياً من صورة وتستخرج عناصر الكميات.
أعد JSON فقط بدون شرح وبدون علامات ```، بالشكل:
{"items":[{"type":"concrete|wall|plaster|paint","kind":"footing|column|beam|slab|other","name":"اسم قصير بالعربية","n":عدد,"l":طول بالمتر,"w":عرض بالمتر,"h":ارتفاع/سماكة بالمتر,"openings":مساحة الفتحات م²,"sides":عدد الوجوه},...],"notes":"ملاحظات وافتراضاتك وما لم تستطع قراءته"}
قواعد صارمة:
- استخدم الأبعاد المكتوبة على المخطط أو مقياس الرسم فقط، ولا تخترع أرقاماً. إن لم يكن البُعد مقروءاً فلا تضف العنصر واذكره في notes.
- type=concrete: خرسانة (n عدد، l طول، w عرض، h ارتفاع أو سماكة) مع kind.
- type=wall: جدران بلوك (l مجموع الطول، h الارتفاع، openings مساحة الأبواب والشبابيك).
- type=plaster: لياسة (l طول، h ارتفاع، sides 1 أو 2، openings).
- type=paint: دهان (l، h، sides، openings).
- استخدم الارتفاعات التي يعطيها المستخدم في الطلب.
- اكتب notes بالعربية وبإيجاز.
''';

  /// يعيد العناصر المستخرجة والملاحظات.
  static Future<({List<BoqItem> items, String notes})> read({
    required Uint8List bytes,
    required String mime,
    required double wallHeight,
    required double slabThickness,
    required double columnHeight,
    required String extra,
  }) async {
    final user = 'ارتفاع الجدران: ${fmt(wallHeight)} م. سماكة البلاطة: ${fmt(slabThickness)} م. ارتفاع الأعمدة: ${fmt(columnHeight)} م.'
        '${extra.trim().isEmpty ? '' : '\nملاحظات المستخدم: ${extra.trim()}'}\n'
        'استخرج عناصر الكميات من المخطط المرفق.';
    final raw = await AiTextService.askWithImage(_system, user, bytes, mime);
    var clean = raw.trim().replaceAll('```json', '').replaceAll('```', '');
    final a = clean.indexOf('{');
    final b = clean.lastIndexOf('}');
    if (a < 0 || b <= a) throw const FormatException('no json');
    final map =
        Map<String, dynamic>.from(jsonDecode(clean.substring(a, b + 1)) as Map);
    final out = <BoqItem>[];
    for (final e in ((map['items'] as List?) ?? [])) {
      final m = Map<String, dynamic>.from(e as Map);
      final type = switch ((m['type'] ?? '').toString()) {
        'concrete' => BoqType.concrete,
        'wall' => BoqType.wall,
        'plaster' => BoqType.plaster,
        'paint' => BoqType.paint,
        _ => null,
      };
      if (type == null) continue;
      double d(dynamic v, double def) => v is num ? v.toDouble() : def;
      final it = BoqItem.blank(type)
        ..name = (m['name'] ?? '').toString()
        ..n = d(m['n'], 1)
        ..l = d(m['l'], 0)
        ..w = d(m['w'], 0)
        ..h = d(m['h'], 0)
        ..openings = d(m['openings'], 0)
        ..sides = d(m['sides'], 2).round().clamp(1, 2)
        ..fromAi = true;
      if (type == BoqType.concrete) {
        final k = (m['kind'] ?? 'other').toString();
        it.kind = kConcreteKinds.containsKey(k) ? k : 'other';
        it.rebar = kRebarDefaults[it.kind]!;
      }
      if (it.name.isEmpty) it.name = typeLabel(type);
      out.add(it);
    }
    return (items: out, notes: (map['notes'] ?? '').toString());
  }
}
