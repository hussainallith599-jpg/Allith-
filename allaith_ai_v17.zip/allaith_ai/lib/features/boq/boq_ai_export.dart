import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../core/docx/docx_kit.dart';
import '../../core/xlsx/xlsx_kit.dart';
import '../site_supervision/brand_store.dart';
import 'boq_ai_models.dart';

class BoqAiExport {
  BoqAiExport._();

  static String _stamp() {
    final d = DateTime.now();
    return '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
  }

  static String _money(double v) => v.toStringAsFixed(2);

  static bool _hasPrices(BoqAiDoc d) =>
      d.sections.any((s) => s.items.any((e) => e.price > 0));

  // ====================== Excel ======================
  static Future<void> shareXlsx(BoqAiDoc d) async {
    final rows = <List<XCell>>[];
    final merges = <String>[];
    final cur = d.currency.isEmpty ? '' : ' (${d.currency})';

    rows.add([XCell.text('A', d.title.isEmpty ? 'جدول الكميات' : d.title, style: XStyle.bold)]);
    rows.add([
      XCell.text('A',
          'الدولة/المرجع: ${d.country.isEmpty ? '—' : d.country}    |    الموقع: ${d.location.isEmpty ? '—' : d.location}    |    الجهة: ${d.client.isEmpty ? '—' : d.client}',
          style: XStyle.normal)
    ]);
    rows.add([]);
    rows.add([
      XCell.text('A', 'رقم البند', style: XStyle.header),
      XCell.text('B', 'وصف البند / المواصفات / طريقة الحساب', style: XStyle.header),
      XCell.text('C', 'الوحدة', style: XStyle.header),
      XCell.text('D', 'العدد', style: XStyle.header),
      XCell.text('E', 'الطول', style: XStyle.header),
      XCell.text('F', 'العرض', style: XStyle.header),
      XCell.text('G', 'الارتفاع', style: XStyle.header),
      XCell.text('H', 'الكمية', style: XStyle.header),
      XCell.text('I', 'سعر الوحدة$cur', style: XStyle.header),
      XCell.text('J', 'الإجمالي$cur', style: XStyle.header),
    ]);

    // أرقام الصفوف التي فيها إجمالي كل قسم لتجميعها لاحقاً
    final sectionTotalRefs = <String>[];

    for (final s in d.sections) {
      rows.add([
        XCell.text('A', '', style: XStyle.section),
        XCell.text('B', s.title, style: XStyle.section),
        for (final c in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'])
          XCell.empty(c, style: XStyle.section),
      ]);
      merges.add('B${rows.length}:J${rows.length}');
      final itemTotalRows = <int>[];

      for (final it in s.items) {
        // صف البند
        final itemRow = rows.length + 1;
        final specRowCount = (it.spec.isNotEmpty ? 1 : 0) + (it.notes.isNotEmpty ? 1 : 0);
        final firstTerm = itemRow + 1 + specRowCount;
        final lastTerm = firstTerm + it.terms.length - 1;

        XCell qtyCell;
        if (it.terms.isNotEmpty) {
          final f = it.factor != 1 ? '*${it.factor}' : '';
          qtyCell = XCell.formula('H', 'SUM(H$firstTerm:H$lastTerm)$f', it.qty,
              style: XStyle.boldNumber);
        } else {
          qtyCell = XCell.num('H', it.directQty ?? 0, style: XStyle.boldNumber);
        }
        rows.add([
          XCell.text('A', it.no + (it.suggested ? ' *' : ''), style: XStyle.cell),
          XCell.text('B', it.description, style: XStyle.header),
          XCell.text('C', it.unit, style: XStyle.cell),
          for (final c in ['D', 'E', 'F', 'G']) XCell.empty(c, style: XStyle.cell),
          qtyCell,
          XCell.num('I', it.price == 0 ? null : it.price, style: XStyle.number),
          XCell.formulaText('J', 'IF(I$itemRow="","",H$itemRow*I$itemRow)',
              style: XStyle.boldNumber),
        ]);
        itemTotalRows.add(itemRow);

        if (it.spec.isNotEmpty) {
          rows.add([
            XCell.empty('A', style: XStyle.cell),
            XCell.text('B', 'المواصفات: ${it.spec}', style: XStyle.cell),
            for (final c in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'])
              XCell.empty(c, style: XStyle.cell),
          ]);
        }
        if (it.notes.isNotEmpty) {
          rows.add([
            XCell.empty('A', style: XStyle.cell),
            XCell.text('B', 'ملاحظات: ${it.notes}${it.suggested ? '  (بند مقترح — راجعه)' : ''}',
                style: XStyle.cell),
            for (final c in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'])
              XCell.empty(c, style: XStyle.cell),
          ]);
        }
        for (final t in it.terms) {
          final r = rows.length + 1;
          final parts = <String>[
            if (t.n != null) 'D$r',
            if (t.l != null) 'E$r',
            if (t.w != null) 'F$r',
            if (t.h != null) 'G$r',
          ];
          final prod = parts.isEmpty ? '0' : parts.join('*');
          rows.add([
            XCell.empty('A', style: XStyle.cell),
            XCell.text('B', '${t.sign < 0 ? '(خصم) ' : ''}${t.label}',
                style: XStyle.cell),
            XCell.empty('C', style: XStyle.cell),
            t.n == null ? XCell.empty('D', style: XStyle.cell) : XCell.num('D', t.n, style: XStyle.number),
            t.l == null ? XCell.empty('E', style: XStyle.cell) : XCell.num('E', t.l, style: XStyle.number),
            t.w == null ? XCell.empty('F', style: XStyle.cell) : XCell.num('F', t.w, style: XStyle.number),
            t.h == null ? XCell.empty('G', style: XStyle.cell) : XCell.num('G', t.h, style: XStyle.number),
            XCell.formula('H', '${t.sign < 0 ? '-' : ''}$prod', t.value,
                style: XStyle.number),
            XCell.empty('I', style: XStyle.cell),
            XCell.empty('J', style: XStyle.cell),
          ]);
        }
        if (it.terms.isNotEmpty && it.factor != 1) {
          rows.add([
            XCell.empty('A', style: XStyle.cell),
            XCell.text('B',
                'معامل الضرب: ${fmtQ(it.factor, 3)}${it.factorNote.isEmpty ? '' : ' (${it.factorNote})'}',
                style: XStyle.cell),
            for (final c in ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'])
              XCell.empty(c, style: XStyle.cell),
          ]);
        }
      }

      // إجمالي القسم (مجموع الصفوف الرئيسية للبنود)
      final r = rows.length + 1;
      final sumParts = itemTotalRows.map((x) => 'J$x').join(',');
      rows.add([
        XCell.empty('A', style: XStyle.section),
        XCell.text('B', 'إجمالي ${s.title}', style: XStyle.section),
        for (final c in ['C', 'D', 'E', 'F', 'G', 'H', 'I'])
          XCell.empty(c, style: XStyle.section),
        sumParts.isEmpty
            ? XCell.empty('J', style: XStyle.section)
            : XCell.formula('J', 'SUM($sumParts)', s.total, style: XStyle.boldNumber),
      ]);
      sectionTotalRefs.add('J$r');
    }

    rows.add([]);
    final hasPrices = _hasPrices(d);
    if (sectionTotalRefs.isNotEmpty) {
      final sumAll = sectionTotalRefs.join(',');
      var r = rows.length + 1;
      final subRow = r;
      rows.add([
        XCell.text('B', 'المجموع الفرعي', style: XStyle.bold),
        XCell.formula('J', 'SUM($sumAll)', d.subtotal, style: XStyle.boldNumber),
      ]);
      r++;
      final contRow = r;
      rows.add([
        XCell.text('B', 'احتياطي/إدارة وأرباح ${fmtQ(d.contingency)}%', style: XStyle.normal),
        XCell.formula('J', 'J$subRow*${d.contingency}/100', d.contingencyAmount,
            style: XStyle.number),
      ]);
      r++;
      rows.add([
        XCell.text('B', 'ضريبة القيمة المضافة/المبيعات ${fmtQ(d.vat)}%', style: XStyle.normal),
        XCell.formula('J', '(J$subRow+J$contRow)*${d.vat}/100', d.vatAmount,
            style: XStyle.number),
      ]);
      r++;
      rows.add([
        XCell.text('B', 'الإجمالي النهائي', style: XStyle.bold),
        XCell.formula('J', 'J$subRow+J$contRow+J${r - 1}', d.grand,
            style: XStyle.boldNumber),
      ]);
      if (!hasPrices) {
        rows.add([
          XCell.text('B', 'أدخل أسعار الوحدات في العمود I لتظهر الإجماليات.',
              style: XStyle.normal)
        ]);
      }
    }
    if (d.notes.isNotEmpty || d.sections.any((s) => s.items.any((e) => e.suggested))) {
      rows.add([]);
      rows.add([XCell.text('B', 'ملاحظات واستثناءات', style: XStyle.bold)]);
      for (final n in d.notes) {
        rows.add([XCell.text('B', '- $n', style: XStyle.wrap)]);
      }
      if (d.sections.any((s) => s.items.any((e) => e.suggested))) {
        rows.add([
          XCell.text('B', '* بنود علامتها (*) مقترحة من الخبير الذكي وتحتاج مراجعتك.',
              style: XStyle.wrap)
        ]);
      }
    }
    rows.add([]);
    rows.add([
      XCell.text('B',
          'الكميات محسوبة من الأبعاد المقروءة أو المدخلة وتُراجَع من مهندس مختص قبل الاعتماد.',
          style: XStyle.wrap)
    ]);

    final bytes = XlsxKit.build(
      sheetName: 'BOQ',
      rows: rows,
      widths: [9, 62, 10, 9, 9, 9, 9, 13, 14, 15],
      merges: merges,
    );
    await XlsxKit.share(bytes, 'boq_${_stamp()}.xlsx');
  }

  // ====================== PDF ======================
  static pw.Widget _t(String s,
          {double size = 10,
          bool bold = false,
          PdfColor color = PdfColors.black,
          pw.TextAlign align = pw.TextAlign.right}) =>
      pw.Text(s,
          textDirection: pw.TextDirection.rtl,
          textAlign: align,
          style: pw.TextStyle(
              fontSize: size,
              color: color,
              fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal));

  static pw.Widget _c(String s,
          {bool head = false,
          bool bold = false,
          PdfColor? bg,
          pw.TextAlign align = pw.TextAlign.center}) =>
      pw.Container(
        color: head ? PdfColors.grey300 : bg,
        padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: _t(s, size: 9, bold: head || bold, align: align),
      );

  static Future<void> sharePdf(BoqAiDoc d) async {
    final regular = await PdfGoogleFonts.cairoRegular();
    final boldF = await PdfGoogleFonts.cairoBold();
    pw.MemoryImage? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) logo = pw.MemoryImage(lb.bytes);
    } catch (_) {}
    final hasPrices = _hasPrices(d);

    // الأعمدة (من اليسار بصرياً): الإجمالي، السعر، الكمية، الوحدة، الوصف، الرقم
    List<pw.Widget> row(List<String> cells, {bool head = false}) =>
        [for (final c in cells.reversed) _c(c, head: head)];
    final heads = hasPrices
        ? ['الرقم', 'الوصف والمواصفات وطريقة الحساب', 'الوحدة', 'الكمية', 'السعر', 'الإجمالي']
        : ['الرقم', 'الوصف والمواصفات وطريقة الحساب', 'الوحدة', 'الكمية'];
    final n = heads.length;
    final widths = <int, pw.TableColumnWidth>{
      for (var i = 0; i < n; i++)
        i: pw.FlexColumnWidth(i == n - 2 ? 5.2 : (i == n - 1 ? 0.9 : 1.0)),
    };

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(26),
          theme: pw.ThemeData.withFont(base: regular, bold: boldF),
        ),
        build: (ctx) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logo != null)
                pw.Container(height: 54, child: pw.Image(logo))
              else
                pw.SizedBox(width: 54),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  _t(d.title.isEmpty ? 'جدول الكميات' : d.title,
                      size: 17, bold: true),
                  pw.SizedBox(height: 2),
                  _t('الدولة/المرجع: ${d.country.isEmpty ? '—' : d.country}',
                      size: 10),
                  if (d.location.isNotEmpty) _t('الموقع: ${d.location}', size: 10),
                  if (d.client.isNotEmpty) _t('الجهة: ${d.client}', size: 10),
                ],
              ),
            ],
          ),
          pw.Divider(),
          for (final s in d.sections) ...[
            pw.SizedBox(height: 8),
            _t(s.title, size: 12.5, bold: true),
            pw.SizedBox(height: 3),
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
              columnWidths: widths,
              children: [
                pw.TableRow(children: row(heads, head: true)),
                for (final it in s.items)
                  pw.TableRow(children: [
                    if (hasPrices) _c(_money(it.total), bold: true),
                    if (hasPrices) _c(it.price == 0 ? '' : _money(it.price)),
                    _c(fmtQ(it.qty), bold: true),
                    _c(it.unit),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(4),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.end,
                        children: [
                          _t(it.description + (it.suggested ? '  ⚠ مقترح' : ''),
                              size: 9.5, bold: true),
                          if (it.spec.isNotEmpty)
                            _t('المواصفات: ${it.spec}', size: 8.5),
                          if (it.calcText.isNotEmpty)
                            _t('الحساب: ${it.calcText}',
                                size: 8, color: PdfColors.grey700),
                          if (it.notes.isNotEmpty)
                            _t('ملاحظة: ${it.notes}',
                                size: 8, color: PdfColors.grey700),
                        ],
                      ),
                    ),
                    _c(it.no),
                  ]),
              ],
            ),
            if (hasPrices)
              pw.Padding(
                padding: const pw.EdgeInsets.only(top: 3),
                child: _t('إجمالي ${s.title}: ${_money(s.total)} ${d.currency}',
                    size: 10, bold: true),
              ),
          ],
          if (hasPrices) ...[
            pw.SizedBox(height: 10),
            _t('المجموع الفرعي: ${_money(d.subtotal)} ${d.currency}', size: 10.5, bold: true),
            if (d.contingency > 0)
              _t('احتياطي/إدارة وأرباح ${fmtQ(d.contingency)}%: ${_money(d.contingencyAmount)}', size: 10),
            if (d.vat > 0)
              _t('الضريبة ${fmtQ(d.vat)}%: ${_money(d.vatAmount)}', size: 10),
            _t('الإجمالي النهائي: ${_money(d.grand)} ${d.currency}', size: 12, bold: true),
          ],
          if (d.notes.isNotEmpty) ...[
            pw.SizedBox(height: 10),
            _t('ملاحظات واستثناءات', size: 11, bold: true),
            for (final x in d.notes) _t('- $x', size: 9),
          ],
          pw.SizedBox(height: 14),
          _t('الكميات محسوبة من الأبعاد المقروءة أو المدخلة وتُراجَع من مهندس مختص قبل الاعتماد. البنود المعلّمة "مقترح" أضافها الخبير الذكي وتحتاج مراجعتك.',
              size: 8.5, color: PdfColors.grey700),
          pw.SizedBox(height: 4),
          _t('أُنشئ بواسطة تطبيق الليث AI', size: 8, color: PdfColors.grey600),
        ],
      ),
    );
    final bytes = await doc.save();
    await Printing.sharePdf(bytes: bytes, filename: 'boq_${_stamp()}.pdf');
  }

  // ====================== Word ======================
  static Future<void> shareDocx(BoqAiDoc d) async {
    final pics = <DocxPic>[];
    DocxPic? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) {
        logo = await DocxKit.makePic(lb.bytes, lb.ext, 1);
        if (logo != null) pics.add(logo);
      }
    } catch (_) {}
    final hasPrices = _hasPrices(d);

    final body = StringBuffer();
    if (logo != null) body.write(DocxKit.image(logo, 1, 3.0, center: true));
    body.write(DocxKit.text(d.title.isEmpty ? 'جدول الكميات' : d.title,
        bold: true, size: 34, jc: 'center', after: 40));
    body.write(DocxKit.text(
        'الدولة/المرجع: ${d.country.isEmpty ? '—' : d.country}${d.location.isEmpty ? '' : '   |   الموقع: ${d.location}'}${d.client.isEmpty ? '' : '   |   الجهة: ${d.client}'}',
        size: 22, jc: 'center', after: 160));

    // الأعمدة (الأول يمين الصفحة): الرقم، الوصف، الوحدة، الكمية، [السعر، الإجمالي]
    final w = hasPrices
        ? [700, 4300, 900, 1200, 1300, 1500]
        : [800, 6200, 1300, 1600];
    final heads = hasPrices
        ? ['الرقم', 'الوصف والمواصفات وطريقة الحساب', 'الوحدة', 'الكمية', 'السعر', 'الإجمالي']
        : ['الرقم', 'الوصف والمواصفات وطريقة الحساب', 'الوحدة', 'الكمية'];

    for (final s in d.sections) {
      body.write(DocxKit.text(s.title, bold: true, size: 26, after: 80));
      final rows = <String>[
        DocxKit.row([
          for (var i = 0; i < heads.length; i++)
            DocxKit.cell(
                DocxKit.text(heads[i],
                    bold: true, size: 19, jc: i == 1 ? null : 'center', after: 0),
                w[i],
                fill: 'E0E0E0'),
        ]),
        for (final it in s.items)
          DocxKit.row([
            DocxKit.cell(
                DocxKit.text(it.no, size: 19, jc: 'center', after: 0), w[0]),
            DocxKit.cell(
                DocxKit.text(
                        it.description + (it.suggested ? '  ⚠ مقترح — راجعه' : ''),
                        bold: true,
                        size: 19,
                        after: 20) +
                    (it.spec.isEmpty
                        ? ''
                        : DocxKit.text('المواصفات: ${it.spec}', size: 17, after: 20)) +
                    (it.calcText.isEmpty
                        ? ''
                        : DocxKit.text('الحساب: ${it.calcText}',
                            size: 16, color: '616161', after: 20)) +
                    (it.notes.isEmpty
                        ? ''
                        : DocxKit.text('ملاحظة: ${it.notes}',
                            size: 16, color: '616161', after: 0)),
                w[1]),
            DocxKit.cell(
                DocxKit.text(it.unit, size: 19, jc: 'center', after: 0), w[2]),
            DocxKit.cell(
                DocxKit.text(fmtQ(it.qty),
                    bold: true, size: 19, jc: 'center', after: 0),
                w[3]),
            if (hasPrices)
              DocxKit.cell(
                  DocxKit.text(it.price == 0 ? '' : _money(it.price),
                      size: 19, jc: 'center', after: 0),
                  w[4]),
            if (hasPrices)
              DocxKit.cell(
                  DocxKit.text(_money(it.total),
                      bold: true, size: 19, jc: 'center', after: 0),
                  w[5]),
          ]),
      ];
      body.write(DocxKit.table(w, rows));
      if (hasPrices) {
        body.write(DocxKit.text(
            'إجمالي ${s.title}: ${_money(s.total)} ${d.currency}',
            bold: true, size: 20, after: 120));
      } else {
        body.write(DocxKit.text('', after: 100));
      }
    }
    if (hasPrices) {
      body.write(DocxKit.text('المجموع الفرعي: ${_money(d.subtotal)} ${d.currency}',
          bold: true, size: 22, after: 40));
      if (d.contingency > 0) {
        body.write(DocxKit.text(
            'احتياطي/إدارة وأرباح ${fmtQ(d.contingency)}%: ${_money(d.contingencyAmount)}',
            size: 21, after: 40));
      }
      if (d.vat > 0) {
        body.write(DocxKit.text('الضريبة ${fmtQ(d.vat)}%: ${_money(d.vatAmount)}',
            size: 21, after: 40));
      }
      body.write(DocxKit.text(
          'الإجمالي النهائي: ${_money(d.grand)} ${d.currency}',
          bold: true, size: 26, after: 120));
    }
    if (d.notes.isNotEmpty) {
      body.write(DocxKit.text('ملاحظات واستثناءات', bold: true, size: 24, after: 60));
      for (final x in d.notes) {
        body.write(DocxKit.text('- $x', size: 20, after: 30));
      }
    }
    body.write(DocxKit.text(
        'الكميات محسوبة من الأبعاد المقروءة أو المدخلة وتُراجَع من مهندس مختص قبل الاعتماد. البنود المعلّمة "مقترح" أضافها الخبير الذكي وتحتاج مراجعتك.',
        size: 17, color: '616161', after: 60));
    body.write(DocxKit.text('أُنشئ بواسطة تطبيق الليث AI', size: 16, color: '757575'));

    final bytes = DocxKit.build(body.toString(), pics);
    await DocxKit.shareBytes(bytes, 'boq_${_stamp()}.docx');
  }
}
