import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'boq_ai_models.dart';

class BoqAiStore {
  static const _key = 'boq_ai_docs_v1';

  static Future<List<SavedBoq>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => SavedBoq.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      list.sort((a, b) => b.updated.compareTo(a.updated));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<SavedBoq> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(l.map((e) => e.toJson()).toList()));
  }

  /// يحفظ (أو يحدّث) الجدول ويعيد معرّفه.
  static Future<String> save(String? id, BoqAiDoc doc) async {
    final list = await load();
    final now = DateTime.now().millisecondsSinceEpoch;
    final useId = id ?? now.toString();
    final name = doc.title.isEmpty ? 'جدول كميات' : doc.title;
    final i = list.indexWhere((x) => x.id == useId);
    if (i >= 0) {
      list[i].name = name;
      list[i].updated = now;
      list[i].doc = doc;
    } else {
      list.add(SavedBoq(useId, name, now, doc));
    }
    await _write(list);
    return useId;
  }

  static Future<void> delete(String id) async {
    final list = await load();
    list.removeWhere((x) => x.id == id);
    await _write(list);
  }
}
