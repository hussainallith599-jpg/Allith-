import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/docx/docx_kit.dart';
import '../site_supervision/brand_store.dart';
import 'boq_models.dart';

class BoqExport {
  BoqExport._();

  static String _fileStamp(BoqProject p) {
    final d = DateTime.fromMillisecondsSinceEpoch(p.date);
    return '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
  }

  static String _dateText(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${d.year}/${d.month}/${d.day}';
  }

  // ---------------- نص ----------------
  static Future<void> shareText(BoqProject p) async {
    await Share.share(boqAsText(p));
  }

  // ---------------- PDF ----------------
  static pw.Widget _t(String s,
          {double size = 10,
          bool bold = false,
          PdfColor color = PdfColors.black,
          pw.TextAlign align = pw.TextAlign.right}) =>
      pw.Text(s,
          textDirection: pw.TextDirection.rtl,
          textAlign: align,
          style: pw.TextStyle(
              fontSize: size,
              color: color,
              fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal));

  static pw.Widget _cell(String s, {bool head = false}) => pw.Container(
        color: head ? PdfColors.grey300 : null,
        padding: const pw.EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        child: _t(s, size: 9.5, bold: head, align: pw.TextAlign.center),
      );

  static Future<void> sharePdf(BoqProject p) async {
    final regular = await PdfGoogleFonts.cairoRegular();
    final bold = await PdfGoogleFonts.cairoBold();
    pw.MemoryImage? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) logo = pw.MemoryImage(lb.bytes);
    } catch (_) {}

    final sections = buildBoqSections(p);
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(28),
          theme: pw.ThemeData.withFont(base: regular, bold: bold),
        ),
        build: (ctx) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logo != null)
                pw.Container(height: 56, child: pw.Image(logo))
              else
                pw.SizedBox(width: 56),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  _t('جدول الكميات (BOQ)', size: 18, bold: true),
                  pw.SizedBox(height: 2),
                  _t('المشروع: ${p.name.isEmpty ? '—' : p.name}', size: 12),
                  _t('التاريخ: ${_dateText(p.date)}', size: 10),
                ],
              ),
            ],
          ),
          pw.Divider(),
          for (final s in sections) ...[
            pw.SizedBox(height: 10),
            _t(s.title, size: 13, bold: true),
            pw.SizedBox(height: 4),
            pw.Table(
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
              columnWidths: {
                for (var i = 0; i < s.headers.length; i++)
                  i: pw.FlexColumnWidth(
                      s.headers.length - 1 - i == 0 ? 2.6 : 1.2),
              },
              children: [
                pw.TableRow(children: [
                  for (final h in s.headers.reversed) _cell(h, head: true)
                ]),
                for (final r in s.rows)
                  pw.TableRow(children: [
                    for (final c in r.reversed) _cell(c),
                  ]),
              ],
            ),
          ],
          pw.SizedBox(height: 16),
          _t(kBoqDisclaimer, size: 8.5, color: PdfColors.grey700),
          pw.SizedBox(height: 6),
          _t('أُنشئ بواسطة تطبيق الليث AI', size: 8, color: PdfColors.grey600),
        ],
      ),
    );
    final bytes = await doc.save();
    await Printing.sharePdf(bytes: bytes, filename: 'boq_${_fileStamp(p)}.pdf');
  }

  // ---------------- Word ----------------
  static Future<void> shareDocx(BoqProject p) async {
    final pics = <DocxPic>[];
    DocxPic? logo;
    try {
      final lb = await BrandStore.logoBytes();
      if (lb != null) {
        logo = await DocxKit.makePic(lb.bytes, lb.ext, 1);
        if (logo != null) pics.add(logo);
      }
    } catch (_) {}

    final body = StringBuffer();
    if (logo != null) {
      body.write(DocxKit.image(logo, 1, 3.0, center: true));
    }
    body.write(DocxKit.text('جدول الكميات (BOQ)',
        bold: true, size: 36, jc: 'center', after: 40));
    body.write(DocxKit.text('المشروع: ${p.name.isEmpty ? '—' : p.name}',
        size: 26, jc: 'center', after: 40));
    body.write(DocxKit.text('التاريخ: ${_dateText(p.date)}',
        size: 22, jc: 'center', after: 160));

    for (final s in buildBoqSections(p)) {
      body.write(DocxKit.text(s.title, bold: true, size: 26, after: 80));
      final n = s.headers.length;
      final first = n <= 3 ? 5400 : 2900;
      final rest = ((9900 - first) / (n - 1)).floor();
      final widths = [first, ...List<int>.filled(n - 1, rest)];
      final rows = <String>[
        DocxKit.row([
          for (var i = 0; i < n; i++)
            DocxKit.cell(
                DocxKit.text(s.headers[i],
                    bold: true,
                    size: 20,
                    jc: i == 0 ? null : 'center',
                    after: 0),
                widths[i],
                fill: 'E0E0E0'),
        ]),
        for (final r in s.rows)
          DocxKit.row([
            for (var i = 0; i < n; i++)
              DocxKit.cell(
                  DocxKit.text(r[i],
                      size: 20, jc: i == 0 ? null : 'center', after: 0),
                  widths[i]),
          ]),
      ];
      body.write(DocxKit.table(widths, rows));
      body.write(DocxKit.text('', after: 120));
    }
    body.write(DocxKit.text(kBoqDisclaimer, size: 18, color: '616161'));
    body.write(DocxKit.text('أُنشئ بواسطة تطبيق الليث AI',
        size: 16, color: '757575'));

    final bytes = DocxKit.build(body.toString(), pics);
    await DocxKit.shareBytes(bytes, 'boq_${_fileStamp(p)}.docx');
  }
}
