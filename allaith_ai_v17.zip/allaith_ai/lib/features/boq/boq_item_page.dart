import 'package:flutter/material.dart';
import 'boq_models.dart';

/// شاشة إضافة/تعديل عنصر كميات، مع نتيجة حية.
class BoqItemPage extends StatefulWidget {
  final BoqItem item;
  final bool isNew;
  final double blocksPerM2;
  const BoqItemPage(
      {super.key,
      required this.item,
      required this.isNew,
      required this.blocksPerM2});
  @override
  State<BoqItemPage> createState() => _BoqItemPageState();
}

class _BoqItemPageState extends State<BoqItemPage> {
  late final BoqItem it = BoqItem.fromJson(widget.item.toJson());
  final _c = <String, TextEditingController>{};

  TextEditingController _ctl(String k, double v) => _c.putIfAbsent(
      k, () => TextEditingController(text: v == 0 ? '' : fmt(v, 3)));

  @override
  void initState() {
    super.initState();
    _c['name'] = TextEditingController(text: it.name);
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  double _v(String k) => parseNum(_c[k]?.text ?? '');

  void _sync() {
    setState(() {
      it.name = _c['name']!.text.trim();
      it.n = _c.containsKey('n') ? (_v('n') == 0 ? 0 : _v('n')) : it.n;
      if (_c.containsKey('l')) it.l = _v('l');
      if (_c.containsKey('w')) it.w = _v('w');
      if (_c.containsKey('h')) it.h = _v('h');
      if (_c.containsKey('t')) it.t = _v('t');
      if (_c.containsKey('openings')) it.openings = _v('openings');
      if (_c.containsKey('rebar')) it.rebar = _v('rebar');
      if (_c.containsKey('coverage')) it.coverage = _v('coverage');
    });
  }

  Widget _num(String key, String label, double value, {String? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: _ctl(key, value),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        onChanged: (_) => _sync(),
        decoration: InputDecoration(labelText: label, suffixText: suffix),
      ),
    );
  }

  Widget _result() {
    final lines = <String>[];
    switch (it.type) {
      case BoqType.concrete:
        lines.add('الحجم: ${fmt(it.volume)} م³');
        lines.add('الحديد (تقديري): ${fmt(it.rebarKg, 0)} كجم');
        break;
      case BoqType.wall:
        lines.add('المساحة الإجمالية: ${fmt(it.grossArea)} م²');
        lines.add('المساحة الصافية: ${fmt(it.wallNetArea)} م²');
        lines.add(
            'البلوك (بدون هدر): ${fmt(it.wallNetArea * widget.blocksPerM2, 0)} بلوكة');
        break;
      case BoqType.plaster:
        lines.add('مساحة اللياسة: ${fmt(it.coatedArea)} م²');
        lines.add('حجم المونة: ${fmt(it.plasterVolume, 3)} م³');
        break;
      case BoqType.paint:
        lines.add('مساحة الدهان: ${fmt(it.coatedArea)} م²');
        lines.add('الكمية: ${fmt(it.paintLiters)} لتر');
        break;
    }
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('النتيجة', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            for (final l in lines) Text(l),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final fields = <Widget>[
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: _c['name'],
          onChanged: (_) => _sync(),
          decoration: const InputDecoration(labelText: 'اسم العنصر (اختياري)'),
        ),
      ),
    ];
    switch (it.type) {
      case BoqType.concrete:
        fields.addAll([
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: DropdownButtonFormField<String>(
              value: it.kind,
              decoration: const InputDecoration(labelText: 'نوع العنصر'),
              items: [
                for (final e in kConcreteKinds.entries)
                  DropdownMenuItem(value: e.key, child: Text(e.value)),
              ],
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  it.kind = v;
                  it.rebar = kRebarDefaults[v] ?? 100;
                  _c['rebar']?.text = fmt(it.rebar, 0);
                });
              },
            ),
          ),
          _num('n', 'العدد', it.n),
          _num('l', 'الطول (م)', it.l),
          _num('w', 'العرض (م)', it.w),
          _num('h', 'الارتفاع أو السماكة (م)', it.h),
          _num('rebar', 'نسبة الحديد (كجم لكل م³) - تقديرية', it.rebar),
        ]);
        break;
      case BoqType.wall:
        fields.addAll([
          _num('l', 'مجموع طول الجدران (م)', it.l),
          _num('h', 'الارتفاع (م)', it.h),
          _num('openings', 'مساحة الفتحات: أبواب وشبابيك (م²)', it.openings),
        ]);
        break;
      case BoqType.plaster:
        fields.addAll([
          _num('l', 'الطول (م) - أو المساحة إن كان الارتفاع 1', it.l),
          _num('h', 'الارتفاع (م)', it.h),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 1, label: Text('وجه واحد')),
                ButtonSegment(value: 2, label: Text('وجهان')),
              ],
              selected: {it.sides},
              onSelectionChanged: (s) => setState(() => it.sides = s.first),
            ),
          ),
          _num('openings', 'مساحة الفتحات (م²)', it.openings),
          _num('t', 'سماكة اللياسة (سم)', it.t),
        ]);
        break;
      case BoqType.paint:
        fields.addAll([
          _num('l', 'الطول (م) - أو المساحة إن كان الارتفاع 1', it.l),
          _num('h', 'الارتفاع (م)', it.h),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 1, label: Text('وجه واحد')),
                ButtonSegment(value: 2, label: Text('وجهان')),
              ],
              selected: {it.sides},
              onSelectionChanged: (s) => setState(() => it.sides = s.first),
            ),
          ),
          _num('openings', 'مساحة الفتحات (م²)', it.openings),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: DropdownButtonFormField<int>(
              value: it.coats.clamp(1, 4),
              decoration: const InputDecoration(labelText: 'عدد الطبقات'),
              items: [
                for (var i = 1; i <= 4; i++)
                  DropdownMenuItem(value: i, child: Text('$i')),
              ],
              onChanged: (v) => setState(() => it.coats = v ?? 2),
            ),
          ),
          _num('coverage', 'تغطية اللتر الواحد (م² للطبقة)', it.coverage),
        ]);
        break;
    }

    return Scaffold(
      appBar: AppBar(title: Text(typeLabel(it.type))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ...fields,
          _result(),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () {
              _sync();
              it.fromAi = false;
              Navigator.pop(context, it);
            },
            child: Text(widget.isNew ? 'إضافة' : 'حفظ'),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
