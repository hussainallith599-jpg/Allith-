import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/services/ai_text_service.dart';
import 'boq_export.dart';
import 'boq_item_page.dart';
import 'boq_models.dart';
import 'boq_plan_reader.dart';

class BoqEditor extends StatefulWidget {
  final BoqProject project;
  const BoqEditor({super.key, required this.project});
  @override
  State<BoqEditor> createState() => _BoqEditorState();
}

class _BoqEditorState extends State<BoqEditor> {
  late final BoqProject p = widget.project;
  late final _name = TextEditingController(text: p.name);
  late final _cw = TextEditingController(text: fmt(p.concreteWaste));
  late final _rw = TextEditingController(text: fmt(p.rebarWaste));
  late final _bw = TextEditingController(text: fmt(p.blockWaste));
  late final _bpm = TextEditingController(text: fmt(p.blocksPerM2));
  late final _mix = TextEditingController(text: p.mix);
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _cw.dispose();
    _rw.dispose();
    _bw.dispose();
    _bpm.dispose();
    _mix.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    p.name = _name.text.trim();
    p.concreteWaste = parseNum(_cw.text, 5).clamp(0, 50);
    p.rebarWaste = parseNum(_rw.text, 5).clamp(0, 50);
    p.blockWaste = parseNum(_bw.text, 5).clamp(0, 50);
    final b = parseNum(_bpm.text, 12.5);
    p.blocksPerM2 = b <= 0 ? 12.5 : b;
    p.mix = _mix.text.trim().isEmpty ? '1:2:4' : _mix.text.trim();
    await BoqStore.save(p);
  }

  Future<void> _addItem() async {
    final type = await showModalBottomSheet<BoqType>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('نوع العنصر',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
            for (final t in BoqType.values)
              ListTile(
                leading: Icon(_icon(t)),
                title: Text(typeLabel(t)),
                subtitle: Text(_hint(t)),
                onTap: () => Navigator.pop(ctx, t),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (type == null || !mounted) return;
    final res = await Navigator.push<BoqItem>(
      context,
      MaterialPageRoute(
        builder: (_) => BoqItemPage(
            item: BoqItem.blank(type), isNew: true, blocksPerM2: p.blocksPerM2),
      ),
    );
    if (res != null) {
      setState(() => p.items.add(res));
      await _save();
    }
  }

  Future<void> _editItem(int i) async {
    final res = await Navigator.push<BoqItem>(
      context,
      MaterialPageRoute(
        builder: (_) => BoqItemPage(
            item: p.items[i], isNew: false, blocksPerM2: p.blocksPerM2),
      ),
    );
    if (res != null) {
      setState(() => p.items[i] = res);
      await _save();
    }
  }

  IconData _icon(BoqType t) {
    switch (t) {
      case BoqType.concrete:
        return Icons.foundation;
      case BoqType.wall:
        return Icons.grid_on;
      case BoqType.plaster:
        return Icons.layers_outlined;
      case BoqType.paint:
        return Icons.format_paint_outlined;
    }
  }

  String _hint(BoqType t) {
    switch (t) {
      case BoqType.concrete:
        return 'قواعد، أعمدة، جسور، أسقف + الحديد';
      case BoqType.wall:
        return 'جدران بلوك مع خصم الفتحات';
      case BoqType.plaster:
        return 'مساحة وحجم مونة اللياسة';
      case BoqType.paint:
        return 'مساحة الدهان وعدد الطبقات';
    }
  }

  String _summary(BoqItem e) {
    switch (e.type) {
      case BoqType.concrete:
        return '${fmt(e.n, 0)} × ${fmt(e.l)}×${fmt(e.w)}×${fmt(e.h)} = ${fmt(e.volume)} م³ • حديد ${fmt(e.rebarKg, 0)} كجم';
      case BoqType.wall:
        return 'صافي ${fmt(e.wallNetArea)} م² • ${fmt(e.wallNetArea * p.blocksPerM2, 0)} بلوكة';
      case BoqType.plaster:
        return '${fmt(e.coatedArea)} م² • ${fmt(e.plasterVolume, 3)} م³';
      case BoqType.paint:
        return '${fmt(e.coatedArea)} م² • ${fmt(e.paintLiters)} لتر';
    }
  }

  // ---------------- قراءة مخطط بالذكاء الاصطناعي ----------------
  Future<void> _readPlan() async {
    final wh = TextEditingController(text: '3');
    final st = TextEditingController(text: '0.2');
    final ch = TextEditingController(text: '3');
    final extra = TextEditingController();
    Uint8List? bytes;
    var mime = 'image/jpeg';
    var imgName = '';
    var running = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('قراءة مخطط (تجريبي)'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                    'النتيجة تقريبية وتحتاج مراجعتك. الأفضل مخطط واضح فيه أبعاد مكتوبة.',
                    style: TextStyle(fontSize: 12.5, height: 1.5)),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: running
                      ? null
                      : () async {
                          try {
                            final x = await ImagePicker().pickImage(
                                source: ImageSource.gallery,
                                maxWidth: 2200,
                                imageQuality: 88);
                            if (x == null) return;
                            final b = await x.readAsBytes();
                            setD(() {
                              bytes = b;
                              imgName = x.name;
                              mime = x.name.toLowerCase().endsWith('.png')
                                  ? 'image/png'
                                  : 'image/jpeg';
                            });
                          } catch (e) {
                            if (mounted) _msg('تعذّر اختيار الصورة.\nالسبب: $e');
                          }
                        },
                  icon: const Icon(Icons.image_outlined),
                  label: Text(bytes == null ? 'اختيار صورة المخطط' : 'تم: $imgName'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: wh,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'ارتفاع الجدران (م)'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: ch,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'ارتفاع الأعمدة (م)'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: st,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'سماكة البلاطة (م)'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: extra,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                      labelText: 'ملاحظات للقارئ (اختياري)',
                      hintText: 'مثال: المقياس 1:100، احسب الجدران الخارجية فقط'),
                ),
                if (running)
                  const Padding(
                    padding: EdgeInsets.only(top: 14),
                    child: Center(child: CircularProgressIndicator()),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: running ? null : () => Navigator.pop(ctx),
                child: const Text('إغلاق')),
            TextButton(
              onPressed: (running || bytes == null)
                  ? null
                  : () async {
                      setD(() => running = true);
                      try {
                        final r = await BoqPlanReader.read(
                          bytes: bytes!,
                          mime: mime,
                          wallHeight: parseNum(wh.text, 3),
                          slabThickness: parseNum(st.text, 0.2),
                          columnHeight: parseNum(ch.text, 3),
                          extra: extra.text,
                        );
                        if (!mounted) return;
                        Navigator.pop(ctx);
                        await _confirmAi(r.items, r.notes);
                      } on AiException catch (e) {
                        if (mounted) _msg(e.message);
                        setD(() => running = false);
                      } catch (_) {
                        if (mounted) {
                          _msg('لم أستطع قراءة المخطط. جرّب صورة أوضح.');
                        }
                        setD(() => running = false);
                      }
                    },
              child: const Text('اقرأ المخطط'),
            ),
          ],
        ),
      ),
    );
    wh.dispose();
    st.dispose();
    ch.dispose();
    extra.dispose();
  }

  Future<void> _confirmAi(List<BoqItem> items, String notes) async {
    if (items.isEmpty) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('لم يُستخرج شيء'),
          content: Text(notes.isEmpty
              ? 'لم أجد أبعاداً مقروءة في الصورة.'
              : notes),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c), child: const Text('حسناً'))
          ],
        ),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('استُخرج ${items.length} عنصر'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final e in items)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('• ${e.name} — ${_summary(e)}',
                      style: const TextStyle(fontSize: 13)),
                ),
              if (notes.isNotEmpty) ...[
                const Divider(),
                Text('ملاحظات القارئ: $notes',
                    style: const TextStyle(fontSize: 13, height: 1.5)),
              ],
              const SizedBox(height: 6),
              const Text('ستُضاف بعلامة "راجعه" ويمكنك تعديل كل عنصر.',
                  style: TextStyle(fontSize: 12)),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('تجاهل')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('إضافة')),
        ],
      ),
    );
    if (ok == true) {
      setState(() => p.items.addAll(items));
      await _save();
    }
  }

  // ---------------- التصدير ----------------
  Future<void> _export(Future<void> Function(BoqProject) fn, String err) async {
    await _save();
    setState(() => _busy = true);
    try {
      await fn(p);
    } catch (e) {
      if (mounted) _msg(err);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('جدول الكميات'),
          actions: [
            IconButton(
              tooltip: 'قراءة مخطط بالذكاء الاصطناعي',
              icon: const Icon(Icons.auto_awesome),
              onPressed: _readPlan,
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'العناصر'),
              Tab(text: 'الإعدادات'),
              Tab(text: 'النتائج'),
            ],
          ),
        ),
        body: TabBarView(
          children: [_itemsTab(), _settingsTab(), _resultsTab()],
        ),
      ),
    );
  }

  Widget _itemsTab() {
    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          children: [
            TextField(
              controller: _name,
              onChanged: (_) => _save(),
              decoration: const InputDecoration(labelText: 'اسم المشروع'),
            ),
            const SizedBox(height: 14),
            if (p.items.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text(
                  'أضف عناصر الخرسانة والجدران واللياسة والدهانات، أو اقرأ مخططاً بالذكاء الاصطناعي (الأيقونة ✨ في الأعلى).',
                  textAlign: TextAlign.center,
                  style: TextStyle(height: 1.7),
                ),
              ),
            for (var i = 0; i < p.items.length; i++)
              Card(
                child: ListTile(
                  leading: Icon(_icon(p.items[i].type)),
                  title: Text(p.items[i].name.isEmpty
                      ? typeLabel(p.items[i].type)
                      : p.items[i].name),
                  subtitle: Text(
                      '${_summary(p.items[i])}${p.items[i].fromAi ? '\n⚠ من الذكاء الاصطناعي — راجعه' : ''}'),
                  isThreeLine: p.items[i].fromAi,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      setState(() => p.items.removeAt(i));
                      await _save();
                    },
                  ),
                  onTap: () => _editItem(i),
                ),
              ),
          ],
        ),
        Positioned(
          left: 16,
          bottom: 16,
          child: FloatingActionButton.extended(
            onPressed: _addItem,
            icon: const Icon(Icons.add),
            label: const Text('إضافة عنصر'),
          ),
        ),
      ],
    );
  }

  Widget _settingsTab() {
    Widget f(TextEditingController c, String label, {String? suffix, bool ltr = false}) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          textDirection: ltr ? TextDirection.ltr : null,
          keyboardType: ltr
              ? TextInputType.text
              : const TextInputType.numberWithOptions(decimal: true),
          onChanged: (_) {
            _save();
            setState(() {});
          },
          decoration: InputDecoration(labelText: label, suffixText: suffix),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        f(_cw, 'هدر الخرسانة', suffix: '%'),
        f(_rw, 'هدر الحديد', suffix: '%'),
        f(_bw, 'هدر البلوك', suffix: '%'),
        f(_bpm, 'عدد البلوك في المتر المربع (بلوك 40×20 = 12.5)'),
        f(_mix, 'نسبة خلطة الخرسانة (أسمنت:رمل:حصى)', ltr: true),
        Wrap(
          spacing: 8,
          children: [
            for (final m in ['1:2:4', '1:1.5:3', '1:3:6'])
              ActionChip(
                label: Text(m),
                onPressed: () {
                  _mix.text = m;
                  _save();
                  setState(() {});
                },
              ),
          ],
        ),
        const SizedBox(height: 16),
        const Text(
          'ملاحظة: نسب الحديد تُحدَّد لكل عنصر خرسانة عند إضافته، وهي تقديرية وتُستبدل بجدول حديد معتمد.',
          style: TextStyle(height: 1.6, fontSize: 13),
        ),
      ],
    );
  }

  Widget _resultsTab() {
    final sections = buildBoqSections(p);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        for (final s in sections) ...[
          Text(s.title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowHeight: 40,
              dataRowMinHeight: 36,
              dataRowMaxHeight: 52,
              columnSpacing: 18,
              columns: [
                for (final h in s.headers)
                  DataColumn(
                      label: Text(h,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 13))),
              ],
              rows: [
                for (final r in s.rows)
                  DataRow(cells: [
                    for (final c in r)
                      DataCell(Text(c, style: const TextStyle(fontSize: 13))),
                  ]),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
        const Text(kBoqDisclaimer, style: TextStyle(fontSize: 12, height: 1.6)),
        const SizedBox(height: 16),
        if (_busy)
          const Center(child: CircularProgressIndicator())
        else ...[
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _export(BoqExport.sharePdf,
                      'تعذّر إنشاء PDF. تأكد من الإنترنت (لتحميل الخط) وأعد المحاولة.'),
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('PDF'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _export(
                      BoqExport.shareDocx, 'تعذّر إنشاء ملف Word. أعد المحاولة.'),
                  icon: const Icon(Icons.description_outlined),
                  label: const Text('Word'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => _export(BoqExport.shareText, 'تعذّرت المشاركة.'),
            icon: const Icon(Icons.share_outlined),
            label: const Text('مشاركة كنص'),
            style:
                OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: boqAsText(p)));
              if (mounted) _msg('تم نسخ النتائج');
            },
            icon: const Icon(Icons.copy),
            label: const Text('نسخ النتائج'),
          ),
        ],
        const SizedBox(height: 30),
      ],
    );
  }
}
