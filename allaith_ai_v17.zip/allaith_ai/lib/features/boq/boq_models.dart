import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

enum BoqType { concrete, wall, plaster, paint }

const Map<String, String> kConcreteKinds = {
  'footing': 'قواعد',
  'column': 'أعمدة',
  'beam': 'جسور',
  'slab': 'أسقف',
  'other': 'أخرى',
};

/// نسب حديد تقديرية (كجم لكل م³ خرسانة)، قابلة للتعديل لكل عنصر.
const Map<String, double> kRebarDefaults = {
  'footing': 80,
  'column': 180,
  'beam': 150,
  'slab': 90,
  'other': 100,
};

String typeLabel(BoqType t) {
  switch (t) {
    case BoqType.concrete:
      return 'خرسانة';
    case BoqType.wall:
      return 'مباني بلوك';
    case BoqType.plaster:
      return 'لياسة';
    case BoqType.paint:
      return 'دهانات';
  }
}

/// يحوّل نصاً (قد يحوي أرقاماً عربية أو فاصلة عشرية عربية) إلى رقم.
double parseNum(String s, [double def = 0]) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var t = s.trim();
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(ar[i], '$i');
  }
  t = t.replaceAll('٫', '.').replaceAll(',', '.').replaceAll('،', '.');
  return double.tryParse(t) ?? def;
}

String fmt(double v, [int d = 2]) {
  final s = v.toStringAsFixed(d);
  if (!s.contains('.')) return s;
  return s.replaceFirst(RegExp(r'\.?0+$'), '');
}

class BoqItem {
  String id;
  BoqType type;
  String name;
  String kind; // لنوع الخرسانة
  double n; // العدد
  double l; // الطول (م)
  double w; // العرض (م)
  double h; // الارتفاع (م) أو السماكة للخرسانة
  double t; // سماكة اللياسة (سم)
  double openings; // مساحة الفتحات (م²)
  int sides; // عدد الوجوه
  int coats; // عدد طبقات الدهان
  double coverage; // تغطية اللتر (م²)
  double rebar; // كجم/م³
  bool fromAi;

  BoqItem({
    required this.id,
    required this.type,
    this.name = '',
    this.kind = 'column',
    this.n = 1,
    this.l = 0,
    this.w = 0,
    this.h = 0,
    this.t = 2,
    this.openings = 0,
    this.sides = 2,
    this.coats = 2,
    this.coverage = 10,
    this.rebar = 100,
    this.fromAi = false,
  });

  static String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  factory BoqItem.blank(BoqType type) {
    final it = BoqItem(id: newId(), type: type);
    if (type == BoqType.concrete) {
      it.kind = 'column';
      it.rebar = kRebarDefaults['column']!;
    }
    if (type == BoqType.paint) it.sides = 2;
    return it;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.index,
        'name': name,
        'kind': kind,
        'n': n,
        'l': l,
        'w': w,
        'h': h,
        't': t,
        'openings': openings,
        'sides': sides,
        'coats': coats,
        'coverage': coverage,
        'rebar': rebar,
        'ai': fromAi,
      };

  factory BoqItem.fromJson(Map<String, dynamic> j) => BoqItem(
        id: j['id'] as String,
        type: BoqType.values[(j['type'] as int?) ?? 0],
        name: (j['name'] as String?) ?? '',
        kind: (j['kind'] as String?) ?? 'column',
        n: (j['n'] as num?)?.toDouble() ?? 1,
        l: (j['l'] as num?)?.toDouble() ?? 0,
        w: (j['w'] as num?)?.toDouble() ?? 0,
        h: (j['h'] as num?)?.toDouble() ?? 0,
        t: (j['t'] as num?)?.toDouble() ?? 2,
        openings: (j['openings'] as num?)?.toDouble() ?? 0,
        sides: (j['sides'] as num?)?.toInt() ?? 2,
        coats: (j['coats'] as num?)?.toInt() ?? 2,
        coverage: (j['coverage'] as num?)?.toDouble() ?? 10,
        rebar: (j['rebar'] as num?)?.toDouble() ?? 100,
        fromAi: (j['ai'] as bool?) ?? false,
      );

  // ---------- الحسابات ----------
  double get volume => n * l * w * h;
  double get rebarKg => volume * rebar;
  double get grossArea => l * h;
  double get wallNetArea => (l * h - openings).clamp(0, double.infinity);
  double get coatedArea =>
      (l * h * sides - openings).clamp(0, double.infinity);
  double get plasterVolume => coatedArea * t / 100;
  double get paintLiters => coverage <= 0 ? 0 : coatedArea * coats / coverage;
}

class BoqProject {
  String id;
  String name;
  int date;
  int updated;
  double concreteWaste; // %
  double rebarWaste; // %
  double blockWaste; // %
  double blocksPerM2; // بلوك 40×20 = 12.5
  String mix; // مثل 1:2:4
  List<BoqItem> items;

  BoqProject({
    required this.id,
    this.name = '',
    required this.date,
    required this.updated,
    this.concreteWaste = 5,
    this.rebarWaste = 5,
    this.blockWaste = 5,
    this.blocksPerM2 = 12.5,
    this.mix = '1:2:4',
    List<BoqItem>? items,
  }) : items = items ?? [];

  factory BoqProject.create() {
    final now = DateTime.now().millisecondsSinceEpoch;
    return BoqProject(id: now.toString(), date: now, updated: now);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'date': date,
        'updated': updated,
        'cw': concreteWaste,
        'rw': rebarWaste,
        'bw': blockWaste,
        'bpm': blocksPerM2,
        'mix': mix,
        'items': items.map((e) => e.toJson()).toList(),
      };

  factory BoqProject.fromJson(Map<String, dynamic> j) => BoqProject(
        id: j['id'] as String,
        name: (j['name'] as String?) ?? '',
        date: (j['date'] as int?) ?? 0,
        updated: (j['updated'] as int?) ?? 0,
        concreteWaste: (j['cw'] as num?)?.toDouble() ?? 5,
        rebarWaste: (j['rw'] as num?)?.toDouble() ?? 5,
        blockWaste: (j['bw'] as num?)?.toDouble() ?? 5,
        blocksPerM2: (j['bpm'] as num?)?.toDouble() ?? 12.5,
        mix: (j['mix'] as String?) ?? '1:2:4',
        items: ((j['items'] as List?) ?? [])
            .map((e) => BoqItem.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );

  BoqTotals totals() => BoqTotals.of(this);
}

class BoqTotals {
  final Map<String, double> concreteByKind;
  final double concrete;
  final double concreteWithWaste;
  final double rebarKg;
  final double rebarWithWaste;
  final double cementBags; // كيس 50 كجم
  final double sandM3;
  final double gravelM3;
  final double wallNet;
  final double blocks;
  final double blocksWithWaste;
  final double plasterArea;
  final double plasterVolume;
  final double paintArea;
  final double paintLiters;

  BoqTotals({
    required this.concreteByKind,
    required this.concrete,
    required this.concreteWithWaste,
    required this.rebarKg,
    required this.rebarWithWaste,
    required this.cementBags,
    required this.sandM3,
    required this.gravelM3,
    required this.wallNet,
    required this.blocks,
    required this.blocksWithWaste,
    required this.plasterArea,
    required this.plasterVolume,
    required this.paintArea,
    required this.paintLiters,
  });

  static List<double> _mix(String s) {
    final parts = s.split(':').map((e) => parseNum(e, 0)).toList();
    if (parts.length == 3 && parts.every((x) => x > 0)) return parts;
    return [1, 2, 4];
  }

  factory BoqTotals.of(BoqProject p) {
    final byKind = <String, double>{};
    var conc = 0.0, rebar = 0.0, wall = 0.0;
    var pArea = 0.0, pVol = 0.0, paArea = 0.0, paL = 0.0;
    for (final it in p.items) {
      switch (it.type) {
        case BoqType.concrete:
          conc += it.volume;
          rebar += it.rebarKg;
          byKind[it.kind] = (byKind[it.kind] ?? 0) + it.volume;
          break;
        case BoqType.wall:
          wall += it.wallNetArea;
          break;
        case BoqType.plaster:
          pArea += it.coatedArea;
          pVol += it.plasterVolume;
          break;
        case BoqType.paint:
          paArea += it.coatedArea;
          paL += it.paintLiters;
          break;
      }
    }
    final cWaste = conc * (1 + p.concreteWaste / 100);
    final m = _mix(p.mix);
    final sum = m[0] + m[1] + m[2];
    const dryFactor = 1.54; // معامل الحجم الجاف
    final cementM3 = cWaste * dryFactor * m[0] / sum;
    final cementBags = cementM3 * 1440 / 50; // كثافة الأسمنت 1440 كجم/م³
    final sand = cWaste * dryFactor * m[1] / sum;
    final gravel = cWaste * dryFactor * m[2] / sum;
    final blocks = wall * p.blocksPerM2;
    return BoqTotals(
      concreteByKind: byKind,
      concrete: conc,
      concreteWithWaste: cWaste,
      rebarKg: rebar,
      rebarWithWaste: rebar * (1 + p.rebarWaste / 100),
      cementBags: cementBags,
      sandM3: sand,
      gravelM3: gravel,
      wallNet: wall,
      blocks: blocks,
      blocksWithWaste: blocks * (1 + p.blockWaste / 100),
      plasterArea: pArea,
      plasterVolume: pVol,
      paintArea: paArea,
      paintLiters: paL,
    );
  }
}

class BoqStore {
  static const _key = 'boq_projects_v1';

  static Future<List<BoqProject>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => BoqProject.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      list.sort((a, b) => b.updated.compareTo(a.updated));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<BoqProject> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(l.map((e) => e.toJson()).toList()));
  }

  static Future<void> save(BoqProject pr) async {
    final list = await load();
    pr.updated = DateTime.now().millisecondsSinceEpoch;
    final i = list.indexWhere((x) => x.id == pr.id);
    if (i >= 0) {
      list[i] = pr;
    } else {
      list.add(pr);
    }
    await _write(list);
  }

  static Future<void> delete(String id) async {
    final list = await load();
    list.removeWhere((x) => x.id == id);
    await _write(list);
  }
}

/// جداول التقرير (تُستخدم في النص وPDF وWord).
class BoqSection {
  final String title;
  final List<String> headers;
  final List<List<String>> rows;
  BoqSection(this.title, this.headers, this.rows);
}

List<BoqSection> buildBoqSections(BoqProject p) {
  final t = p.totals();
  final out = <BoqSection>[];

  final conc = p.items.where((e) => e.type == BoqType.concrete).toList();
  if (conc.isNotEmpty) {
    out.add(BoqSection('الخرسانة والحديد', [
      'العنصر',
      'النوع',
      'العدد',
      'الأبعاد (م)',
      'الحجم م³',
      'الحديد كجم'
    ], [
      for (final e in conc)
        [
          e.name.isEmpty ? '—' : e.name,
          kConcreteKinds[e.kind] ?? e.kind,
          fmt(e.n, 0),
          '${fmt(e.l)}×${fmt(e.w)}×${fmt(e.h)}',
          fmt(e.volume),
          fmt(e.rebarKg, 0),
        ],
    ]));
  }
  final walls = p.items.where((e) => e.type == BoqType.wall).toList();
  if (walls.isNotEmpty) {
    out.add(BoqSection('المباني (البلوك)', [
      'العنصر',
      'الطول م',
      'الارتفاع م',
      'الفتحات م²',
      'المساحة الصافية م²',
      'عدد البلوك'
    ], [
      for (final e in walls)
        [
          e.name.isEmpty ? '—' : e.name,
          fmt(e.l),
          fmt(e.h),
          fmt(e.openings),
          fmt(e.wallNetArea),
          fmt(e.wallNetArea * p.blocksPerM2, 0),
        ],
    ]));
  }
  final pl = p.items.where((e) => e.type == BoqType.plaster).toList();
  if (pl.isNotEmpty) {
    out.add(BoqSection('اللياسة', [
      'العنصر',
      'الطول م',
      'الارتفاع م',
      'الوجوه',
      'المساحة م²',
      'الحجم م³'
    ], [
      for (final e in pl)
        [
          e.name.isEmpty ? '—' : e.name,
          fmt(e.l),
          fmt(e.h),
          '${e.sides}',
          fmt(e.coatedArea),
          fmt(e.plasterVolume, 3),
        ],
    ]));
  }
  final pa = p.items.where((e) => e.type == BoqType.paint).toList();
  if (pa.isNotEmpty) {
    out.add(BoqSection('الدهانات', [
      'العنصر',
      'المساحة م²',
      'الطبقات',
      'التغطية م²/لتر',
      'اللترات'
    ], [
      for (final e in pa)
        [
          e.name.isEmpty ? '—' : e.name,
          fmt(e.coatedArea),
          '${e.coats}',
          fmt(e.coverage),
          fmt(e.paintLiters),
        ],
    ]));
  }

  final sum = <List<String>>[
    ['حجم الخرسانة (صافي)', fmt(t.concrete), 'م³'],
    [
      'حجم الخرسانة مع الهدر ${fmt(p.concreteWaste)}%',
      fmt(t.concreteWithWaste),
      'م³'
    ],
    ['حديد التسليح (تقديري)', fmt(t.rebarKg, 0), 'كجم'],
    [
      'حديد التسليح مع الهدر ${fmt(p.rebarWaste)}%',
      fmt(t.rebarWithWaste, 0),
      'كجم (${fmt(t.rebarWithWaste / 1000, 2)} طن)'
    ],
    ['أسمنت للخرسانة (خلطة ${p.mix})', fmt(t.cementBags, 0), 'كيس 50 كجم'],
    ['رمل للخرسانة', fmt(t.sandM3), 'م³'],
    ['حصى للخرسانة', fmt(t.gravelM3), 'م³'],
    ['مساحة المباني الصافية', fmt(t.wallNet), 'م²'],
    [
      'البلوك مع الهدر ${fmt(p.blockWaste)}%',
      fmt(t.blocksWithWaste, 0),
      'بلوكة'
    ],
    ['مساحة اللياسة', fmt(t.plasterArea), 'م²'],
    ['حجم مونة اللياسة (صافي)', fmt(t.plasterVolume, 2), 'م³'],
    ['مساحة الدهان', fmt(t.paintArea), 'م²'],
    ['كمية الدهان', fmt(t.paintLiters), 'لتر'],
  ];
  out.add(BoqSection('ملخص الكميات', ['البند', 'الكمية', 'الوحدة'], sum));
  return out;
}

const String kBoqDisclaimer =
    'الكميات تقديرية حسب الأبعاد المدخلة. حديد التسليح محسوب بنسب تقديرية (كجم/م³) ويُستبدل بجدول حديد معتمد. مكونات الخرسانة بمعامل حجم جاف 1.54. يُراجَع التقرير من مهندس مختص قبل الاعتماد.';

String boqAsText(BoqProject p) {
  final b = StringBuffer('جدول الكميات: ${p.name.isEmpty ? 'مشروع' : p.name}\n');
  for (final s in buildBoqSections(p)) {
    b.writeln('\n— ${s.title} —');
    for (final r in s.rows) {
      b.writeln(r.join(' | '));
    }
  }
  b.writeln('\n$kBoqDisclaimer');
  return b.toString();
}
