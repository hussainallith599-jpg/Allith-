import 'package:flutter/material.dart';
import 'boq_ai_list.dart';
import 'boq_home.dart';

/// واجهة الكميات: المساعد الذكي + الحاسبة اليدوية.
class BoqHub extends StatelessWidget {
  const BoqHub({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الكميات BOQ'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'من المخططات (ذكي)'),
              Tab(text: 'حاسبة يدوية'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [BoqAiList(), BoqHome(embedded: true)],
        ),
      ),
    );
  }
}
