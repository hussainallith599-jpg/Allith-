import 'dart:convert';
import 'dart:typed_data';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/services/ai_text_service.dart';
import '../../core/theme/app_theme.dart';
import 'boq_ai_doc_screen.dart';
import 'boq_ai_export.dart';
import 'boq_ai_models.dart';
import 'boq_ai_prompt.dart';

class _Msg {
  final bool user;
  final String text;
  final List<AiFile> files;
  final BoqAiResult? res;
  final bool error;
  final bool auto; // رسالة إكمال تلقائي
  final String? raw; // الرد الخام عند فشل التحليل
  _Msg(this.user, this.text,
      {this.files = const [],
      this.res,
      this.error = false,
      this.auto = false,
      this.raw});
}

/// مساعد الكميات الذكي: يقرأ المخططات (صور/PDF) وطلبك، يسأل عمّا ينقص، ثم يُخرج الجدول.
class BoqAiScreen extends StatefulWidget {
  final BoqAiDoc? existing;
  const BoqAiScreen({super.key, this.existing});
  @override
  State<BoqAiScreen> createState() => _BoqAiScreenState();
}

class _BoqAiScreenState extends State<BoqAiScreen> {
  static const _maxBytes = 18 * 1024 * 1024;
  static const _starters = [
    'احسب كميات البناء بالبلوك فقط من المخططات المرفقة',
    'احسب كميات الخرسانة (قواعد، أعمدة، جسور، أسقف) من المخططات الإنشائية',
    'احسب كل الكميات مع كتابة البنود والمواصفات حسب مواصفات السعودية',
    'احسب كل الكميات مع كتابة البنود والمواصفات حسب مواصفات اليمن',
    'هذه بنودي ومواصفاتي (سألصقها): احسب كمياتها من المخططات',
  ];

  final _ctl = TextEditingController();
  final _scroll = ScrollController();
  final List<_Msg> _msgs = [];
  final List<AiFile> _pending = [];
  BoqAiDoc? _doc;
  bool _busy = false;
  int? _editIdx;

  @override
  void initState() {
    super.initState();
    _doc = widget.existing;
  }

  @override
  void dispose() {
    _ctl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  int get _usedBytes {
    var t = 0;
    for (final m in _msgs) {
      for (final f in m.files) {
        t += f.bytes.length;
      }
    }
    for (final f in _pending) {
      t += f.bytes.length;
    }
    return t;
  }

  void _scrollEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('صور من المعرض'),
              subtitle: const Text('يمكنك اختيار عدة صور'),
              onTap: () => Navigator.pop(ctx, 'img'),
            ),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: const Text('ملف PDF'),
              subtitle: const Text('مخططات معمارية أو إنشائية'),
              onTap: () => Navigator.pop(ctx, 'pdf'),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    try {
      final added = <AiFile>[];
      if (choice == 'img') {
        final xs = await ImagePicker().pickMultiImage(maxWidth: 2600, imageQuality: 90);
        for (final x in xs) {
          final b = await x.readAsBytes();
          final isPng = x.name.toLowerCase().endsWith('.png');
          added.add(AiFile(x.name, isPng ? 'image/png' : 'image/jpeg', b));
        }
      } else {
        final x = await openFile(acceptedTypeGroups: [
          const XTypeGroup(
              label: 'PDF', extensions: ['pdf'], mimeTypes: ['application/pdf'])
        ]);
        if (x != null) {
          added.add(AiFile(x.name, 'application/pdf', await x.readAsBytes()));
        }
      }
      if (added.isEmpty) return;
      final addBytes = added.fold<int>(0, (a, f) => a + f.bytes.length);
      if (_usedBytes + addBytes > _maxBytes) {
        _msg('حجم الملفات كبير (الحد حوالي 18 ميجابايت). قلّل الصفحات أو اضغط الملف.');
        return;
      }
      setState(() => _pending.addAll(added));
    } catch (e) {
      _msg('تعذّر إرفاق الملف.\nالسبب: $e');
    }
  }

  /// يبني أدوار المحادثة للنموذج: يدمج الرسائل المتتالية ويضيف المستند الحالي لآخر رسالة.
  List<AiTurn> _buildTurns() {
    var lastDocIdx = -1;
    for (var i = 0; i < _msgs.length; i++) {
      if (!_msgs[i].user && _msgs[i].res?.doc != null) lastDocIdx = i;
    }
    final turns = <AiTurn>[];
    for (var i = 0; i < _msgs.length; i++) {
      final m = _msgs[i];
      if (m.error) continue;
      var text = m.text;
      if (!m.user && m.res != null) {
        text = (m.res!.doc != null && i != lastDocIdx) ? '(جدول كميات سابق)' : m.res!.raw;
      }
      final role = m.user ? 'user' : 'assistant';
      if (turns.isNotEmpty && turns.last.role == role) {
        final prev = turns.removeLast();
        turns.add(AiTurn(role, '${prev.text}\n\n$text', [...prev.files, ...m.files]));
      } else {
        turns.add(AiTurn(role, text, m.files));
      }
    }
    if (_doc != null && turns.isNotEmpty && turns.last.role == 'user') {
      final last = turns.removeLast();
      final ctx = jsonEncode({'boq': _doc!.toAiJson()});
      turns.add(AiTurn('user',
          '${last.text}\n\n[المستند الحالي (بعد أي تعديل يدوي):\n$ctx\n]', last.files));
    }
    return turns;
  }

  Future<BoqAiResult> _askModel() async {
    final raw = await AiTextService.chatFiles(kBoqAiSystem, _buildTurns());
    return BoqAiResult.parse(raw, truncated: AiTextService.lastTruncated);
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _ctl.text).trim();
    if ((text.isEmpty && _pending.isEmpty) || _busy) return;
    setState(() {
      if (_editIdx != null) {
        _msgs.removeRange(_editIdx!, _msgs.length);
        _editIdx = null;
        BoqAiDoc? d;
        for (final m in _msgs) {
          if (!m.user && m.res?.doc != null) d = m.res!.doc;
        }
        _doc = d ?? widget.existing;
      }
      _msgs.add(_Msg(true, text, files: List.of(_pending)));
      _pending.clear();
      _ctl.clear();
      _busy = true;
    });
    _scrollEnd();
    var merge = false;
    try {
      for (var round = 0; round < 8; round++) {
        final res = await _askModel();
        if (!mounted) return;
        setState(() {
          _msgs.add(_Msg(false, res.message, res: res));
          final nd = res.doc;
          if (nd != null && nd.itemCount > 0) {
            if (merge && _doc != null) {
              mergeBoqDoc(_doc!, nd);
            } else {
              if (_doc != null) nd.copyMetaFrom(_doc!);
              _doc = nd;
            }
          }
        });
        if (_doc != null) await BoqAiStore.save(_doc!);
        _scrollEnd();
        final more =
            res.doc != null && (res.truncated || res.remaining.isNotEmpty);
        if (!more) break;
        final rem = res.remaining.isEmpty
            ? ''
            : ' الأقسام المتبقية: ${res.remaining.join('، ')}.';
        final note = res.truncated
            ? 'انقطع الرد السابق عند ${res.lastPoint}. أكمل بعده فقط البنود والأقسام التي لم تُكتب بعد ولا تكرر ما سبق.$rem'
            : 'أكمل الأقسام المتبقية فقط ولا تكرر ما سبق.$rem';
        setState(() => _msgs.add(_Msg(true, note, auto: true)));
        merge = true;
      }
    } on AiException catch (e) {
      if (mounted) setState(() => _msgs.add(_Msg(false, e.message, error: true)));
    } on BoqParseFailure catch (e) {
      if (mounted) {
        setState(() => _msgs.add(_Msg(
            false,
            e.truncated
                ? 'انقطع رد النموذج قبل أن يكتمل ولم أستطع استرجاعه. جرّب طلب نطاق أصغر (قسم واحد من الأعمال) أو أعد المحاولة.'
                : 'لم أستطع فهم رد النموذج. يمكنك نسخ الرد الخام وإرساله إلى المطوّر لفحصه.',
            error: true,
            raw: e.raw)));
      }
    } catch (e) {
      if (mounted) setState(() => _msgs.add(_Msg(false, 'حدث خطأ: $e', error: true)));
    } finally {
      if (mounted) setState(() => _busy = false);
      _scrollEnd();
    }
  }

  Future<void> _msgMenu(int idx) async {
    final m = _msgs[idx];
    final c = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.copy),
              title: const Text('نسخ الرسالة'),
              onTap: () => Navigator.pop(ctx, 'copy'),
            ),
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('تعديل الرسالة وإعادة الإرسال'),
              subtitle: const Text('ستُحذف الردود التي بعدها'),
              onTap: () => Navigator.pop(ctx, 'edit'),
            ),
          ],
        ),
      ),
    );
    if (c == 'copy') {
      await Clipboard.setData(ClipboardData(text: m.text));
      if (mounted) _msg('تم النسخ');
    } else if (c == 'edit' && !_busy) {
      setState(() {
        _editIdx = idx;
        _ctl.text = m.text;
        _pending
          ..clear()
          ..addAll(m.files);
      });
    }
  }

  Future<void> _openDoc() async {
    if (_doc == null) return;
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => BoqAiDocScreen(doc: _doc!)));
    if (mounted) setState(() {});
  }

  Future<void> _export(Future<void> Function(BoqAiDoc) fn) async {
    if (_doc == null) return;
    setState(() => _busy = true);
    try {
      await fn(_doc!);
    } catch (_) {
      if (mounted) _msg('تعذّر إنشاء الملف. أعد المحاولة.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مساعد الكميات الذكي'),
        actions: [
          if (_doc != null)
            IconButton(
              tooltip: 'فتح الجدول وتعديله',
              icon: const Icon(Icons.table_chart_outlined),
              onPressed: _openDoc,
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _msgs.isEmpty ? _empty() : _list()),
          if (_editIdx != null)
            Container(
              width: double.infinity,
              color: const Color(0xFFFFF8E1),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              child: Row(
                children: [
                  const Icon(Icons.edit_outlined, size: 18),
                  const SizedBox(width: 8),
                  const Expanded(
                      child: Text('تعديل رسالة — سيُعاد الإرسال وتُحذف الردود بعدها',
                          style: TextStyle(fontSize: 12.5))),
                  TextButton(
                    onPressed: () => setState(() {
                      _editIdx = null;
                      _ctl.clear();
                      _pending.clear();
                    }),
                    child: const Text('إلغاء'),
                  ),
                ],
              ),
            ),
          if (_pending.isNotEmpty) _pendingBar(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _empty() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Icon(Icons.auto_awesome, size: 44),
        const SizedBox(height: 10),
        Text('أرفق المخططات واكتب طلبك',
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text(
          'سأقرأ الأبعاد من المخططات وأحسب الكميات داخل التطبيق بمعادلات ثابتة. وإن نقصتني معلومة (ارتفاع، سماكة، تشطيب، مواصفات) سأسألك ولن أفترضها. ثم تعدّل الجدول بالمحادثة أو يدوياً وتصدّره Excel أو PDF أو Word.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.7, fontSize: 13.5),
        ),
        const SizedBox(height: 16),
        for (final s in _starters)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                title: Text(s, style: const TextStyle(fontSize: 14)),
                trailing: const Icon(Icons.north_west, size: 18),
                onTap: () => setState(() => _ctl.text = s),
              ),
            ),
          ),
      ],
    );
  }

  Widget _list() {
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(12),
      itemCount: _msgs.length + (_busy ? 1 : 0),
      itemBuilder: (context, i) {
        if (i == _msgs.length) return _typing();
        return _bubble(_msgs[i], i);
      },
    );
  }

  Widget _typing() => Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            SizedBox(
                height: 16,
                width: 16,
                child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 10),
            Text('أقرأ المخططات وأحسب... قد يستغرق دقائق'),
          ]),
        ),
      );

  Widget _bubble(_Msg m, int idx) {
    final maxW = MediaQuery.of(context).size.width * 0.88;
    if (m.auto) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Center(
          child: Text('⏭ طلب إكمال تلقائي...',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        ),
      );
    }
    if (m.user) {
      return Align(
        alignment: AlignmentDirectional.centerStart,
        child: GestureDetector(
          onLongPress: () => _msgMenu(idx),
          child: Container(
          constraints: BoxConstraints(maxWidth: maxW),
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.ink,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (m.files.isNotEmpty)
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final f in m.files)
                      Chip(
                        avatar: Icon(
                            f.mime == 'application/pdf'
                                ? Icons.picture_as_pdf
                                : Icons.image,
                            size: 16),
                        label: Text(f.name,
                            style: const TextStyle(fontSize: 11),
                            overflow: TextOverflow.ellipsis),
                        visualDensity: VisualDensity.compact,
                      ),
                  ],
                ),
              if (m.text.isNotEmpty)
                Padding(
                  padding: EdgeInsets.only(top: m.files.isNotEmpty ? 8 : 0),
                  child: Text(m.text,
                      style: const TextStyle(color: Colors.white, height: 1.5)),
                ),
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: InkWell(
                  onTap: () => _msgMenu(idx),
                  child: const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Icon(Icons.more_horiz, size: 18, color: Colors.white70),
                  ),
                ),
              ),
            ],
          ),
        ),
        ),
      );
    }
    final res = m.res;
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxW),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: m.error ? const Color(0xFFFFF1F0) : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (m.text.isNotEmpty)
              SelectableText(m.text,
                  style: TextStyle(
                      height: 1.6,
                      color: m.error ? const Color(0xFFB42318) : null)),
            if (m.raw != null)
              TextButton.icon(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: m.raw!));
                  if (mounted) _msg('تم نسخ الرد الخام');
                },
                icon: const Icon(Icons.copy, size: 16),
                label: const Text('نسخ الرد الخام للفحص'),
              ),
            if (res != null && res.questions.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Text('أحتاج منك:',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              for (var i = 0; i < res.questions.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: SelectableText('${i + 1}. ${res.questions[i]}',
                      style: const TextStyle(height: 1.6)),
                ),
              const Text('أجب عنها في رسالتك التالية.',
                  style: TextStyle(fontSize: 12.5)),
            ],
            if (res?.doc != null) ...[
              const SizedBox(height: 10),
              Card(
                margin: EdgeInsets.zero,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          '${res!.doc!.title.isEmpty ? 'جدول الكميات' : res.doc!.title}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text(
                          '${res.doc!.sections.length} قسم • ${res.doc!.itemCount} بند'),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          FilledButton.tonalIcon(
                            onPressed: _openDoc,
                            icon: const Icon(Icons.edit_note),
                            label: const Text('فتح وتعديل'),
                          ),
                          OutlinedButton.icon(
                            onPressed: _busy
                                ? null
                                : () => _export(BoqAiExport.shareXlsx),
                            icon: const Icon(Icons.table_chart_outlined, size: 18),
                            label: const Text('Excel'),
                          ),
                          OutlinedButton.icon(
                            onPressed:
                                _busy ? null : () => _export(BoqAiExport.sharePdf),
                            icon: const Icon(Icons.picture_as_pdf_outlined, size: 18),
                            label: const Text('PDF'),
                          ),
                          OutlinedButton.icon(
                            onPressed:
                                _busy ? null : () => _export(BoqAiExport.shareDocx),
                            icon: const Icon(Icons.description_outlined, size: 18),
                            label: const Text('Word'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              if (res.doc!.notes.isNotEmpty) ...[
                const SizedBox(height: 8),
                for (final n in res.doc!.notes)
                  Text('• $n', style: const TextStyle(fontSize: 12.5, height: 1.5)),
              ],
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                children: [
                  ActionChip(
                    label: const Text('راجع واقترح بنوداً ناقصة',
                        style: TextStyle(fontSize: 12)),
                    onPressed: _busy
                        ? null
                        : () => _send(
                            'راجع الجدول كخبير واقترح البنود اللازمة الناقصة لنطاق العمل (علّمها كمقترحة)، واسألني عن أي رقم تحتاجه ولا تفترضه'),
                  ),
                  ActionChip(
                    label: const Text('أضف الأسعار', style: TextStyle(fontSize: 12)),
                    onPressed: () => setState(() => _ctl.text =
                        'أضف إلى البنود هذه الأسعار للوحدة: '),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _pendingBar() {
    final mb = (_usedBytes / (1024 * 1024)).toStringAsFixed(1);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              for (var i = 0; i < _pending.length; i++)
                InputChip(
                  avatar: Icon(
                      _pending[i].mime == 'application/pdf'
                          ? Icons.picture_as_pdf
                          : Icons.image,
                      size: 16),
                  label: Text(_pending[i].name,
                      style: const TextStyle(fontSize: 11),
                      overflow: TextOverflow.ellipsis),
                  onDeleted: () => setState(() => _pending.removeAt(i)),
                ),
            ],
          ),
          Text('الحجم الكلي المرسل: $mb ميجابايت (الحد 18)',
              style: const TextStyle(fontSize: 11)),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'إرفاق مخططات',
              icon: const Icon(Icons.attach_file),
              onPressed: _busy ? null : _attach,
            ),
            Expanded(
              child: TextField(
                controller: _ctl,
                minLines: 1,
                maxLines: 6,
                decoration: const InputDecoration(
                  hintText: 'اكتب طلبك أو تعديلك...',
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filled(
              onPressed: _busy ? null : () => _send(),
              style: IconButton.styleFrom(
                  backgroundColor: AppColors.ink,
                  minimumSize: const Size(48, 48)),
              icon: const Icon(Icons.send, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
