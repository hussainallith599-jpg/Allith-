import 'dart:convert';
import 'package:flutter/material.dart';
import 'boq_ai_models.dart';

/// تعديل بند واحد: الوصف والمواصفات والوحدة والسعر والحدود الحسابية.
class BoqAiItemPage extends StatefulWidget {
  final BoqAiItem item;
  const BoqAiItemPage({super.key, required this.item});
  @override
  State<BoqAiItemPage> createState() => _BoqAiItemPageState();
}

class _TermCtl {
  final label = TextEditingController();
  final n = TextEditingController();
  final l = TextEditingController();
  final w = TextEditingController();
  final h = TextEditingController();
  int sign = 1;

  _TermCtl(QTerm t) {
    label.text = t.label;
    n.text = t.n == null ? '' : fmtQ(t.n!, 3);
    l.text = t.l == null ? '' : fmtQ(t.l!, 3);
    w.text = t.w == null ? '' : fmtQ(t.w!, 3);
    h.text = t.h == null ? '' : fmtQ(t.h!, 3);
    sign = t.sign;
  }

  static double? _p(String s) {
    final t = _norm(s);
    if (t.isEmpty) return null;
    return double.tryParse(t);
  }

  static String _norm(String s) {
    const ar = '٠١٢٣٤٥٦٧٨٩';
    var t = s.trim();
    for (var i = 0; i < 10; i++) {
      t = t.replaceAll(ar[i], '$i');
    }
    return t.replaceAll('٫', '.').replaceAll(',', '.').replaceAll('،', '.');
  }

  QTerm toTerm() => QTerm(label.text.trim(), _p(n.text), _p(l.text),
      _p(w.text), _p(h.text), sign);

  void dispose() {
    label.dispose();
    n.dispose();
    l.dispose();
    w.dispose();
    h.dispose();
  }
}

class _BoqAiItemPageState extends State<BoqAiItemPage> {
  late final BoqAiItem it = BoqAiItem.fromJson(
      Map<String, dynamic>.from(jsonDecode(jsonEncode(widget.item.toJson())) as Map))
    ..no = widget.item.no;
  late final _desc = TextEditingController(text: it.description);
  late final _spec = TextEditingController(text: it.spec);
  late final _unit = TextEditingController(text: it.unit);
  late final _notes = TextEditingController(text: it.notes);
  late final _price =
      TextEditingController(text: it.price == 0 ? '' : fmtQ(it.price));
  late final _factor =
      TextEditingController(text: it.factor == 1 ? '' : fmtQ(it.factor, 3));
  late final _factorNote = TextEditingController(text: it.factorNote);
  late final _direct = TextEditingController(
      text: it.directQty == null ? '' : fmtQ(it.directQty!, 3));
  late final List<_TermCtl> _terms = it.terms.map((t) => _TermCtl(t)).toList();

  @override
  void dispose() {
    for (final c in [_desc, _spec, _unit, _notes, _price, _factor, _factorNote, _direct]) {
      c.dispose();
    }
    for (final t in _terms) {
      t.dispose();
    }
    super.dispose();
  }

  double? _num(String s) => _TermCtl._p(s);

  BoqAiItem _collect() {
    final r = BoqAiItem(
      no: widget.item.no,
      description: _desc.text.trim(),
      spec: _spec.text.trim(),
      unit: _unit.text.trim(),
      terms: _terms.map((t) => t.toTerm()).toList(),
      directQty: _num(_direct.text),
      factor: (_num(_factor.text) ?? 1) <= 0 ? 1 : (_num(_factor.text) ?? 1),
      factorNote: _factorNote.text.trim(),
      notes: _notes.text.trim(),
      price: _num(_price.text) ?? 0,
      suggested: it.suggested,
    );
    return r;
  }

  Widget _f(TextEditingController c, String label,
      {int lines = 1, bool number = false, String? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        minLines: lines,
        maxLines: lines == 1 ? 1 : 8,
        keyboardType: number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.multiline,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
            labelText: label, suffixText: suffix, alignLabelWithHint: true),
      ),
    );
  }

  Widget _tf(TextEditingController c, String label) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: TextField(
            controller: c,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
                labelText: label,
                isDense: true,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 10)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cur = _collect();
    return Scaffold(
      appBar: AppBar(title: const Text('تعديل بند')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _f(_desc, 'وصف البند', lines: 2),
          _f(_spec, 'المواصفات', lines: 3),
          Row(
            children: [
              Expanded(child: _f(_unit, 'الوحدة')),
              const SizedBox(width: 10),
              Expanded(child: _f(_price, 'سعر الوحدة', number: true)),
            ],
          ),
          _f(_notes, 'ملاحظات', lines: 2),
          if (it.suggested)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('بند مقترح من الخبير — لم أعتمده بعد'),
              subtitle: const Text('أطفئه بعد مراجعتك لاعتماد البند'),
              value: it.suggested,
              onChanged: (v) => setState(() => it.suggested = v),
            ),
          const Divider(height: 28),
          Row(
            children: [
              Expanded(
                child: Text('حدود الحساب (عدد × طول × عرض × ارتفاع)',
                    style: Theme.of(context)
                        .textTheme
                        .titleSmall
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              TextButton.icon(
                onPressed: () => setState(
                    () => _terms.add(_TermCtl(QTerm('', null, null, null, null, 1)))),
                icon: const Icon(Icons.add),
                label: const Text('حد'),
              ),
            ],
          ),
          const Text('اترك الخانة فارغة إن لم تنطبق. استخدم "خصم" للفتحات.',
              style: TextStyle(fontSize: 12.5)),
          const SizedBox(height: 8),
          for (var i = 0; i < _terms.length; i++)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _terms[i].label,
                            decoration: const InputDecoration(
                                labelText: 'وصف الحد', isDense: true),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => setState(() {
                            _terms[i].dispose();
                            _terms.removeAt(i);
                          }),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(children: [
                      _tf(_terms[i].n, 'عدد'),
                      _tf(_terms[i].l, 'طول'),
                      _tf(_terms[i].w, 'عرض'),
                      _tf(_terms[i].h, 'ارتفاع'),
                    ]),
                    SwitchListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: const Text('خصم (يُطرح من الكمية)'),
                      value: _terms[i].sign < 0,
                      onChanged: (v) =>
                          setState(() => _terms[i].sign = v ? -1 : 1),
                    ),
                  ],
                ),
              ),
            ),
          if (_terms.isEmpty) _f(_direct, 'الكمية (مباشرة)', number: true),
          if (_terms.isNotEmpty) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(child: _f(_factor, 'معامل ضرب (اختياري)', number: true)),
                const SizedBox(width: 10),
                Expanded(child: _f(_factorNote, 'سبب المعامل')),
              ],
            ),
          ],
          Card(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الكمية: ${fmtQ(cur.qty)} ${cur.unit}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  if (cur.calcText.isNotEmpty) Text('الحساب: ${cur.calcText}'),
                  if (cur.price > 0) Text('الإجمالي: ${fmtQ(cur.total)}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () => Navigator.pop(context, _collect()),
            child: const Text('حفظ البند'),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
