import 'package:flutter/material.dart';
import 'boq_editor.dart';
import 'boq_models.dart';

class BoqHome extends StatefulWidget {
  final bool embedded;
  const BoqHome({super.key, this.embedded = false});
  @override
  State<BoqHome> createState() => _BoqHomeState();
}

class _BoqHomeState extends State<BoqHome> {
  List<BoqProject> _list = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final l = await BoqStore.load();
    if (!mounted) return;
    setState(() {
      _list = l;
      _loading = false;
    });
  }

  Future<void> _open(BoqProject p) async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => BoqEditor(project: p)));
    _reload();
  }

  Future<void> _create() async {
    final p = BoqProject.create();
    await BoqStore.save(p);
    if (!mounted) return;
    await _open(p);
  }

  Future<void> _delete(BoqProject p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('حذف المشروع'),
        content: const Text('سيتم حذف جدول الكميات هذا نهائياً. هل أنت متأكد؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await BoqStore.delete(p.id);
      _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.embedded
          ? null
          : AppBar(title: const Text('حاسبة الكميات BOQ')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add),
        label: const Text('مشروع جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _list.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'لا توجد مشاريع بعد.\nاضغط "مشروع جديد" لحساب كميات الخرسانة والحديد والبلوك واللياسة والدهانات.',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.7),
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                  itemCount: _list.length,
                  itemBuilder: (context, i) {
                    final p = _list[i];
                    final t = p.totals();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          leading: const Icon(Icons.calculate_outlined, size: 30),
                          title: Text(p.name.isEmpty ? 'مشروع بدون اسم' : p.name,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              '${p.items.length} عنصر • خرسانة ${fmt(t.concrete)} م³ • حديد ${fmt(t.rebarKg, 0)} كجم'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => _delete(p),
                          ),
                          onTap: () => _open(p),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
