import 'package:flutter/material.dart';
import 'boq_ai_doc_screen.dart';
import 'boq_ai_models.dart';
import 'boq_ai_screen.dart';

/// الجداول المحفوظة التي أنشأها المساعد الذكي.
class BoqAiList extends StatefulWidget {
  const BoqAiList({super.key});
  @override
  State<BoqAiList> createState() => _BoqAiListState();
}

class _BoqAiListState extends State<BoqAiList> {
  List<BoqAiDoc> _list = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final l = await BoqAiStore.load();
    if (!mounted) return;
    setState(() {
      _list = l;
      _loading = false;
    });
  }

  Future<void> _new() async {
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => const BoqAiScreen()));
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _new,
        icon: const Icon(Icons.auto_awesome),
        label: const Text('جدول جديد بالذكاء الاصطناعي'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _list.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'لا توجد جداول بعد.\nاضغط الزر لترفع المخططات وتطلب حساب الكميات.',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.7),
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                  itemCount: _list.length,
                  itemBuilder: (context, i) {
                    final d = _list[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          leading: const Icon(Icons.table_chart_outlined, size: 30),
                          title: Text(d.title.isEmpty ? 'جدول كميات' : d.title,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              '${d.sections.length} قسم • ${d.itemCount} بند${d.country.isEmpty ? '' : ' • ${d.country}'}'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              final ok = await showDialog<bool>(
                                context: context,
                                builder: (c) => AlertDialog(
                                  title: const Text('حذف الجدول'),
                                  content: const Text('سيُحذف هذا الجدول نهائياً.'),
                                  actions: [
                                    TextButton(
                                        onPressed: () => Navigator.pop(c, false),
                                        child: const Text('إلغاء')),
                                    TextButton(
                                        onPressed: () => Navigator.pop(c, true),
                                        child: const Text('حذف')),
                                  ],
                                ),
                              );
                              if (ok == true) {
                                await BoqAiStore.delete(d.id);
                                _reload();
                              }
                            },
                          ),
                          onTap: () async {
                            await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => BoqAiDocScreen(doc: d)));
                            _reload();
                          },
                          onLongPress: () async {
                            await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => BoqAiScreen(existing: d)));
                            _reload();
                          },
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
