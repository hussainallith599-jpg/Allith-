import 'package:flutter/material.dart';
import 'boq_ai_export.dart';
import 'boq_ai_item_page.dart';
import 'boq_ai_models.dart';

/// عرض جدول الكميات وتعديله يدوياً (بنود، أقسام، أسعار، نسب، ملاحظات) وتصديره.
class BoqAiDocScreen extends StatefulWidget {
  final BoqAiDoc doc;
  const BoqAiDocScreen({super.key, required this.doc});
  @override
  State<BoqAiDocScreen> createState() => _BoqAiDocScreenState();
}

class _BoqAiDocScreenState extends State<BoqAiDocScreen> {
  late final BoqAiDoc d = widget.doc;
  late final _title = TextEditingController(text: d.title);
  late final _country = TextEditingController(text: d.country);
  late final _location = TextEditingController(text: d.location);
  late final _client = TextEditingController(text: d.client);
  late final _currency = TextEditingController(text: d.currency);
  late final _cont = TextEditingController(text: d.contingency == 0 ? '' : fmtQ(d.contingency));
  late final _vat = TextEditingController(text: d.vat == 0 ? '' : fmtQ(d.vat));
  late final _notes = TextEditingController(text: d.notes.join('\n'));
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_title, _country, _location, _client, _currency, _cont, _vat, _notes]) {
      c.dispose();
    }
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  double _n(String s) {
    const ar = '٠١٢٣٤٥٦٧٨٩';
    var t = s.trim();
    for (var i = 0; i < 10; i++) {
      t = t.replaceAll(ar[i], '$i');
    }
    t = t.replaceAll('٫', '.').replaceAll(',', '.');
    return double.tryParse(t) ?? 0;
  }

  Future<void> _save() async {
    d.title = _title.text.trim();
    d.country = _country.text.trim();
    d.location = _location.text.trim();
    d.client = _client.text.trim();
    d.currency = _currency.text.trim();
    d.contingency = _n(_cont.text).clamp(0, 100).toDouble();
    d.vat = _n(_vat.text).clamp(0, 100).toDouble();
    d.notes = _notes.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    d.renumber();
    await BoqAiStore.save(d);
  }

  Future<void> _editItem(BoqAiSection s, int i) async {
    final res = await Navigator.push<BoqAiItem>(
        context, MaterialPageRoute(builder: (_) => BoqAiItemPage(item: s.items[i])));
    if (res != null) {
      setState(() => s.items[i] = res);
      await _save();
    }
  }

  Future<void> _addItem(BoqAiSection s) async {
    final blank = BoqAiItem(unit: 'م³');
    final res = await Navigator.push<BoqAiItem>(
        context, MaterialPageRoute(builder: (_) => BoqAiItemPage(item: blank)));
    if (res != null) {
      setState(() => s.items.add(res));
      await _save();
    }
  }

  Future<String?> _askText(String title, String initial) async {
    final c = TextEditingController(text: initial);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    final t = c.text.trim();
    c.dispose();
    return (ok == true && t.isNotEmpty) ? t : null;
  }

  Future<bool> _confirm(String title, String body) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _export(Future<void> Function(BoqAiDoc) fn, String err) async {
    await _save();
    setState(() => _busy = true);
    try {
      await fn(d);
    } catch (e) {
      if (mounted) _msg(err);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _tf(TextEditingController c, String label,
      {bool number = false, String? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        keyboardType: number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        onChanged: (_) {
          _save();
          setState(() {});
        },
        decoration: InputDecoration(labelText: label, suffixText: suffix),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasPrices = d.sections.any((s) => s.items.any((e) => e.price > 0));
    return Scaffold(
      appBar: AppBar(title: const Text('جدول الكميات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tf(_title, 'عنوان الجدول'),
          Row(children: [
            Expanded(child: _tf(_country, 'الدولة / المرجع')),
            const SizedBox(width: 10),
            Expanded(child: _tf(_location, 'الموقع')),
          ]),
          Row(children: [
            Expanded(child: _tf(_client, 'الجهة / المالك')),
            const SizedBox(width: 10),
            Expanded(child: _tf(_currency, 'العملة')),
          ]),
          Row(children: [
            Expanded(child: _tf(_cont, 'احتياطي/إدارة وأرباح', number: true, suffix: '%')),
            const SizedBox(width: 10),
            Expanded(child: _tf(_vat, 'الضريبة', number: true, suffix: '%')),
          ]),
          const SizedBox(height: 6),
          for (var si = 0; si < d.sections.length; si++) ...[
            Row(
              children: [
                Expanded(
                  child: Text(d.sections[si].title.isEmpty ? 'قسم' : d.sections[si].title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800)),
                ),
                IconButton(
                  tooltip: 'إعادة تسمية',
                  icon: const Icon(Icons.edit_outlined, size: 20),
                  onPressed: () async {
                    final t = await _askText('اسم القسم', d.sections[si].title);
                    if (t != null) {
                      setState(() => d.sections[si].title = t);
                      await _save();
                    }
                  },
                ),
                IconButton(
                  tooltip: 'حذف القسم',
                  icon: const Icon(Icons.delete_outline, size: 20),
                  onPressed: () async {
                    if (await _confirm('حذف القسم', 'سيُحذف القسم وكل بنوده. هل أنت متأكد؟')) {
                      setState(() => d.sections.removeAt(si));
                      await _save();
                    }
                  },
                ),
              ],
            ),
            for (var i = 0; i < d.sections[si].items.length; i++)
              Builder(builder: (context) {
                final it = d.sections[si].items[i];
                return Card(
                  child: ListTile(
                    title: Text('${it.no}  ${it.description}',
                        style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4)),
                    subtitle: Text(
                      '${it.spec.isEmpty ? '' : '${it.spec}\n'}الكمية: ${fmtQ(it.qty)} ${it.unit}'
                      '${it.price > 0 ? ' • الإجمالي ${fmtQ(it.total)}' : ''}'
                      '${it.suggested ? '\n⚠ مقترح من الخبير — راجعه' : ''}',
                      style: const TextStyle(height: 1.5),
                    ),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        if (await _confirm('حذف البند', 'هل تريد حذف هذا البند؟')) {
                          setState(() => d.sections[si].items.removeAt(i));
                          await _save();
                        }
                      },
                    ),
                    onTap: () => _editItem(d.sections[si], i),
                  ),
                );
              }),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton.icon(
                onPressed: () => _addItem(d.sections[si]),
                icon: const Icon(Icons.add),
                label: const Text('إضافة بند'),
              ),
            ),
            if (hasPrices)
              Text('إجمالي القسم: ${fmtQ(d.sections[si].total)} ${d.currency}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
          ],
          OutlinedButton.icon(
            onPressed: () async {
              final t = await _askText('اسم القسم الجديد', '');
              if (t != null) {
                setState(() => d.sections.add(BoqAiSection(t)));
                await _save();
              }
            },
            icon: const Icon(Icons.create_new_folder_outlined),
            label: const Text('إضافة قسم'),
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
          ),
          if (hasPrices) ...[
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('المجموع الفرعي: ${fmtQ(d.subtotal)} ${d.currency}'),
                    if (d.contingency > 0)
                      Text('احتياطي/إدارة وأرباح ${fmtQ(d.contingency)}%: ${fmtQ(d.contingencyAmount)}'),
                    if (d.vat > 0) Text('الضريبة ${fmtQ(d.vat)}%: ${fmtQ(d.vatAmount)}'),
                    const SizedBox(height: 4),
                    Text('الإجمالي النهائي: ${fmtQ(d.grand)} ${d.currency}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 14),
          TextField(
            controller: _notes,
            minLines: 3,
            maxLines: 8,
            onChanged: (_) => _save(),
            decoration: const InputDecoration(
                labelText: 'ملاحظات واستثناءات (سطر لكل ملاحظة)',
                alignLabelWithHint: true),
          ),
          const SizedBox(height: 18),
          if (_busy)
            const Center(child: CircularProgressIndicator())
          else
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                FilledButton.icon(
                  onPressed: () => _export(BoqAiExport.shareXlsx, 'تعذّر إنشاء ملف Excel.'),
                  icon: const Icon(Icons.table_chart_outlined),
                  label: const Text('Excel'),
                ),
                FilledButton.icon(
                  onPressed: () => _export(BoqAiExport.sharePdf,
                      'تعذّر إنشاء PDF. تأكد من الإنترنت (لتحميل الخط) وأعد المحاولة.'),
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('PDF'),
                ),
                FilledButton.icon(
                  onPressed: () => _export(BoqAiExport.shareDocx, 'تعذّر إنشاء ملف Word.'),
                  icon: const Icon(Icons.description_outlined),
                  label: const Text('Word'),
                ),
              ],
            ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
