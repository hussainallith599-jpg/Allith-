import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// وصول آمن لمجلدات التطبيق: يجرّب عدة طرق ولا ينهار إذا فشلت إحداها.
class AppStorage {
  AppStorage._();

  /// مجلد دائم داخل بيانات التطبيق، أو null إن تعذّر كل شيء.
  static Future<Directory?> dir(String sub) async {
    final candidates = <Future<String?> Function()>[
      () async => (await getApplicationDocumentsDirectory()).path,
      () async => p.join(Directory.systemTemp.parent.path, 'files'),
      () async => Directory.systemTemp.path,
    ];
    for (final c in candidates) {
      try {
        final base = await c();
        if (base == null) continue;
        final d = Directory(p.join(base, sub));
        if (!d.existsSync()) d.createSync(recursive: true);
        final t = File(p.join(d.path, '.w'));
        t.writeAsStringSync('1');
        t.deleteSync();
        return d;
      } catch (_) {}
    }
    return null;
  }

  static Future<Directory> temp() async {
    try {
      return await getTemporaryDirectory();
    } catch (_) {
      return Directory.systemTemp;
    }
  }
}
