import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:share_plus/share_plus.dart';
import '../../features/site_supervision/app_storage.dart';

class DocxPic {
  final String rid;
  final String fileName;
  final Uint8List bytes;
  final int w;
  final int h;
  DocxPic(this.rid, this.fileName, this.bytes, this.w, this.h);
}

/// أدوات بناء ملف Word (.docx) عربي RTL بدون مكتبات خارجية.
class DocxKit {
  DocxKit._();

  static String esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static String run(String text,
      {bool bold = false, int size = 22, String? color}) {
    return '<w:r><w:rPr>'
        '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'
        '${bold ? '<w:b/><w:bCs/>' : ''}'
        '${color != null ? '<w:color w:val="$color"/>' : ''}'
        '<w:sz w:val="$size"/><w:szCs w:val="$size"/><w:rtl/>'
        '</w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r>';
  }

  static String para(String inner, {String? jc, int after = 80}) {
    return '<w:p><w:pPr><w:bidi/><w:spacing w:after="$after"/>'
        '${jc != null ? '<w:jc w:val="$jc"/>' : ''}</w:pPr>$inner</w:p>';
  }

  static String text(String text,
          {bool bold = false,
          int size = 22,
          String? color,
          String? jc,
          int after = 80}) =>
      para(run(text, bold: bold, size: size, color: color),
          jc: jc, after: after);

  static String cell(String inner, int w, {String? fill}) {
    return '<w:tc><w:tcPr><w:tcW w:w="$w" w:type="dxa"/>'
        '${fill != null ? '<w:shd w:val="clear" w:color="auto" w:fill="$fill"/>' : ''}'
        '</w:tcPr>$inner</w:tc>';
  }

  static String row(List<String> cells) => '<w:tr>${cells.join()}</w:tr>';

  static String table(List<int> widths, List<String> rows) {
    String border(String n) =>
        '<w:$n w:val="single" w:sz="4" w:space="0" w:color="9E9E9E"/>';
    final total = widths.fold<int>(0, (a, x) => a + x);
    return '<w:tbl><w:tblPr><w:bidiVisual/>'
        '<w:tblW w:w="$total" w:type="dxa"/>'
        '<w:tblBorders>${border('top')}${border('left')}${border('bottom')}${border('right')}${border('insideH')}${border('insideV')}</w:tblBorders>'
        '<w:tblLayout w:type="fixed"/>'
        '<w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="80" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar>'
        '</w:tblPr><w:tblGrid>${widths.map((w) => '<w:gridCol w:w="$w"/>').join()}</w:tblGrid>'
        '${rows.join()}</w:tbl>';
  }

  static String image(DocxPic pic, int id, double maxCm, {bool center = false}) {
    final maxEmu = (maxCm * 360000).round();
    final ratio = pic.h / pic.w;
    var cx = maxEmu;
    var cy = (maxEmu * ratio).round();
    const maxH = 3600000;
    if (cy > maxH) {
      cy = maxH;
      cx = (maxH / ratio).round();
    }
    return '<w:p><w:pPr><w:bidi/>${center ? '<w:jc w:val="center"/>' : ''}</w:pPr><w:r><w:drawing>'
        '<wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="$cx" cy="$cy"/>'
        '<wp:docPr id="$id" name="Picture $id"/>'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="$id" name="${pic.fileName}"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="${pic.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
        '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
  }

  static Future<DocxPic?> makePic(Uint8List bytes, String ext, int index) async {
    try {
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final w = frame.image.width;
      final h = frame.image.height;
      frame.image.dispose();
      return DocxPic('rId${index + 10}', 'image$index.$ext', bytes, w, h);
    } catch (_) {
      return null;
    }
  }

  /// يبني الحزمة الكاملة ويعيد بايتات ملف docx.
  static List<int> build(String body, List<DocxPic> pics) {
    final documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
        '<w:body>$body'
        '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000" w:header="708" w:footer="708" w:gutter="0"/>'
        '<w:bidi/></w:sectPr></w:body></w:document>';
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Default Extension="png" ContentType="image/png"/>'
        '<Default Extension="jpg" ContentType="image/jpeg"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>';
    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '</Relationships>';
    final rels = StringBuffer(
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">');
    for (final p in pics) {
      rels.write(
          '<Relationship Id="${p.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${p.fileName}"/>');
    }
    rels.write('</Relationships>');

    final archive = Archive();
    void add(String name, List<int> data) =>
        archive.addFile(ArchiveFile(name, data.length, data));
    add('[Content_Types].xml', utf8.encode(contentTypes));
    add('_rels/.rels', utf8.encode(rootRels));
    add('word/document.xml', utf8.encode(documentXml));
    add('word/_rels/document.xml.rels', utf8.encode(rels.toString()));
    for (final p in pics) {
      add('word/media/${p.fileName}', p.bytes);
    }
    final zipped = ZipEncoder().encode(archive);
    if (zipped == null) throw Exception('zip failed');
    return zipped;
  }

  static Future<void> shareBytes(List<int> bytes, String name) async {
    final dir = await AppStorage.temp();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([
      XFile(file.path,
          mimeType:
              'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    ]);
  }
}
