import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';

/// استخراج النص من المستندات المرفقة (Word docx وملفات النص).
class FileText {
  FileText._();

  static String? docxToText(Uint8List bytes) {
    try {
      final arc = ZipDecoder().decodeBytes(bytes);
      final f = arc.findFile('word/document.xml');
      if (f == null) return null;
      var xml = utf8.decode(f.content as List<int>, allowMalformed: true);
      xml = xml
          .replaceAll('</w:p>', '\n')
          .replaceAll('<w:tab/>', '\t')
          .replaceAll('<w:br/>', '\n')
          .replaceAll(RegExp(r'<[^>]+>'), '')
          .replaceAll('&amp;', '&')
          .replaceAll('&lt;', '<')
          .replaceAll('&gt;', '>')
          .replaceAll('&quot;', '"')
          .replaceAll('&apos;', "'");
      final t = xml.replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
      return t.isEmpty ? null : t;
    } catch (_) {
      return null;
    }
  }

  static String plain(Uint8List bytes) =>
      utf8.decode(bytes, allowMalformed: true).trim();
}
