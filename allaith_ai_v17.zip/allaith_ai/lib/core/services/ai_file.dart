import 'dart:convert';
import 'dart:typed_data';

/// ملف مرفق (صورة أو PDF أو نص مستخرج من Word/TXT) يُرسل للنموذج.
class AiFile {
  final String name;
  final String mime; // image/jpeg, image/png, application/pdf, text/plain
  final Uint8List bytes;
  AiFile(this.name, this.mime, this.bytes);

  bool get isText => mime == 'text/plain';
  bool get isPdf => mime == 'application/pdf';

  /// النص المستخرج (للملفات النصية فقط)، مقصوص لحجم معقول.
  String get textContent {
    final t = utf8.decode(bytes, allowMalformed: true);
    return t.length > 60000 ? '${t.substring(0, 60000)}\n...(قُصّ النص لطوله)' : t;
  }
}
