import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:share_plus/share_plus.dart';
import '../../features/site_supervision/app_storage.dart';

/// خلية في ورقة Excel.
class XCell {
  final String col; // A, B, ...
  final String? text;
  final double? number;
  final String? formula;
  final double? cached; // قيمة مخزّنة للصيغة
  final bool formulaIsText;
  final int style;
  XCell.text(this.col, this.text, {this.style = 0})
      : number = null,
        formula = null,
        cached = null,
        formulaIsText = false;
  XCell.num(this.col, this.number, {this.style = 0})
      : text = null,
        formula = null,
        cached = null,
        formulaIsText = false;
  XCell.formula(this.col, this.formula, this.cached, {this.style = 0})
      : text = null,
        number = null,
        formulaIsText = false;
  XCell.formulaText(this.col, this.formula, {this.style = 0})
      : text = null,
        number = null,
        cached = null,
        formulaIsText = true;
  XCell.empty(this.col, {this.style = 0})
      : text = null,
        number = null,
        formula = null,
        cached = null,
        formulaIsText = false;
}

/// أنماط الخلايا الجاهزة (فهارس cellXfs).
class XStyle {
  static const normal = 0;
  static const bold = 1;
  static const header = 2;
  static const cell = 3;
  static const number = 4;
  static const boldNumber = 5;
  static const section = 6;
  static const wrap = 7;
}

/// كاتب ملف xlsx بسيط (ورقة واحدة، RTL) بدون مكتبات خارجية سوى الضغط.
class XlsxKit {
  XlsxKit._();

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static String _fnum(double v) {
    if (v.isNaN || v.isInfinite) return '0';
    return v.toString();
  }

  static String _cellXml(XCell c, int row) {
    final ref = '${c.col}$row';
    if (c.text != null) {
      return '<c r="$ref" s="${c.style}" t="inlineStr"><is><t xml:space="preserve">${_esc(c.text!)}</t></is></c>';
    }
    if (c.number != null) {
      return '<c r="$ref" s="${c.style}"><v>${_fnum(c.number!)}</v></c>';
    }
    if (c.formula != null) {
      if (c.formulaIsText) {
        return '<c r="$ref" s="${c.style}" t="str"><f>${_esc(c.formula!)}</f><v></v></c>';
      }
      return '<c r="$ref" s="${c.style}"><f>${_esc(c.formula!)}</f><v>${_fnum(c.cached ?? 0)}</v></c>';
    }
    return '<c r="$ref" s="${c.style}"/>';
  }

  /// يبني ملف xlsx. [rows] قائمة صفوف، كل صف قائمة خلايا. [widths] عرض الأعمدة بالترتيب.
  static List<int> build({
    required String sheetName,
    required List<List<XCell>> rows,
    required List<double> widths,
    List<String> merges = const [],
  }) {
    final sheet = StringBuffer(
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>'
        '<sheetFormatPr defaultRowHeight="15"/>'
        '<cols>');
    for (var i = 0; i < widths.length; i++) {
      sheet.write(
          '<col min="${i + 1}" max="${i + 1}" width="${widths[i]}" customWidth="1"/>');
    }
    sheet.write('</cols><sheetData>');
    for (var r = 0; r < rows.length; r++) {
      sheet.write('<row r="${r + 1}">');
      for (final c in rows[r]) {
        sheet.write(_cellXml(c, r + 1));
      }
      sheet.write('</row>');
    }
    sheet.write('</sheetData>');
    if (merges.isNotEmpty) {
      sheet.write('<mergeCells count="${merges.length}">');
      for (final m in merges) {
        sheet.write('<mergeCell ref="$m"/>');
      }
      sheet.write('</mergeCells>');
    }
    sheet.write(
        '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
        '<pageSetup orientation="landscape" fitToHeight="0"/></worksheet>');

    const styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="2">'
        '<font><sz val="11"/><name val="Arial"/></font>'
        '<font><b/><sz val="11"/><name val="Arial"/></font>'
        '</fonts>'
        '<fills count="4">'
        '<fill><patternFill patternType="none"/></fill>'
        '<fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFD9D9D9"/><bgColor indexed="64"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF1FB"/><bgColor indexed="64"/></patternFill></fill>'
        '</fills>'
        '<borders count="2">'
        '<border><left/><right/><top/><bottom/><diagonal/></border>'
        '<border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border>'
        '</borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="8">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        '<xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>'
        '<xf numFmtId="2" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>'
        '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        '</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '</styleSheet>';

    final workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets><sheet name="${_esc(sheetName)}" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        '</Relationships>';
    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>';
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        '</Types>';

    final archive = Archive();
    void add(String name, String data) {
      final b = utf8.encode(data);
      archive.addFile(ArchiveFile(name, b.length, b));
    }

    add('[Content_Types].xml', contentTypes);
    add('_rels/.rels', rootRels);
    add('xl/workbook.xml', workbook);
    add('xl/_rels/workbook.xml.rels', wbRels);
    add('xl/styles.xml', styles);
    add('xl/worksheets/sheet1.xml', sheet.toString());
    final zipped = ZipEncoder().encode(archive);
    if (zipped == null) throw Exception('zip failed');
    return zipped;
  }

  static Future<void> share(List<int> bytes, String name) async {
    final dir = await AppStorage.temp();
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([
      XFile(file.path,
          mimeType:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    ]);
  }
}
