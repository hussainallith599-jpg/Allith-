import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../../features/chat/chat_message.dart';
import 'settings_service.dart';

class AiException implements Exception {
  final String message;
  AiException(this.message);
  @override
  String toString() => message;
}

/// ملف مرفق (صورة أو PDF) يُرسل للنموذج.
class AiFile {
  final String name;
  final String mime; // image/jpeg, image/png, application/pdf
  final Uint8List bytes;
  AiFile(this.name, this.mime, this.bytes);
}

/// دور واحد في محادثة تحتوي ملفات.
class AiTurn {
  final String role; // user أو assistant
  final String text;
  final List<AiFile> files;
  AiTurn(this.role, this.text, [this.files = const []]);
}

class AiTextService {
  AiTextService._();

  static const String systemPrompt = '''
أنت "الليث AI"، مستشار هندسي خبير متخصص حصرياً في الهندسة المعمارية والهندسة المدنية في العالم العربي وخارجه.

نطاق خبرتك:
- التصميم المعماري والإنشائي، التربة والأساسات، الخرسانة المسلحة والمعدنية، العزل والتشطيبات، الإشراف وإدارة المواقع، حساب الكميات.
- الأكواد والمواصفات: الكود السعودي SBC (خاصة 201 و301 و304 و601 وما يتعلق بالحريق والكهرباء والميكانيكا)، الأكواد الأمريكية (ACI 318 وASCE 7 وIBC وAISC وNFPA وASHRAE)، الأوروبية Eurocode، البريطانية BS، الكود المصري، الكود الأردني، كود دول الخليج، والممارسات المحلية في اليمن وغيرها.
- الهوية العمرانية السعودية: الطرز الإقليمية (النجدي، الحجازي، الجنوبي/العسيري، الأحسائي والشرقي)، وتوجهات رؤية 2030 وخريطة العمارة السعودية، وملامح الواجهات المعاصرة المستلهمة منها (الإيقاع، المشربيات، الفتحات الصغيرة، الطين والحجر، الظل والفناء الداخلي).
- العمارة اليمنية التقليدية (صنعاء، حضرموت، شبام، زبيد) وأساليبها ومواد بنائها.

قواعد الإجابة:
1. أجب بالعربية الفصحى المبسطة بأسلوب مهني منظم، وابدأ بالجواب ثم التفصيل.
2. عند أي حساب اذكر المعادلة والافتراضات والوحدات المترية، وتحقق من الأرقام.
3. حدّد الكود المعتمد قبل الإجابة. إن لم يذكر المستخدم البلد أو الكود فاسأله أو اذكر افتراضك صراحة. ولا تخلط بين اشتراطات كودين.
4. اذكر اسم الكود والبند عندما تكون متأكداً منه. وإن لم تكن متأكداً من رقم بند أو قيمة فقل ذلك صراحة ولا تخترع رقماً.
5. استخدم البحث في الويب عندما يتعلق السؤال بإصدار حديث من كود، أو اشتراطات بلدية أو أنظمة حديثة، أو أسعار، أو أي معلومة قد تكون تغيرت. وانسب المعلومة لمصدرها.
6. في المسائل الإنشائية والسلامة نبّه إلى وجوب اعتماد مهندس مرخّص ومراجعة الرسومات قبل التنفيذ.
7. لا تبدأ بتحية ولا تعرّف بنفسك، ادخل في الجواب مباشرة.
8. عند ذكر قيم مثل غطاء الخرسانة أو أطوال التراكب فرّق بين حالات التعرض وأقطار حديد التسليح، واذكر أن الأرقام مرجعية وتُراجع مع الكود المعتمد في المشروع.
9. إذا كان السؤال خارج الهندسة المعمارية والمدنية، فاعتذر بلطف ووجّه المستخدم لسؤال هندسي.
''';

  static List<ChatMessage> _recent(List<ChatMessage> history) {
    var recent = history.length > 20
        ? history.sublist(history.length - 20)
        : List<ChatMessage>.from(history);
    while (recent.isNotEmpty && recent.first.role != 'user') {
      recent.removeAt(0);
    }
    if (recent.isEmpty) throw AiException('لا توجد رسالة لإرسالها.');
    return recent;
  }

  static Future<String> chat(List<ChatMessage> history) {
    final recent = _recent(history);
    if (SettingsService.instance.provider == 'gemini') {
      return _chatGemini(recent);
    }
    return _chatClaude(recent);
  }

  /// سؤال واحد بتعليمات نظام مخصصة (بدون بحث ويب)، يُستخدم لتحويل الطلبات إلى إعدادات.
  static Future<String> askOnce(String system, String user) {
    final msgs = [ChatMessage(role: 'user', text: user)];
    if (SettingsService.instance.provider == 'gemini') {
      return _chatGemini(msgs, system: system, search: false, json: true);
    }
    return _chatClaude(msgs, system: system, search: false);
  }

  /// سؤال مع صورة (مخطط) وتعليمات نظام مخصصة. تُعاد النتيجة نصاً (JSON غالباً).
  static Future<String> askWithImage(
      String system, String user, Uint8List bytes, String mime) async {
    final b64 = base64Encode(bytes);
    if (SettingsService.instance.provider == 'gemini') {
      final key = SettingsService.instance.geminiKey;
      if (key.isEmpty) {
        throw AiException('لم يتم إدخال مفتاح Gemini. افتح الإعدادات وأدخله.');
      }
      final body = jsonEncode({
        'system_instruction': {
          'parts': [
            {'text': system}
          ]
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {
                'inline_data': {'mime_type': mime, 'data': b64}
              },
              {'text': user},
            ]
          }
        ],
        'generationConfig': {
          'maxOutputTokens': 6000,
          'responseMimeType': 'application/json',
        },
      });
      final res = await _post(
        Uri.parse(
            '${ApiConfig.geminiBase}/${SettingsService.instance.geminiModel}:generateContent'),
        {'content-type': 'application/json', 'x-goog-api-key': key},
        body,
      );
      final data = _decode(res);
      if (res.statusCode != 200) {
        String detail = '';
        try {
          detail = data['error']['message']?.toString() ?? '';
        } catch (_) {}
        throw AiException('خطأ من Google (${res.statusCode}).\n$detail');
      }
      try {
        final parts = data['candidates'][0]['content']['parts'] as List;
        final text = parts
            .where((p) => p is Map && p['text'] != null)
            .map((p) => p['text'] as String)
            .join('')
            .trim();
        if (text.isNotEmpty) return text;
      } catch (_) {}
      throw AiException('وصل رد فارغ من النموذج.');
    }

    final key = SettingsService.instance.textKey;
    if (key.isEmpty) {
      throw AiException('لم يتم إدخال مفتاح Claude. افتح الإعدادات وأدخله.');
    }
    final body = jsonEncode({
      'model': ApiConfig.textModel,
      'max_tokens': 6000,
      'system': system,
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'image',
              'source': {'type': 'base64', 'media_type': mime, 'data': b64}
            },
            {'type': 'text', 'text': user},
          ]
        }
      ],
    });
    final res = await _post(
      Uri.parse(ApiConfig.textApiUrl),
      {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': ApiConfig.anthropicVersion,
      },
      body,
    );
    final data = _decode(res);
    if (res.statusCode != 200) {
      String detail = '';
      try {
        detail = data['error']['message']?.toString() ?? '';
      } catch (_) {}
      throw AiException('خطأ من الخادم (${res.statusCode}). $detail');
    }
    final blocks = (data['content'] as List?) ?? [];
    final text = blocks
        .where((b) => b is Map && b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('')
        .trim();
    if (text.isEmpty) throw AiException('وصل رد فارغ من النموذج.');
    return text;
  }

  /// محادثة متعددة الأدوار مع ملفات (صور/PDF)، بتعليمات نظام مخصصة، والرد JSON.
  static Future<String> chatFiles(String system, List<AiTurn> turns,
      {int maxTokens = 16000}) async {
    const to = Duration(seconds: 240);
    if (SettingsService.instance.provider == 'gemini') {
      final key = SettingsService.instance.geminiKey;
      if (key.isEmpty) {
        throw AiException('لم يتم إدخال مفتاح Gemini. افتح الإعدادات وأدخله.');
      }
      final body = jsonEncode({
        'system_instruction': {
          'parts': [
            {'text': system}
          ]
        },
        'contents': [
          for (final t in turns)
            {
              'role': t.role == 'user' ? 'user' : 'model',
              'parts': [
                for (final f in t.files)
                  {
                    'inline_data': {
                      'mime_type': f.mime,
                      'data': base64Encode(f.bytes)
                    }
                  },
                {'text': t.text.isEmpty ? '(بدون نص)' : t.text},
              ]
            }
        ],
        'generationConfig': {
          'maxOutputTokens': maxTokens,
          'responseMimeType': 'application/json',
        },
      });
      final res = await _post(
        Uri.parse(
            '${ApiConfig.geminiBase}/${SettingsService.instance.geminiModel}:generateContent'),
        {'content-type': 'application/json', 'x-goog-api-key': key},
        body,
        timeout: to,
      );
      final data = _decode(res);
      if (res.statusCode != 200) {
        String detail = '';
        try {
          detail = data['error']['message']?.toString() ?? '';
        } catch (_) {}
        throw AiException('خطأ من Google (${res.statusCode}).\n$detail');
      }
      try {
        final parts = data['candidates'][0]['content']['parts'] as List;
        final text = parts
            .where((p) => p is Map && p['text'] != null)
            .map((p) => p['text'] as String)
            .join('')
            .trim();
        if (text.isNotEmpty) return text;
      } catch (_) {}
      throw AiException('وصل رد فارغ من النموذج. جرّب تقليل عدد الملفات.');
    }

    final key = SettingsService.instance.textKey;
    if (key.isEmpty) {
      throw AiException('لم يتم إدخال مفتاح Claude. افتح الإعدادات وأدخله.');
    }
    final body = jsonEncode({
      'model': ApiConfig.textModel,
      'max_tokens': maxTokens,
      'system': system,
      'messages': [
        for (final t in turns)
          {
            'role': t.role,
            'content': [
              for (final f in t.files)
                {
                  'type': f.mime == 'application/pdf' ? 'document' : 'image',
                  'source': {
                    'type': 'base64',
                    'media_type': f.mime,
                    'data': base64Encode(f.bytes)
                  }
                },
              {'type': 'text', 'text': t.text.isEmpty ? '(بدون نص)' : t.text},
            ]
          }
      ],
    });
    final res = await _post(
      Uri.parse(ApiConfig.textApiUrl),
      {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': ApiConfig.anthropicVersion,
      },
      body,
      timeout: to,
    );
    final data = _decode(res);
    if (res.statusCode != 200) {
      String detail = '';
      try {
        detail = data['error']['message']?.toString() ?? '';
      } catch (_) {}
      throw AiException('خطأ من الخادم (${res.statusCode}). $detail');
    }
    final blocks = (data['content'] as List?) ?? [];
    final text = blocks
        .where((b) => b is Map && b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('')
        .trim();
    if (text.isEmpty) throw AiException('وصل رد فارغ من النموذج.');
    return text;
  }

  static Future<http.Response> _post(
      Uri url, Map<String, String> headers, String body,
      {Duration timeout = const Duration(seconds: 75)}) async {
    try {
      return await http
          .post(url, headers: headers, body: body)
          .timeout(timeout);
    } on TimeoutException {
      throw AiException('انتهت مهلة الاتصال. تحقق من الإنترنت وحاول مرة أخرى.');
    } catch (_) {
      throw AiException('تعذّر الاتصال بالخادم. تحقق من الإنترنت.');
    }
  }

  static dynamic _decode(http.Response res) {
    try {
      return jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      throw AiException('رد غير مفهوم من الخادم (رمز ${res.statusCode}).');
    }
  }

  // ---------------- Gemini (مجاني) ----------------
  static Future<http.Response> _geminiCall(
      List<ChatMessage> recent, String key, bool search,
      {String? system, bool json = false}) {
    final payload = <String, dynamic>{
      'system_instruction': {
        'parts': [
          {'text': system ?? systemPrompt}
        ]
      },
      'contents': recent
          .map((m) => {
                'role': m.role == 'user' ? 'user' : 'model',
                'parts': [
                  {'text': m.text}
                ]
              })
          .toList(),
      'generationConfig': {
        'maxOutputTokens': 4000,
        if (json) 'responseMimeType': 'application/json',
      },
    };
    if (search) {
      payload['tools'] = [
        {'google_search': {}}
      ];
    }
    return _post(
      Uri.parse(
          '${ApiConfig.geminiBase}/${SettingsService.instance.geminiModel}:generateContent'),
      {'content-type': 'application/json', 'x-goog-api-key': key},
      jsonEncode(payload),
    );
  }

  static Future<String> _chatGemini(List<ChatMessage> recent,
      {String? system, bool? search, bool json = false}) async {
    final key = SettingsService.instance.geminiKey;
    if (key.isEmpty) {
      throw AiException(
          'لم يتم إدخال مفتاح Gemini. افتح الإعدادات وأدخله (مجاني من aistudio.google.com).');
    }
    final useSearch = search ?? SettingsService.instance.webSearch;
    var res = await _geminiCall(recent, key, useSearch,
        system: system, json: json);
    // إن فشل مع البحث في الويب نجرّب بدونه
    if (res.statusCode != 200 && useSearch) {
      res = await _geminiCall(recent, key, false, system: system, json: json);
    }
    final data = _decode(res);
    if (res.statusCode != 200) {
      String detail = '';
      try {
        detail = data['error']['message']?.toString() ?? '';
      } catch (_) {}
      final head = switch (res.statusCode) {
        404 => 'اسم النموذج غير متاح. غيّره من الإعدادات.',
        400 || 403 => 'المفتاح غير صالح أو غير مفعّل.',
        429 => 'رفضت Google الطلب (حد الاستخدام).',
        _ => 'خطأ من الخادم (${res.statusCode}).',
      };
      throw AiException('$head\nرد Google: $detail');
    }
    try {
      final parts = data['candidates'][0]['content']['parts'] as List;
      final text = parts
          .where((p) => p is Map && p['text'] != null)
          .map((p) => p['text'] as String)
          .join('')
          .trim();
      if (text.isNotEmpty) return text;
    } catch (_) {}
    throw AiException('وصل رد فارغ من النموذج. أعد صياغة السؤال.');
  }

  // ---------------- Claude (مدفوع) ----------------
  static Future<String> _chatClaude(List<ChatMessage> recent,
      {String? system, bool? search}) async {
    final key = SettingsService.instance.textKey;
    if (key.isEmpty) {
      throw AiException(
          'لم يتم إدخال مفتاح Claude. افتح الإعدادات وأدخله.');
    }
    final payload = <String, dynamic>{
      'model': ApiConfig.textModel,
      'max_tokens': 4000,
      'system': system ?? systemPrompt,
      'messages': recent.map((m) => {'role': m.role, 'content': m.text}).toList(),
    };
    if (search ?? SettingsService.instance.webSearch) {
      payload['tools'] = [
        {'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 5}
      ];
    }
    final body = jsonEncode(payload);
    final res = await _post(
      Uri.parse(ApiConfig.textApiUrl),
      {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': ApiConfig.anthropicVersion,
      },
      body,
    );
    final data = _decode(res);
    if (res.statusCode != 200) {
      String detail = '';
      try {
        detail = data['error']['message']?.toString() ?? '';
      } catch (_) {}
      switch (res.statusCode) {
        case 401:
          throw AiException('مفتاح API غير صحيح. راجع الإعدادات.');
        case 429:
          throw AiException('تجاوزت حد الاستخدام. انتظر قليلاً ثم حاول.');
        default:
          throw AiException('خطأ من الخادم (${res.statusCode}). $detail');
      }
    }
    final blocks = (data['content'] as List?) ?? [];
    final text = blocks
        .where((b) => b is Map && b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join('')
        .trim();
    if (text.isEmpty) throw AiException('وصل رد فارغ من النموذج.');
    return text;
  }
}
