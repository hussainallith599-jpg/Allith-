import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

double? _d(dynamic v) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.replaceAll(',', '.'));
  return null;
}

String _s(dynamic v) => v == null ? '' : v.toString().trim();

String fmtQ(double v, [int d = 2]) {
  final s = v.toStringAsFixed(d);
  if (!s.contains('.')) return s;
  return s.replaceFirst(RegExp(r'\.?0+$'), '');
}

/// حدّ واحد في حساب الكمية: عدد × طول × عرض × ارتفاع (الحقول الفارغة تُهمل).
/// الإشارة -1 تعني خصماً (فتحات مثلاً).
class QTerm {
  String label;
  double? n, l, w, h;
  int sign;
  QTerm(this.label, this.n, this.l, this.w, this.h, this.sign);

  factory QTerm.fromJson(Map<String, dynamic> j) => QTerm(
        _s(j['label']),
        _d(j['n']),
        _d(j['l']),
        _d(j['w']),
        _d(j['h']),
        (_d(j['sign']) ?? 1) < 0 ? -1 : 1,
      );

  Map<String, dynamic> toJson() => {
        'label': label,
        'n': n,
        'l': l,
        'w': w,
        'h': h,
        'sign': sign,
      };

  List<double> get factors => [
        if (n != null) n!,
        if (l != null) l!,
        if (w != null) w!,
        if (h != null) h!,
      ];

  double get value {
    final f = factors;
    if (f.isEmpty) return 0;
    var p = 1.0;
    for (final x in f) {
      p *= x;
    }
    return sign * p;
  }

  String get calcText {
    final f = factors.map((x) => fmtQ(x, 3)).join('×');
    return '${sign < 0 ? '− ' : ''}$f';
  }
}

class BoqAiItem {
  String no;
  String description;
  String spec;
  String unit;
  List<QTerm> terms;
  double? directQty;
  double factor;
  String factorNote;
  String notes;
  double price; // سعر الوحدة (يُدخله المستخدم)
  bool suggested; // بند مقترح من الخبير ويحتاج مراجعة

  BoqAiItem({
    this.no = '',
    this.description = '',
    this.spec = '',
    this.unit = '',
    List<QTerm>? terms,
    this.directQty,
    this.factor = 1,
    this.factorNote = '',
    this.notes = '',
    this.price = 0,
    this.suggested = false,
  }) : terms = terms ?? [];

  factory BoqAiItem.fromJson(Map<String, dynamic> j) {
    final f = _d(j['factor']) ?? 1;
    return BoqAiItem(
      no: _s(j['no']),
      description: _s(j['description']),
      spec: _s(j['spec']),
      unit: _s(j['unit']),
      terms: ((j['terms'] as List?) ?? [])
          .map((e) => QTerm.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      directQty: _d(j['qty']),
      factor: f <= 0 ? 1 : f,
      factorNote: _s(j['factorNote']),
      notes: _s(j['notes']),
      price: _d(j['price']) ?? 0,
      suggested: j['suggested'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'no': no,
        'description': description,
        'spec': spec,
        'unit': unit,
        'terms': terms.map((t) => t.toJson()).toList(),
        'qty': directQty,
        'factor': factor,
        'factorNote': factorNote,
        'notes': notes,
        'price': price,
        'suggested': suggested,
      };

  /// الكمية تُحسب داخل التطبيق من الحدود (وليس من النموذج).
  double get qty {
    if (terms.isNotEmpty) {
      var sum = 0.0;
      for (final t in terms) {
        sum += t.value;
      }
      return sum * factor;
    }
    return directQty ?? 0;
  }

  double get total => qty * price;

  String get calcText {
    if (terms.isEmpty) return directQty == null ? '' : 'كمية مُدخلة مباشرة';
    final b = StringBuffer();
    for (var i = 0; i < terms.length; i++) {
      final t = terms[i].calcText;
      if (i == 0) {
        b.write(t.startsWith('− ') ? '-${t.substring(2)}' : t);
      } else {
        b.write(t.startsWith('− ') ? ' $t' : ' + $t');
      }
    }
    if (factor != 1) {
      b.write(
          ' ، ثم × ${fmtQ(factor, 3)}${factorNote.isEmpty ? '' : ' ($factorNote)'}');
    }
    return b.toString();
  }
}

class BoqAiSection {
  String title;
  List<BoqAiItem> items;
  BoqAiSection(this.title, [List<BoqAiItem>? items]) : items = items ?? [];

  double get total => items.fold(0.0, (a, e) => a + e.total);
}

class BoqAiDoc {
  String id;
  String title;
  String country;
  String location;
  String client;
  String currency;
  double contingency; // %
  double vat; // %
  List<BoqAiSection> sections;
  List<String> notes;
  int updated;

  BoqAiDoc({
    String? id,
    this.title = '',
    this.country = '',
    this.location = '',
    this.client = '',
    this.currency = '',
    this.contingency = 0,
    this.vat = 0,
    List<BoqAiSection>? sections,
    List<String>? notes,
    int? updated,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        sections = sections ?? [],
        notes = notes ?? [],
        updated = updated ?? DateTime.now().millisecondsSinceEpoch;

  int get itemCount => sections.fold(0, (a, s) => a + s.items.length);

  double get subtotal => sections.fold(0.0, (a, s) => a + s.total);
  double get contingencyAmount => subtotal * contingency / 100;
  double get vatAmount => (subtotal + contingencyAmount) * vat / 100;
  double get grand => subtotal + contingencyAmount + vatAmount;

  void renumber() {
    for (var i = 0; i < sections.length; i++) {
      for (var k = 0; k < sections[i].items.length; k++) {
        sections[i].items[k].no = '${i + 1}.${k + 1}';
      }
    }
  }

  void copyMetaFrom(BoqAiDoc o) {
    id = o.id;
    if (title.isEmpty) title = o.title;
    if (country.isEmpty) country = o.country;
    location = o.location;
    client = o.client;
    currency = o.currency;
    contingency = o.contingency;
    vat = o.vat;
  }

  factory BoqAiDoc.fromAiJson(Map<String, dynamic> j) {
    final d = BoqAiDoc(
      title: _s(j['title']),
      country: _s(j['country']),
      sections: ((j['sections'] as List?) ?? []).map((e) {
        final m = Map<String, dynamic>.from(e as Map);
        return BoqAiSection(
          _s(m['title']),
          ((m['items'] as List?) ?? [])
              .map((x) =>
                  BoqAiItem.fromJson(Map<String, dynamic>.from(x as Map)))
              .toList(),
        );
      }).toList(),
      notes: ((j['notes'] as List?) ?? [])
          .map((e) => _s(e))
          .where((e) => e.isNotEmpty)
          .toList(),
    );
    d.renumber();
    return d;
  }

  /// بنفس مخطط رد النموذج (ليقرأه النموذج عند التعديل).
  Map<String, dynamic> toAiJson() => {
        'title': title,
        'country': country,
        'sections': sections
            .map((s) => {
                  'title': s.title,
                  'items': s.items.map((e) => e.toJson()).toList(),
                })
            .toList(),
        'notes': notes,
      };

  Map<String, dynamic> toJson() => {
        'id': id,
        'location': location,
        'client': client,
        'currency': currency,
        'contingency': contingency,
        'vat': vat,
        'updated': updated,
        'boq': toAiJson(),
      };

  factory BoqAiDoc.fromJson(Map<String, dynamic> j) {
    final d = BoqAiDoc.fromAiJson(
        Map<String, dynamic>.from((j['boq'] as Map?) ?? {}));
    d.id = _s(j['id']).isEmpty ? d.id : _s(j['id']);
    d.location = _s(j['location']);
    d.client = _s(j['client']);
    d.currency = _s(j['currency']);
    d.contingency = _d(j['contingency']) ?? 0;
    d.vat = _d(j['vat']) ?? 0;
    d.updated = (j['updated'] as int?) ?? d.updated;
    return d;
  }
}

enum BoqAiStatus { needInfo, ready, message }

class BoqAiResult {
  final BoqAiStatus status;
  final String message;
  final List<String> questions;
  final BoqAiDoc? doc;
  final String raw;
  BoqAiResult(this.status, this.message, this.questions, this.doc, this.raw);

  static BoqAiResult parse(String raw) {
    var clean = raw.trim().replaceAll('```json', '').replaceAll('```', '');
    final a = clean.indexOf('{');
    final b = clean.lastIndexOf('}');
    if (a < 0 || b <= a) throw const FormatException('no json');
    final m = Map<String, dynamic>.from(
        jsonDecode(clean.substring(a, b + 1)) as Map);
    final st = _s(m['status']);
    final questions = ((m['questions'] as List?) ?? [])
        .map((e) => _s(e))
        .where((e) => e.isNotEmpty)
        .toList();
    BoqAiDoc? doc;
    if (m['boq'] is Map) {
      doc = BoqAiDoc.fromAiJson(Map<String, dynamic>.from(m['boq'] as Map));
    }
    final status = (st == 'need_info' || (questions.isNotEmpty && doc == null))
        ? BoqAiStatus.needInfo
        : (doc != null && doc.itemCount > 0)
            ? BoqAiStatus.ready
            : BoqAiStatus.message;
    return BoqAiResult(
        status, _s(m['message']), questions, doc, clean.substring(a, b + 1));
  }
}

/// جداول الكميات المحفوظة.
class BoqAiStore {
  static const _key = 'boq_ai_docs_v1';

  static Future<List<BoqAiDoc>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final l = (jsonDecode(raw) as List)
          .map((e) => BoqAiDoc.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      l.sort((a, b) => b.updated.compareTo(a.updated));
      return l;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<BoqAiDoc> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(l.map((e) => e.toJson()).toList()));
  }

  static Future<void> save(BoqAiDoc d) async {
    final l = await load();
    d.updated = DateTime.now().millisecondsSinceEpoch;
    final i = l.indexWhere((x) => x.id == d.id);
    if (i >= 0) {
      l[i] = d;
    } else {
      l.add(d);
    }
    await _write(l);
  }

  static Future<void> delete(String id) async {
    final l = await load();
    l.removeWhere((x) => x.id == id);
    await _write(l);
  }
}
