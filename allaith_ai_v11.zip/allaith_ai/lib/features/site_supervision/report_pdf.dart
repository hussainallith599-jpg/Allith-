import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'checklist_data.dart';
import 'site_models.dart';

class ReportPdf {
  ReportPdf._();

  static pw.Widget _t(String text,
      {double size = 11,
      bool bold = false,
      PdfColor color = PdfColors.black,
      pw.TextAlign align = pw.TextAlign.right}) {
    return pw.Text(
      text,
      textDirection: pw.TextDirection.rtl,
      textAlign: align,
      style: pw.TextStyle(
        fontSize: size,
        color: color,
        fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
      ),
    );
  }

  static String _statusLabel(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return 'مطابق';
      case ItemStatus.notOk:
        return 'غير مطابق';
      case ItemStatus.na:
        return 'لا ينطبق';
      case ItemStatus.pending:
        return 'لم يُفحص';
    }
  }

  static PdfColor _statusColor(ItemStatus s) {
    switch (s) {
      case ItemStatus.ok:
        return PdfColors.green800;
      case ItemStatus.notOk:
        return PdfColors.red800;
      case ItemStatus.na:
        return PdfColors.grey700;
      case ItemStatus.pending:
        return PdfColors.orange800;
    }
  }

  static pw.Widget _cell(pw.Widget child, {PdfColor? bg}) => pw.Container(
        color: bg,
        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        child: child,
      );

  /// يبني ملف PDF ويفتح نافذة المشاركة.
  static Future<void> shareReport(SiteReport r) async {
    final regular = await PdfGoogleFonts.cairoRegular();
    final bold = await PdfGoogleFonts.cairoBold();
    final phase = phaseById(r.phaseId);
    final items = reportItems(r);

    pw.MemoryImage? logo;
    try {
      final data = await rootBundle.load('assets/images/logo.png');
      logo = pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {}

    var ok = 0, bad = 0, na = 0, pending = 0;
    for (final it in items) {
      switch (r.statusOf(it.id)) {
        case ItemStatus.ok:
          ok++;
          break;
        case ItemStatus.notOk:
          bad++;
          break;
        case ItemStatus.na:
          na++;
          break;
        case ItemStatus.pending:
          pending++;
          break;
      }
    }

    final photos = <pw.Widget>[];
    for (final n in r.notes) {
      pw.Widget? img;
      if (n.photoPath != null && File(n.photoPath!).existsSync()) {
        final bytes = await File(n.photoPath!).readAsBytes();
        img = pw.Container(
          height: 130,
          child: pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.contain),
        );
      }
      photos.add(pw.Container(
        width: 250,
        margin: const pw.EdgeInsets.only(bottom: 8),
        padding: const pw.EdgeInsets.all(6),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey400, width: 0.5),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            if (img != null) img,
            if (img != null) pw.SizedBox(height: 4),
            if (n.text.trim().isNotEmpty) _t(n.text, size: 10),
          ],
        ),
      ));
    }

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(28),
          theme: pw.ThemeData.withFont(base: regular, bold: bold),
        ),
        build: (ctx) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logo != null)
                pw.Container(height: 60, child: pw.Image(logo))
              else
                pw.SizedBox(width: 60),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  _t('تقرير الإشراف الهندسي', size: 18, bold: true),
                  pw.SizedBox(height: 2),
                  _t('مرحلة: ${phase.title}', size: 12),
                ],
              ),
            ],
          ),
          pw.Divider(),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(3),
              1: const pw.FlexColumnWidth(1.4),
            },
            children: [
              pw.TableRow(children: [
                _cell(_t(r.project.isEmpty ? '—' : r.project)),
                _cell(_t('المشروع', bold: true), bg: PdfColors.grey200),
              ]),
              pw.TableRow(children: [
                _cell(_t(r.location.isEmpty ? '—' : r.location)),
                _cell(_t('الموقع', bold: true), bg: PdfColors.grey200),
              ]),
              pw.TableRow(children: [
                _cell(_t(r.engineer.isEmpty ? '—' : r.engineer)),
                _cell(_t('المهندس المشرف', bold: true), bg: PdfColors.grey200),
              ]),
              pw.TableRow(children: [
                _cell(_t(fmtDate(r.date))),
                _cell(_t('التاريخ', bold: true), bg: PdfColors.grey200),
              ]),
            ],
          ),
          pw.SizedBox(height: 10),
          _t('نسبة الإنجاز الكلية: ${overallProgress(r)}%   |   مطابق $ok  |  غير مطابق $bad  |  لا ينطبق $na  |  لم يُفحص $pending',
              size: 11, bold: true),
          pw.SizedBox(height: 8),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(1.0),
              1: const pw.FlexColumnWidth(1.2),
              2: const pw.FlexColumnWidth(5),
              3: const pw.FlexColumnWidth(0.5),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColors.grey300),
                children: [
                  _cell(_t('الإنجاز', bold: true, align: pw.TextAlign.center)),
                  _cell(_t('الحالة', bold: true, align: pw.TextAlign.center)),
                  _cell(_t('بند الفحص', bold: true)),
                  _cell(_t('#', bold: true, align: pw.TextAlign.center)),
                ],
              ),
              for (var i = 0; i < items.length; i++)
                pw.TableRow(children: [
                  _cell(_t('${r.progressOf(items[i].id)}%',
                      size: 10, align: pw.TextAlign.center)),
                  _cell(_t(_statusLabel(r.statusOf(items[i].id)),
                      size: 10,
                      bold: true,
                      color: _statusColor(r.statusOf(items[i].id)),
                      align: pw.TextAlign.center)),
                  _cell(_t(items[i].text, size: 10)),
                  _cell(_t('${i + 1}', size: 10, align: pw.TextAlign.center)),
                ]),
            ],
          ),
          if (photos.isNotEmpty) ...[
            pw.SizedBox(height: 14),
            _t('الملاحظات والصور', size: 13, bold: true),
            pw.SizedBox(height: 6),
            pw.Wrap(
              spacing: 8,
              runSpacing: 4,
              alignment: pw.WrapAlignment.end,
              children: photos,
            ),
          ],
          if (r.general.trim().isNotEmpty) ...[
            pw.SizedBox(height: 10),
            _t('ملاحظات عامة', size: 13, bold: true),
            pw.SizedBox(height: 4),
            _t(r.general),
          ],
          pw.SizedBox(height: 24),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              _t('توقيع المقاول: ____________'),
              _t('توقيع المهندس المشرف: ____________'),
            ],
          ),
          pw.SizedBox(height: 14),
          _t('أُنشئ بواسطة تطبيق الليث AI', size: 8, color: PdfColors.grey600),
        ],
      ),
    );

    final bytes = await doc.save();
    final d = DateTime.fromMillisecondsSinceEpoch(r.date);
    final name =
        'site_report_${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}.pdf';
    await Printing.sharePdf(bytes: bytes, filename: name);
  }
}
