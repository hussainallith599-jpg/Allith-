import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'checklist_data.dart';

enum ItemStatus { pending, ok, notOk, na }

String fmtDate(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${d.year}/${d.month}/${d.day}';
}

class SiteNote {
  String text;
  String? photoPath;
  SiteNote({required this.text, this.photoPath});

  Map<String, dynamic> toJson() => {'text': text, 'photo': photoPath};

  factory SiteNote.fromJson(Map<String, dynamic> j) => SiteNote(
        text: (j['text'] as String?) ?? '',
        photoPath: j['photo'] as String?,
      );
}

class CustomItem {
  String id;
  String phaseId;
  String text;
  CustomItem({required this.id, required this.phaseId, required this.text});

  Map<String, dynamic> toJson() => {'id': id, 'phase': phaseId, 'text': text};

  factory CustomItem.fromJson(Map<String, dynamic> j) => CustomItem(
        id: j['id'] as String,
        phaseId: (j['phase'] as String?) ?? 'excavation',
        text: (j['text'] as String?) ?? '',
      );
}

class SiteReport {
  String id;
  String project;
  String location;
  String engineer;
  String phaseId;
  String general;
  int date;
  int updated;
  Map<String, int> statuses;
  Map<String, int> progress;
  List<CustomItem> custom;
  List<SiteNote> notes;

  SiteReport({
    required this.id,
    this.project = '',
    this.location = '',
    this.engineer = '',
    this.phaseId = 'excavation',
    this.general = '',
    required this.date,
    required this.updated,
    Map<String, int>? statuses,
    Map<String, int>? progress,
    List<CustomItem>? custom,
    List<SiteNote>? notes,
  })  : statuses = statuses ?? {},
        progress = progress ?? {},
        custom = custom ?? [],
        notes = notes ?? [];

  factory SiteReport.create() {
    final now = DateTime.now().millisecondsSinceEpoch;
    return SiteReport(id: now.toString(), date: now, updated: now);
  }

  ItemStatus statusOf(String itemId) {
    final v = statuses[itemId];
    if (v == null || v < 0 || v >= ItemStatus.values.length) {
      return ItemStatus.pending;
    }
    return ItemStatus.values[v];
  }

  int progressOf(String itemId) => (progress[itemId] ?? 0).clamp(0, 100);

  void setProgress(String itemId, int v) {
    if (v <= 0) {
      progress.remove(itemId);
    } else {
      progress[itemId] = v.clamp(0, 100);
    }
  }

  void setStatus(String itemId, ItemStatus s) {
    if (s == ItemStatus.pending) {
      statuses.remove(itemId);
    } else {
      statuses[itemId] = s.index;
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'project': project,
        'location': location,
        'engineer': engineer,
        'phaseId': phaseId,
        'general': general,
        'date': date,
        'updated': updated,
        'statuses': statuses,
        'progress': progress,
        'custom': custom.map((c) => c.toJson()).toList(),
        'notes': notes.map((n) => n.toJson()).toList(),
      };

  factory SiteReport.fromJson(Map<String, dynamic> j) => SiteReport(
        id: j['id'] as String,
        project: (j['project'] as String?) ?? '',
        location: (j['location'] as String?) ?? '',
        engineer: (j['engineer'] as String?) ?? '',
        phaseId: (j['phaseId'] as String?) ?? 'excavation',
        general: (j['general'] as String?) ?? '',
        date: (j['date'] as int?) ?? 0,
        updated: (j['updated'] as int?) ?? 0,
        statuses: Map<String, int>.from((j['statuses'] as Map?) ?? {}),
        progress: Map<String, int>.from((j['progress'] as Map?) ?? {}),
        custom: ((j['custom'] as List?) ?? [])
            .map((e) => CustomItem.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        notes: ((j['notes'] as List?) ?? [])
            .map((e) => SiteNote.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class ReportsStore {
  static const _key = 'site_reports_v1';

  static Future<List<SiteReport>> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => SiteReport.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      list.sort((a, b) => b.updated.compareTo(a.updated));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<SiteReport> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(list.map((r) => r.toJson()).toList()));
  }

  static Future<void> save(SiteReport r) async {
    final list = await load();
    r.updated = DateTime.now().millisecondsSinceEpoch;
    final i = list.indexWhere((x) => x.id == r.id);
    if (i >= 0) {
      list[i] = r;
    } else {
      list.add(r);
    }
    await _write(list);
  }

  static Future<void> delete(String id) async {
    final list = await load();
    list.removeWhere((x) => x.id == id);
    await _write(list);
  }
}

/// بنود المرحلة الحالية: الجاهزة + المضافة يدوياً.
List<ChecklistItem> reportItems(SiteReport r) => [
      ...phaseById(r.phaseId).items,
      ...r.custom
          .where((c) => c.phaseId == r.phaseId)
          .map((c) => ChecklistItem(c.id, c.text)),
    ];

/// نسبة الإنجاز الكلية للمرحلة (متوسط نسب البنود).
int overallProgress(SiteReport r) {
  final items = reportItems(r);
  if (items.isEmpty) return 0;
  final sum = items.fold<int>(0, (a, i) => a + r.progressOf(i.id));
  return (sum / items.length).round();
}
