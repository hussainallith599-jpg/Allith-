/// ضع مفاتيحك هنا مباشرة، أو الأفضل تمريرها عند البناء:
/// flutter build apk --release \
///   --dart-define=TEXT_API_KEY=xxx --dart-define=IMAGE_API_KEY=yyy
class ApiConfig {
  ApiConfig._();

  // ===== مفتاح نموذج النصوص (Anthropic Claude) =====
  static const String textApiKey = String.fromEnvironment(
    'TEXT_API_KEY',
    defaultValue: 'ضع_مفتاح_ANTHROPIC_هنا',
  );
  static const String textApiUrl = 'https://api.anthropic.com/v1/messages';
  static const String textModel = 'claude-sonnet-5-5';
  static const String anthropicVersion = '2023-06-01';

  // ===== مفتاح توليد الصور (OpenAI Images) =====
  static const String imageApiKey = String.fromEnvironment(
    'IMAGE_API_KEY',
    defaultValue: 'ضع_مفتاح_OPENAI_هنا',
  );
  static const String imageApiUrl = 'https://api.openai.com/v1/images/generations';
  static const String imageEditUrl = 'https://api.openai.com/v1/images/edits';
  static const String imageModel = 'gpt-image-1';

  static bool get hasTextKey => !textApiKey.startsWith('ضع_');
  static bool get hasImageKey => !imageApiKey.startsWith('ضع_');
}
