import 'package:flutter/material.dart';
import '../../core/widgets/allaith_logo.dart';

class _Section {
  final String title;
  final String subtitle;
  final IconData icon;
  const _Section(this.title, this.subtitle, this.icon);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const _sections = [
    _Section('المساعد الهندسي', 'استشارات معمارية وإنشائية وأكواد البناء',
        Icons.forum_outlined),
    _Section('استوديو الرندر والتصميم الداخلي',
        'توليد تصاميم واقعية واقتراح الأثاث', Icons.chair_outlined),
    _Section('مولد المخططات المعمارية', 'توزيع ذكي للمساحات حسب أبعاد الأرض',
        Icons.grid_view_outlined),
    _Section('حاسبة الكميات BOQ', 'خرسانة، حديد، بلوك، لياسة، دهان',
        Icons.calculate_outlined),
    _Section('الإشراف الهندسي', 'قوائم فحص وتقارير الموقع اليومية',
        Icons.fact_check_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const AllaithLogo(height: 40)),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _sections.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final s = _sections[i];
          return Card(
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              leading: Icon(s.icon, size: 32),
              title: Text(s.title,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(s.subtitle),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('سيتم ربط "${s.title}" في الجزء التالي'))),
            ),
          );
        },
      ),
    );
  }
}
